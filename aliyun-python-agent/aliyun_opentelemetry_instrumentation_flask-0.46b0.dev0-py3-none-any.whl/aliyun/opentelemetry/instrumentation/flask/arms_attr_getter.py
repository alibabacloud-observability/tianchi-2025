from aliyun.sdk.extension.arms.semconv import attributes as ArmsAttributes
from aliyun.opentelemetry.semconv.trace import SpanAttributes
from aliyun.sdk.extension.arms.convergence import converge, TargetType
from urllib.parse import urlparse
from aliyun.sdk.extension.arms.semconv.attributes import arms_attributes
from aliyun.sdk.extension.arms.semconv.metrics import MetricInstruments as ArmsMetrics
from aliyun.sdk.extension.arms.semconv.metrics import RpcType
from opentelemetry.baggage import get_baggage
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.semconv.attributes.convergence_attributes import get_convergence_key

_logger = getLogger(__name__)

ARMS_EXCEP_NAME = "excepName"
ARMS_EXCEP_INFO = "excepInfo"
ARMS_EXCEP_TYPE = "excepType"


def append_client_attributes(attributes, ctx=None):
    ppid = get_baggage(ArmsAttributes.EagleEye_pAppName, context=ctx)
    if ppid is not None:
        attributes[ArmsAttributes.PPID] = ppid
    prpc = get_baggage(ArmsAttributes.EagleEye_pRpc, context=ctx)
    if prpc is not None:
        prpc = converge(TargetType.prpc, prpc)
        attributes[arms_attributes.PRPC] = prpc


def collect_arms_request_attributes(attributes, span_name=None):
    host = attributes.get(SpanAttributes.HTTP_HOST)
    scheme = attributes.get(SpanAttributes.HTTP_SCHEME)
    conv_host = converge(TargetType.url, host)
    if span_name is not None:
        path = span_name
    else:
        path = attributes.get(SpanAttributes.HTTP_TARGET)
    if path is None or path == "":
        url = attributes.get(SpanAttributes.HTTP_URL)
        if url is not None and url != "":
            parsed_url = urlparse(url)
            path = parsed_url.path
    if path is not None and ("?" in path):
        path = path.split("?")[0]
    conv_path = converge(TargetType.url, path)
    attributes[SpanAttributes.URL_PATH] = path
    attributes[SpanAttributes.DESTINATION_DOMAIN] = host
    conv_path_key = get_convergence_key(SpanAttributes.URL_PATH)
    attributes[conv_path_key] = conv_path
    attributes[ArmsAttributes.HOST] = host
    conv_host_key = get_convergence_key(ArmsAttributes.HOST)
    attributes[conv_host_key] = conv_host
    attributes[arms_attributes.COMPONENT_NAME] = arms_attributes.CallTypeValue.HTTP.value
    attributes[arms_attributes.ENDPOINT] = conv_path
    attributes[ArmsAttributes.RPC] = conv_path
    attributes[arms_attributes.CALL_KIND] = arms_attributes.CallTypeValue.HTTP.value
    attributes[arms_attributes.CALL_TYPE] = arms_attributes.CallTypeValue.HTTP.value
    attributes[arms_attributes.RPC_TYPE] = arms_attributes.RpcTypeValue.HTTP.value
    attributes[arms_attributes.OUT_IDS] = host
    attributes[arms_attributes.NET_PROTOCOL_NAME] = scheme


def convert_status_code(status_code):
    status = None
    if status_code == 200:
        status = "200"
    elif 200 < status_code < 300:
        status = "2xx"
    elif 300 < status_code < 400:
        status = "3xx"
    elif 400 <= status_code < 500:
        status = "4xx"
    elif 100 <= status_code < 200:
        status = "1xx"
    else:
        status = "5xx"
    return status


# TODO: add exception meta id here
def collect_excep_attributes(excep):
    return {
        ARMS_EXCEP_NAME: type(excep).__name__,
        ARMS_EXCEP_INFO: "C4",
        ARMS_EXCEP_TYPE: "1baaaa"
    }
