"""
Constants for SGLang instrumentation.
"""
from aliyun.semconv.trace import (
    SpanAttributes,
)

# Service name
SERVICE_NAME = "sglang"

# Span names
SPAN_HTTP_REQUEST = "http.request"
SPAN_TOKENIZE = "tokenize"
SPAN_MODEL_INFERENCE = "model.inference"
SPAN_DETOKENIZE = "detokenize"

# Attribute names
ATTR_MODEL_NAME = "model.name"
ATTR_REQUEST_TYPE = "request.type"
ATTR_INPUT_TOKENS = "input.tokens"
ATTR_OUTPUT_TOKENS = "output.tokens"
ATTR_TEMPERATURE = "temperature"
ATTR_MAX_TOKENS = "max_tokens"
ATTR_LATENCY = "latency"
ATTR_ERROR = "error"

# Request types
REQUEST_TYPE_COMPLETION = "completion"
REQUEST_TYPE_CHAT = "chat"
REQUEST_TYPE_EMBEDDING = "embedding"

# Environment variables
ENV_ENABLED = "SGLANG_INSTRUMENTATION_ENABLED"
ENV_SAMPLE_RATE = "SGLANG_INSTRUMENTATION_SAMPLE_RATE"

# OpenTelemetry Metrics 名称常量
# 时间类指标
METRIC_TIME_TO_FIRST_TOKEN = "gen_ai_server_time_to_first_token"
METRIC_TIME_TO_FIRST_TOKEN_COUNT = "time_to_first_token_count"
METRIC_E2E_LATENCY = "e2e_latency"
METRIC_MODEL_EXECUTE_TIME = "model_execute_time"
METRIC_MODEL_FORWARD_TIME = "model_forward_time"
METRIC_REASONING_TIME = "reasoning_time"

# 数据块相关指标
METRIC_RESPONSE_CHUNK_COUNT = "response_chunk_count"
METRIC_RESPONSE_CHUNK_INTERVAL_AVG = "response_chunk_interval_avg"
METRIC_RESPONSE_CHUNK_INTERVAL_MAX = "response_chunk_interval_max"
METRIC_RESPONSE_CHUNK_INTERVAL_MIN = "response_chunk_interval_min"
METRIC_ITL = "inter_token_latency"
METRIC_TPOT = "gen_ai_server_time_per_output_token"

# Tokenizer metrics
METRIC_PROMPT_TOKENS_TOTAL = "prompt_tokens_total"
METRIC_GENERATION_TOKENS_TOTAL = "generation_tokens_total"
METRIC_NUM_REQUESTS_TOTAL = "num_requests_total"
METRIC_TIME_TO_FIRST_TOKEN_SECONDS = "time_to_first_token_seconds"
METRIC_TIME_PER_OUTPUT_TOKEN_SECONDS = "time_per_output_token_seconds"
METRIC_E2E_REQUEST_LATENCY_SECONDS = "e2e_request_latency_seconds"

# 指标单位
METRIC_UNIT_SECONDS = "s"
METRIC_UNIT_COUNT = "count"

# 指标属性
METRIC_ATTRIBUTES_DEFAULT = {"callType": "gen_ai", "rpcType": "2100"}

# 特定模型类型识别
REASONING_MODEL_TYPES = ["deepseek", "qwen", "qwq-32b"]

# 推理标记，用于检测推理过程的开始和结束
REASONING_START_MARKER = "<think>"
REASONING_END_MARKER = "</think>"
ENV_ENABLE_REASONING = "ENABLE_REASONING"

# Span子类型常量
SPAN_SUB_KIND_FIRST_TOKEN = "FIRST_TOKEN_LATENCY"
SPAN_SUB_KIND_REASONING = "REASONING"

# Span属性键常量 - genai.llm相关
# 响应数据块相关
GEN_AI_LLM_RESPONSE_CHUNK_COUNT = "gen_ai.response.chunk_count"
GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_AVG = "gen_ai.response.avg_chunk_interval"
GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_MAX = "gen_ai.response.max_chunk_interval"
GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_MIN = "gen_ai.response.min_chunk_interval"

# 工具调用相关
GEN_AI_LLM_TOOL_CALL_DETECTED = "gen_ai.request.tool_call_detected"
GEN_AI_LLM_TOOL_CALLS_COUNT = "gen_ai.request.tool_calls_count"
GEN_AI_LLM_HAS_TOOL_CALLS = "gen_ai.request.has_tool_calls"

# 完成原因
GEN_AI_LLM_FINISH_REASON = SpanAttributes.GEN_AI_RESPONSE_FINISH_REASON
GEN_AI_LLM_MATCHED_STOP = "gen_ai.response.matched_stop"

# 模型相关
GEN_AI_LLM_MODEL = SpanAttributes.GEN_AI_MODEL_NAME

# Inter-Token Latency (ITL)
GEN_AI_LLM_MEAN_ITL = "gen_ai.response.mean_itl"
GEN_AI_LLM_MEAN_TPOT = "gen_ai.response.mean_tpot"

# 推理过程相关
GEN_AI_REASONING_CONTENT = "gen_ai.reasoning.content"
GEN_AI_REASONING_DURATION = "gen_ai.reasoning.duration"
GEN_AI_REASONING_CONTENT_SIZE = "gen_ai.reasoning.content_size"
GEN_AI_REASONING_END_MARKER = "gen_ai.reasoning.end_marker"
GEN_AI_REASONING_START_MARKER = "gen_ai.reasoning.start_marker"

# 响应相关
GEN_AI_RESPONSE_TOKENS_STREAMED = "gen_ai.response.tokens_streamed"
GEN_AI_RESPONSE_REASONING_TIME = "gen_ai.response.reasoning_time"
GEN_AI_RESPONSE_REASONING_CONTENT = "gen_ai.response.reasoning_content"
GEN_AI_RESPONSE_REASONING_CONTENT_SIZE = "gen_ai.response.reasoning_content_size"

# 首个token相关
GEN_AI_FIRST_TOKEN_DURATION = "gen_ai.first_token.duration"
GEN_AI_FIRST_TOKEN_ARRIVAL_TIME = "gen_ai.first_token.arrival_time"

# Metric names
METRIC_NUM_RUNNING_REQS = "sglang_num_running_reqs"
METRIC_LOG_COUNT = "sglang_log_count"
METRIC_NUM_USED_TOKENS = "sglang_num_used_tokens"
METRIC_TOKEN_USAGE = "sglang_token_usage"
METRIC_GEN_THROUGHPUT = "sglang_gen_throughput"
METRIC_NUM_QUEUE_REQS = "sglang_num_queue_reqs"
METRIC_CACHE_HIT_RATE = "gen_ai_sglang_cache_hit_rate"
METRIC_SPEC_ACCEPT_LENGTH = "sglang_spec_accept_length"
METRIC_TIME_PER_OUTPUT_TOKEN = "gen_ai_server_time_per_output_token"
METRIC_TIME_INTER_TOKEN_LATENCY_SECONDS = "sglang_inter_token_latency_seconds"
METRIC_E2E_REQUEST_LATENCY = "gen_ai_server_request_duration"
METRIC_CACHED_TOKENS_TOTAL = "gen_ai_sglang_cached_tokens_total"
