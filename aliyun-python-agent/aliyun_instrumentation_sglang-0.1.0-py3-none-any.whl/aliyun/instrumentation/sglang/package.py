_instruments = ("sglang >= 0.4.0", "sglang <= 0.4.9post6")
_supports_metrics = True
