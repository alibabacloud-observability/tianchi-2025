"""
Instrumentation implementation for SGLang.
"""

import time
import os
from aliyun.sdk.extension.arms.logger import getLogger
import json

from opentelemetry.trace import Span, Status, StatusCode, Tracer
from opentelemetry.metrics import get_meter
from aliyun.semconv.trace import (
    AliyunSpanKindValues,
    MessageAttributes,
    SpanAttributes,
    VSpanAttributes,
)
from .utils import (
    record_error,
)
from .constants import (
    REASONING_START_MARKER,
    REASONING_END_MARKER,
    GEN_AI_LLM_TOOL_CALL_DETECTED,
    GEN_AI_LLM_TOOL_CALLS_COUNT,
    GEN_AI_LLM_HAS_TOOL_CALLS,
    GEN_AI_LLM_FINISH_REASON,
    GEN_AI_REASONING_CONTENT,
    GEN_AI_REASONING_DURATION,
    GEN_AI_REASONING_CONTENT_SIZE,
    GEN_AI_REASONING_END_MARKER,
    GEN_AI_REASONING_START_MARKER,
    GEN_AI_RESPONSE_TOKENS_STREAMED,
    GEN_AI_RESPONSE_REASONING_TIME,
    GEN_AI_RESPONSE_REASONING_CONTENT,
    GEN_AI_RESPONSE_REASONING_CONTENT_SIZE,
    GEN_AI_FIRST_TOKEN_DURATION,
    GEN_AI_FIRST_TOKEN_ARRIVAL_TIME,
    ENV_ENABLE_REASONING,
)
from .stop_on_exception import stop_on_exception
from aliyun.sdk.extension.arms.semconv.metrics import ArmsCommonServiceMetrics
from aliyun.sdk.extension.arms.common.utils.metrics_utils import get_llm_common_attributes

# 字符串最大长度常量
MAX_CONTENT_LENGTH = 50000

# Configure logging
logger = getLogger(__name__)

# 全局变量，用于存储server_args
_server_args = None

# 定义server_args文件路径
import tempfile

_SERVER_ARGS_FILE = os.path.join(tempfile.gettempdir(), 'sglang_server_args.pkl')

# 导入server_args工具函数
from .server_args_utils import (
    load_server_args_from_file,
    extract_server_args_info
)

from .version import __version__


class BaseWrapper:
    """Base class for all wrappers."""

    def __init__(self, tracer: Tracer) -> None:
        self.tracer = tracer
        # 获取全局server_args
        global _server_args
        self.server_args = _server_args
        self.server_args_info = None  # 用于存储从文件读取的server_args信息
        self.model_supports_reasoning = None  # 用于缓存模型是否支持推理的信息
        self.meter = get_meter(__name__,
                               __version__,
                               None,
                               schema_url="https://opentelemetry.io/schemas/1.11.0",
                               )

        pid = os.getpid()
        # 如果当前进程没有server_args，尝试从文件读取
        if not self.server_args:
            # 从文件加载server_args信息
            self.server_args_info = load_server_args_from_file(pid)
            if not self.server_args_info:
                logger.debug(f"[PID:{pid}] BaseWrapper 未能从文件加载 server_args_info")
        else:
            logger.debug(f"[PID:{pid}] BaseWrapper 成功获取全局 server_args: {self.server_args}")

            # 从server_args对象中提取信息（用于本进程内使用）
            self.server_args_info = extract_server_args_info(self.server_args, pid)
            if self.server_args_info:
                logger.debug(f"[PID:{pid}] BaseWrapper 从全局server_args提取信息: {self.server_args_info}")

        if not self.server_args_info:
            logger.debug(f"[PID:{pid}] BaseWrapper 未获取到 server_args_info")

        # 初始化推理支持状态为未确定
        self.reasoning_support_determined = False
        self.supports_reasoning = False

    def get_model_name(self) -> str:
        """从 server_args_info 中获取模型名称

        Returns:
            str: 模型名称，如果未找到则返回 "unknown"
        """
        if self.server_args_info and "served_model_name" in self.server_args_info:
            return self.server_args_info["served_model_name"]
        return "unknown"

    @stop_on_exception(default_return=False)
    def _model_supports_reasoning(self, model_name):
        """判断给定的模型名称是否支持推理功能

        Args:
            model_name: 模型名称

        Returns:
            bool: 模型是否支持推理功能
        """
        if not model_name:
            return False

        # 转换为小写进行比较
        model_name = model_name.lower()

        # 支持推理的模型关键字，只保留三个核心关键字
        reasoning_model_keywords = [
            "qwq-32b",  # qwq-32b系列模型
            "deepseek-r1",  # deepseek-r1系列模型
            "reasoning"  # 名称中明确包含reasoning的模型
        ]

        # 检查模型名称是否包含关键字
        for keyword in reasoning_model_keywords:
            if keyword in model_name:
                logger.debug(f"模型 {model_name} 支持推理功能 (匹配关键字: {keyword})")
                return True

        return False

    @stop_on_exception(default_return=(False, False))
    def _is_reasoning_enabled_by_env(self):
        """检查环境变量是否启用或禁用了推理功能

        Returns:
            tuple: (is_set, is_enabled) - 环境变量是否设置了推理状态，以及推理是否启用
        """
        enable_reasoning_env = os.environ.get(ENV_ENABLE_REASONING)
        if enable_reasoning_env is not None:
            enable_reasoning_env = enable_reasoning_env.lower()
            if enable_reasoning_env in ("1", "true", "yes", "y", "on"):
                logger.debug(f"环境变量启用了推理功能 ({ENV_ENABLE_REASONING})")
                return True, True
            elif enable_reasoning_env in ("0", "false", "no", "n", "off"):
                logger.debug(f"环境变量禁用了推理功能 ({ENV_ENABLE_REASONING})")
                return True, False

        # 环境变量未设置推理状态
        return False, False

    @stop_on_exception(default_return=False)
    def _is_reasoning_supported(self, model_name=None, request_params=None):
        """判断当前使用的模型是否支持推理功能

        Args:
            model_name: 模型名称，如果已知
            request_params: 请求参数，可能包含推理相关配置

        Returns:
            bool: 是否支持推理功能
        """
        # 如果已经确定了推理支持状态，直接返回缓存的结果
        if self.reasoning_support_determined:
            return self.supports_reasoning

        # 默认不支持
        supports_reasoning = False

        # 0. 基于环境变量的判断（最高优先级）
        env_set, env_enabled = self._is_reasoning_enabled_by_env()
        if env_set:
            supports_reasoning = env_enabled
            self.reasoning_support_determined = True
            self.supports_reasoning = supports_reasoning
            return supports_reasoning

        # 1. 从server_args_info中获取模型名称并判断
        if self.server_args_info and "served_model_name" in self.server_args_info:
            model_name = self.server_args_info["served_model_name"]
            supports_reasoning = self._model_supports_reasoning(model_name)
            logger.debug(f"从server_args_info中获取模型名称: {model_name}, 支持推理: {supports_reasoning}")
        # 2. 如果server_args_info中没有模型名称，则使用传入的model_name
        elif model_name:
            supports_reasoning = self._model_supports_reasoning(model_name)
            logger.debug(f"使用传入的模型名称: {model_name}, 支持推理: {supports_reasoning}")

        # 3. 基于请求参数的判断
        if request_params:
            # 检查请求参数中是否有启用推理的相关配置
            # 例如，某些API可能使用类似 enable_reasoning=True 的参数
            if isinstance(request_params, dict):
                if request_params.get("enable_reasoning") is True:
                    supports_reasoning = True
                    logger.debug("请求参数启用了推理功能")
                elif request_params.get("enable_reasoning") is False:
                    supports_reasoning = False
                    logger.debug("请求参数禁用了推理功能")

        # 缓存结果，避免重复判断
        self.reasoning_support_determined = True
        self.supports_reasoning = supports_reasoning

        logger.debug(f"推理支持状态确定: {supports_reasoning}")

        return supports_reasoning

    @stop_on_exception(default_return="")
    def _get_span_attribute(self, span, attribute_name, default_value=""):
        """安全地获取span属性，处理NonRecordingSpan的情况

        Args:
            span: span对象
            attribute_name: 属性名称
            default_value: 默认值

        Returns:
            属性值或默认值
        """
        if hasattr(span, 'get_attribute'):
            return span.get_attribute(attribute_name) or default_value
        return default_value

    @stop_on_exception(default_return=None)
    def _create_span(self, name: str, kind: str, sub_kind: str, **attributes):
        """Create a span with common attributes."""
        span_attrs = {
            SpanAttributes.GEN_AI_SPAN_KIND: kind,
            SpanAttributes.GEN_AI_SPAN_SUB_KIND: sub_kind,
            SpanAttributes.SERVICE_NAME: "sglang",
            SpanAttributes.SERVICE_VERSION: "0.1.0",
            **attributes
        }
        return self.tracer.start_span(name, attributes=span_attrs)

    @stop_on_exception(default_return="")
    def _truncate_string(self, text, max_length=MAX_CONTENT_LENGTH):
        """截断过长的字符串

        Args:
            text: 要截断的字符串
            max_length: 最大长度，默认为MAX_CONTENT_LENGTH

        Returns:
            截断后的字符串
        """
        if not isinstance(text, str):
            text = str(text)

        if len(text) > max_length:
            return text[:max_length - 3] + "..."
        return text

    async def _extract_request_parameters(self, raw_request, pid):
        """提取请求参数并创建基本的 span 属性"""
        try:
            logger.debug(f"[PID:{pid}] 开始提取请求参数")
            request_json = await raw_request.json()
            is_chat = 'messages' in request_json
            model_name = request_json.get('model', 'unknown')
            is_stream = request_json.get('stream', False)

            # 创建合适的 span 名称
            span_name = "chat.completions" if is_chat else "completions"
            if is_stream:
                span_name += ".stream"
            logger.debug(f"[PID:{pid}] 确定请求类型: is_chat={is_chat}, is_stream={is_stream}, span_name={span_name}")

            # 基本请求参数
            span_attributes = {
                SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
                SpanAttributes.GEN_AI_REQUEST_IS_STREAM: is_stream,
                SpanAttributes.GEN_AI_REQUEST_MODEL_NAME: model_name,
            }
            logger.debug(f"[PID:{pid}] 基础属性设置完成: model={model_name}")

            # 常用请求设置
            logger.debug(f"[PID:{pid}] 提取请求参数: 开始处理请求设置")
            if 'temperature' in request_json:
                span_attributes[VSpanAttributes.GEN_AI_REQUEST_TEMPERATURE] = request_json['temperature']
                logger.debug(f"[PID:{pid}] 设置温度参数: {request_json['temperature']}")
            if 'max_tokens' in request_json:
                span_attributes[VSpanAttributes.GEN_AI_REQUEST_MAX_TOKENS] = request_json['max_tokens']
                logger.debug(f"[PID:{pid}] 设置最大令牌数: {request_json['max_tokens']}")
            if 'top_p' in request_json:
                span_attributes[VSpanAttributes.GEN_AI_REQUEST_TOP_P] = request_json['top_p']
                logger.debug(f"[PID:{pid}] 设置top_p值: {request_json['top_p']}")

            # 添加提示词或消息
            logger.debug(f"[PID:{pid}] 提取请求参数: 开始处理提示词或消息")
            if is_chat and 'messages' in request_json:
                messages = request_json['messages']
                logger.debug(f"[PID:{pid}] 解析聊天消息，共 {len(messages)} 条")

                input_dict = {}
                total_length = 0
                max_length = MAX_CONTENT_LENGTH - 3
                # 记录单独的消息
                for i, msg in enumerate(messages):
                    if 'role' in msg:
                        span_attributes[f"{MessageAttributes.MESSAGE_ROLE}.{i}"] = msg['role']
                        logger.debug(f"[PID:{pid}] 消息 {i} 角色: {msg['role']}")
                    if 'content' in msg:
                        content = msg['content']
                        # 限制 content 的长度以避免 span 过大
                        content_str = content if isinstance(content, str) else str(content)
                        content_str = self._truncate_string(content_str)
                        span_attributes[f"{MessageAttributes.MESSAGE_CONTENT}.{i}"] = content_str
                        # 计算当前内容长度
                        content_length = len(content_str)

                        # 如果已经超过最大长度限制，则不再添加新的内容
                        if total_length + content_length > max_length:
                            break

                        # 添加到输出字典
                        input_dict[str(i)] = {"content": content_str}
                        total_length += content_length
                if total_length >= max_length:
                    input_dict["truncated"] = True
                # 记录整体输入值
                input_value = json.dumps(input_dict, ensure_ascii=False)
                span_attributes[SpanAttributes.INPUT_VALUE] = input_value
            elif 'prompt' in request_json:
                prompt = str(request_json['prompt'])
                prompt_len = len(prompt)
                logger.debug(f"[PID:{pid}] 解析提示词，长度: {prompt_len} 字符")
                # 记录输入值
                prompt_for_input = self._truncate_string(prompt)
                span_attributes[SpanAttributes.INPUT_VALUE] = prompt_for_input
                logger.debug(f"[PID:{pid}] 已记录输入值，长度: {len(prompt_for_input)} 字符")

                # 限制 prompt 的长度
                span_attributes[SpanAttributes.GEN_AI_PROMPT] = prompt_for_input

            logger.debug(f"[PID:{pid}] 请求参数提取完成，属性数量: {len(span_attributes)}")
            logger.debug(f"[PID:{pid}] Request parameters: {json.dumps(request_json, ensure_ascii=False)}")

            return span_name, span_attributes, is_chat, is_stream, request_json
        except Exception as e:
            logger.error(f"[PID:{pid}] Error extracting request parameters: {str(e)}", exc_info=True)
            logger.error(f"[PID:{pid}] 请求参数提取失败: {str(e)}")
            raise

    @stop_on_exception(default_return=(0, 0, {}))
    def _record_usage_statistics(self, usage):
        """记录使用统计信息

        Args:
            usage: usage数据对象

        Returns:
            tuple: (prompt_tokens, completion_tokens, attributes) 提取的token计数信息和需要设置的属性
        """
        prompt_tokens = 0
        completion_tokens = 0
        attributes = {}

        if hasattr(usage, "prompt_tokens"):
            prompt_tokens = usage.prompt_tokens
            attributes[SpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS] = usage.prompt_tokens
        if hasattr(usage, "completion_tokens"):
            completion_tokens = usage.completion_tokens
            attributes[SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS] = usage.completion_tokens
        if hasattr(usage, "total_tokens"):
            attributes[SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS] = usage.total_tokens

        return prompt_tokens, completion_tokens, attributes

    async def _create_instrumented_stream_generator(self, original_generator, span_name, span_attributes, pid,
                                                    wrapper_name):
        """创建一个包装了原始生成器的新生成器函数"""
        logger.debug(f"[PID:{pid}] {wrapper_name} 创建流式响应生成器")

        async def instrumented_stream_generator():
            logger.debug(f"[PID:{pid}] {wrapper_name} 流式生成器启动")
            stream_start_time = time.time()
            first_token_time = None
            total_tokens_streamed = 0
            prompt_tokens = 0
            completion_tokens = 0
            chunk_count = 0

            # 新增：记录埋点处理开销的总时间
            total_instrumentation_time = 0

            # 获取stream_interval参数
            stream_interval = 1  # 默认值
            if self.server_args_info and "stream_interval" in self.server_args_info:
                stream_interval = self.server_args_info["stream_interval"]
                logger.debug(f"[PID:{pid}] {wrapper_name} 使用server_args_info中的stream_interval: {stream_interval}")
            else:
                logger.debug(f"[PID:{pid}] {wrapper_name} 使用默认stream_interval: {stream_interval}")

            # 替换单一变量为按索引和类型存储输出的字典
            collected_outputs = {}
            tool_calls_detected = False
            # 推理过程追踪
            in_reasoning = True
            reasoning_start_time = time.time()
            reasoning_content = ""

            # 创建一个流式响应的span
            with self.tracer.start_as_current_span(
                    span_name,
                    attributes=span_attributes
            ) as span:
                try:
                    logger.debug(f"[PID:{pid}] {wrapper_name} 创建 span: {span_name}")
                    # 创建一个first_token span来追踪首个token的到达时间
                    first_token_span = self.tracer.start_span(
                        "first_token"
                    )
                    # 存储first_token_span的引用，以确保可以在后续关闭它
                    self.current_first_token_span = first_token_span

                    # 处理每个流式响应块
                    async for chunk in original_generator:
                        chunk_count += 1

                        try:
                            # 新增：记录埋点处理开始时间
                            instrumentation_start_time = time.time()

                            # 使用抽取的方法处理数据块
                            (first_token_time, in_reasoning, reasoning_content, reasoning_start_time,
                             total_tokens_streamed, tool_calls_detected_in_chunk, chunk_prompt_tokens,
                             chunk_completion_tokens) = self._process_chunk(
                                chunk, chunk_count, collected_outputs, span, first_token_time,
                                stream_start_time, in_reasoning, reasoning_start_time, reasoning_content,
                                total_tokens_streamed, stream_interval, pid, wrapper_name
                            )

                            # 更新token计数
                            if chunk_prompt_tokens > 0:
                                prompt_tokens = chunk_prompt_tokens
                            if chunk_completion_tokens > 0:
                                completion_tokens = chunk_completion_tokens
                            if tool_calls_detected_in_chunk:
                                tool_calls_detected = True

                            # 新增：计算埋点处理耗时并累加
                            instrumentation_end_time = time.time()
                            instrumentation_time = instrumentation_end_time - instrumentation_start_time
                            total_instrumentation_time += instrumentation_time
                        except Exception as e:
                            logger.error(f"[PID:{pid}] {wrapper_name} 埋点处理时发生错误: {str(e)}", exc_info=True)
                            # 继续执行，不影响业务逻辑
                            pass

                        # 直接传递chunk
                        yield chunk
                    try:
                        # 记录流式响应指标
                        stream_end_time = time.time()
                        total_duration = stream_end_time - stream_start_time
                        stream_metrics = {
                            VSpanAttributes.GEN_AI_LATENCY_E2E: total_duration,
                            GEN_AI_RESPONSE_TOKENS_STREAMED: total_tokens_streamed,
                        }
                        if completion_tokens == 0:
                            stream_metrics[SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS] = total_tokens_streamed
                            self.record_token_usage(self.get_model_name(), total_tokens_streamed, "output")

                        span.set_attributes(stream_metrics)
                        logger.debug(f"[PID:{pid}] {wrapper_name} 流式响应完成，总耗时: {total_duration:.3f}s")
                        logger.debug(f"[PID:{pid}] {wrapper_name} 共流式传输令牌数: {total_tokens_streamed}")

                        # 记录收集的输出内容，使用结构化格式
                        if collected_outputs:
                            logger.debug(
                                f"[PID:{pid}] {wrapper_name} 开始记录收集的输出内容，共 {len(collected_outputs)} 个选择")

                            total_length = 0
                            max_length = MAX_CONTENT_LENGTH - 3
                            # 记录结构化的输出内容
                            content_attributes = {}
                            for i, output in collected_outputs.items():
                                # 记录内容和角色
                                attributes, content_length = self._process_content_and_role(output, i)
                                content_attributes.update(attributes)
                                # 记录工具调用
                                if output["tool_calls"]:
                                    content_attributes.update(self._process_tool_calls(output, i))

                                # 如果已经超过最大长度限制，则不再添加新的内容
                                if total_length + content_length > max_length:
                                    break
                                total_length += content_length
                            span.set_attributes(content_attributes)
                            # 记录完整的输出值
                            output_value = json.dumps(content_attributes, ensure_ascii=False)
                            span.set_attribute(SpanAttributes.OUTPUT_VALUE, output_value)
                            logger.debug(f"[PID:{pid}] {wrapper_name} 已记录输出值，长度: {len(output_value)} 字符")
                        # 日志记录完整的性能信息
                        perf_metrics = {
                            "total_duration": total_duration,
                            "time_to_first_token": first_token_time - stream_start_time if first_token_time else None,
                            "tokens_streamed": total_tokens_streamed,
                            "prompt_tokens": prompt_tokens,
                            "completion_tokens": completion_tokens,
                            "total_chunks": chunk_count,
                            "choices_count": len(collected_outputs),
                            "has_tool_calls": tool_calls_detected
                        }

                        logger.debug(
                            f"[PID:{pid}] {wrapper_name} streaming completed: {json.dumps(perf_metrics, ensure_ascii=False)}")
                    except Exception as e:
                        pass
                except Exception as e:
                    logger.error(f"[PID:{pid}] {wrapper_name} error: {str(e)}", exc_info=True)
                    record_error(span, e)

                    # 确保任何尚未关闭的推理span都被正确关闭
                    if hasattr(self, 'current_reasoning_span') and self.current_reasoning_span:
                        try:
                            self.current_reasoning_span.set_status(Status(StatusCode.ERROR))
                            self.current_reasoning_span.set_attribute("error", str(e))
                            self.current_reasoning_span.end()
                            self.current_reasoning_span = None
                            logger.debug(f"[PID:{pid}] {wrapper_name} 在错误处理中关闭推理 span")
                        except Exception as span_e:
                            logger.error(f"[PID:{pid}] {wrapper_name} 关闭推理 span 失败: {str(span_e)}")

                    # 确保任何尚未关闭的首个token span都被正确关闭
                    if hasattr(self, 'current_first_token_span') and self.current_first_token_span:
                        try:
                            self.current_first_token_span.set_status(Status(StatusCode.ERROR))
                            self.current_first_token_span.set_attribute("error", str(e))
                            self.current_first_token_span.end()
                            self.current_first_token_span = None
                            logger.debug(f"[PID:{pid}] {wrapper_name} 在错误处理中关闭首个令牌等待 span")
                        except Exception as span_e:
                            logger.error(f"[PID:{pid}] {wrapper_name} 关闭首个令牌等待 span 失败: {str(span_e)}")

                    # 仍然需要在错误情况下结束流
                    yield "data: [DONE]\n\n"

                finally:
                    # 确保推理span在任何情况下都被关闭
                    if hasattr(self, 'current_reasoning_span') and self.current_reasoning_span:
                        try:
                            self.current_reasoning_span.end()
                            self._reset_reasoning_span()
                            logger.debug(f"[PID:{pid}] {wrapper_name} 在finally块中关闭推理 span")
                        except Exception as span_e:
                            logger.error(f"[PID:{pid}] {wrapper_name} 在finally块中关闭推理 span 失败: {str(span_e)}")

                    # 确保首个token span在任何情况下都被关闭
                    if hasattr(self, 'current_first_token_span') and self.current_first_token_span:
                        try:
                            self.current_first_token_span.end()
                            self.current_first_token_span = None
                            logger.debug(f"[PID:{pid}] {wrapper_name} 在finally块中关闭首个令牌等待 span")
                        except Exception as span_e:
                            logger.error(
                                f"[PID:{pid}] {wrapper_name} 在finally块中关闭首个令牌等待 span 失败: {str(span_e)}")

        logger.debug(f"[PID:{pid}] {wrapper_name} 流式响应生成器创建完成")
        return instrumented_stream_generator

    @stop_on_exception(default_return=(0, 0, {}))
    def _process_usage_info(self, usage):
        """处理数据块中的使用信息（usage）

        Args:
            usage: usage数据对象

        Returns:
            tuple: (prompt_tokens, completion_tokens, attributes) 提取的token计数信息和需要设置的属性
        """
        prompt_tokens = 0
        completion_tokens = 0
        attributes = {}

        # 添加判空检查，确保usage不为None
        if usage is None:
            return prompt_tokens, completion_tokens, attributes

        if "prompt_tokens" in usage:
            prompt_tokens = usage["prompt_tokens"]
            attributes[SpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS] = prompt_tokens
        if "completion_tokens" in usage:
            completion_tokens = usage["completion_tokens"]
            attributes[SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS] = completion_tokens
        if "total_tokens" in usage:
            total_tokens = usage["total_tokens"]
            attributes[SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS] = total_tokens

        return prompt_tokens, completion_tokens, attributes

    @stop_on_exception(default_return={})
    def _process_content_and_role(self, output, i):
        """处理输出中的内容和角色信息

        Args:
            output: 包含内容和角色的输出字典
            i: 当前处理的索引

        Returns:
            dict: 需要设置的属性字典
        """
        attributes = {}
        content_length = 0
        if output["content"]:
            content_key = f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.{MessageAttributes.MESSAGE_CONTENT}"
            role_key = f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.{MessageAttributes.MESSAGE_ROLE}"

            # 添加判空保护，确保role存在且不为空，否则使用默认值"assistant"
            role = output.get("role") or "assistant"
            trunc_content = self._truncate_string(output["content"])
            attributes[content_key] = trunc_content
            attributes[role_key] = role
            content_length = len(trunc_content)

        return attributes, content_length

    @stop_on_exception(default_return={})
    def _process_tool_calls(self, output, i):
        """处理输出中的工具调用

        Args:
            output: 包含工具调用的输出字典
            i: 当前处理的索引

        Returns:
            dict: 需要设置的属性字典
        """
        attributes = {}
        if output["tool_calls"]:
            for j, tool_call in enumerate(output["tool_calls"]):
                tool_call_base = f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.tool_calls.{j}"
                if "name" in tool_call:
                    attributes[f"{tool_call_base}.name"] = tool_call["name"]
                if "arguments" in tool_call:
                    attributes[f"{tool_call_base}.arguments"] = self._truncate_string(tool_call["arguments"])

        return attributes

    @stop_on_exception(default_return={})
    def _process_stream_tool_calls(self, choice, index, collected_outputs, pid, wrapper_name):
        """处理流式响应中的工具调用数据

        Args:
            choice: 当前选择对象
            index: 当前处理的索引
            collected_outputs: 收集的输出内容
            pid: 进程ID
            wrapper_name: 包装器名称，用于日志

        Returns:
            dict: 需要设置的span属性
        """
        if "delta" in choice and "tool_calls" in choice["delta"] and choice["delta"]["tool_calls"]:
            tool_calls = choice["delta"]["tool_calls"]
            tool_calls_count = len(tool_calls)
            logger.debug(f"[PID:{pid}] {wrapper_name} 发现工具调用，数量: {tool_calls_count}")

            # 收集工具调用内容
            for tool_call in tool_calls:
                if "function" in tool_call:
                    function = tool_call["function"]
                    tool_info = {}
                    if "name" in function:
                        tool_info["name"] = function["name"]
                    if "arguments" in function:
                        tool_info["arguments"] = function["arguments"]
                    collected_outputs[index]["tool_calls"].append(tool_info)
                    logger.debug(f"[PID:{pid}] {wrapper_name} 收集索引 {index} 的工具调用信息")

            # 返回需要设置的span属性
            return {
                GEN_AI_LLM_TOOL_CALL_DETECTED: True,
                GEN_AI_LLM_TOOL_CALLS_COUNT: tool_calls_count
            }
        return {}

    @stop_on_exception(default_return=None)
    def _process_reasoning_end(self, reasoning_end_time, reasoning_start_time, reasoning_content, span, pid,
                               wrapper_name):
        """处理推理结束时的逻辑，记录时间和内容信息

        Args:
            reasoning_end_time: 推理结束时间
            reasoning_start_time: 推理开始时间
            reasoning_content: 推理内容文本
            span: 当前活动的span
            pid: 进程ID
            wrapper_name: 包装器名称，用于日志
        """
        # 获取当前使用的模型名称
        model_name = self._get_span_attribute(span, SpanAttributes.GEN_AI_REQUEST_MODEL_NAME)

        # 只有当模型支持推理时才处理推理结束逻辑
        if not self._is_reasoning_supported(model_name=model_name):
            logger.debug(f"{wrapper_name} 当前模型不支持推理，跳过推理结束处理")
            return

        # 计算推理时间和内容大小
        reasoning_time = reasoning_end_time - reasoning_start_time
        reasoning_size = len(reasoning_content.encode('utf-8'))

        # 设置父span属性
        span.set_attribute(GEN_AI_RESPONSE_REASONING_TIME, reasoning_time)
        span.set_attribute(GEN_AI_RESPONSE_REASONING_CONTENT, reasoning_content)
        span.set_attribute(GEN_AI_RESPONSE_REASONING_CONTENT_SIZE, reasoning_size)

        # 结束reasoning span，设置相关属性
        if hasattr(self, 'current_reasoning_span') and self.current_reasoning_span:
            try:
                reasoning_span_attributes = {
                    GEN_AI_REASONING_CONTENT: reasoning_content,
                    GEN_AI_REASONING_DURATION: reasoning_time,
                    GEN_AI_REASONING_CONTENT_SIZE: reasoning_size,
                    GEN_AI_REASONING_END_MARKER: REASONING_END_MARKER,
                }
                self.current_reasoning_span.set_attributes(reasoning_span_attributes)
                self.current_reasoning_span.end()
                self._reset_reasoning_span()
                span.add_event("reasoning_ended")
                logger.debug(f"{wrapper_name} 结束推理 span，推理耗时: {reasoning_time:.3f}s")
            except Exception as e:
                logger.error(f"{wrapper_name} 结束推理 span 失败: {str(e)}")
        else:
            logger.warning(f"{wrapper_name} 未找到推理 span，可能是因为它已经被关闭或未创建")

        logger.debug(
            f"{wrapper_name} 检测到推理结束标记: {REASONING_END_MARKER}, 推理耗时: {reasoning_time:.3f}s, 内容大小: {reasoning_size} bytes")

    def _reset_reasoning_span(self):
        """重置当前的推理span引用

        在推理span结束后调用，确保推理span引用被正确清除
        """
        self.current_reasoning_span = None

    def record_token_usage(self, model_name: str, token_count: int, usage_type: str):
        """Record token usage metrics."""
        if model_name is None or (not isinstance(model_name, str)):
            model_name = self.get_model_name()
        try:
            arms_metrics = ArmsCommonServiceMetrics(self.meter)
            attr = get_llm_common_attributes()
            attr["modelName"] = model_name
            attr["spanKind"] = AliyunSpanKindValues.LLM.value
            attr["usageType"] = usage_type
            arms_metrics.llm_usage_tokens.add(
                token_count,
                attributes=attr
            )
        except Exception as e:
            logger.exception(f"Failed to record token usage metrics: {str(e)}")

    @stop_on_exception(default_return=(None, True, "", time.time(), 0, False, 0, 0))
    def _process_chunk(self, chunk, chunk_count, collected_outputs, span, first_token_time, stream_start_time,
                       in_reasoning, reasoning_start_time, reasoning_content, total_tokens_streamed,
                       stream_interval, pid, wrapper_name):
        """处理流式响应中的单个数据块

        Args:
            chunk: 数据块内容
            chunk_count: 当前处理的数据块计数
            collected_outputs: 收集的输出内容字典
            span: 当前活动的span
            first_token_time: 记录的首个令牌时间（可能为None）
            stream_start_time: 流式处理开始时间
            in_reasoning: 当前是否处于推理过程中
            reasoning_start_time: 推理开始时间
            reasoning_content: 已收集的推理内容
            total_tokens_streamed: 已流式传输的令牌总数
            stream_interval: 流式传输间隔
            pid: 进程ID，用于日志记录
            wrapper_name: 包装器名称，用于日志

        Returns:
            tuple: (first_token_time, in_reasoning, reasoning_content, reasoning_start_time, total_tokens_streamed, tool_calls_detected, prompt_tokens, completion_tokens)
                更新后的状态变量
        """
        tool_calls_detected = False
        prompt_tokens = 0
        completion_tokens = 0

        # 记录第一个token的时间
        if first_token_time is None:
            first_token_time = time.time()
            ttft = first_token_time - stream_start_time
            if hasattr(span, 'set_attribute'):
                span.set_attribute(VSpanAttributes.GEN_AI_LATENCY_TIME_TO_FIRST_TOKEN, ttft)
            logger.debug(f"[PID:{pid}] {wrapper_name} 收到第一个令牌，time to first token: {ttft:.3f}s")

            # 结束首个token span并记录相关属性
            if hasattr(self, 'current_first_token_span') and self.current_first_token_span:
                try:
                    if hasattr(self.current_first_token_span, 'set_attribute'):
                        self.current_first_token_span.set_attribute(GEN_AI_FIRST_TOKEN_DURATION, ttft)
                        self.current_first_token_span.set_attribute(GEN_AI_FIRST_TOKEN_ARRIVAL_TIME, first_token_time)
                    self.current_first_token_span.end()
                    self.current_first_token_span = None
                    logger.debug(f"[PID:{pid}] {wrapper_name} 结束首个令牌等待 span，耗时: {ttft:.3f}s")
                except Exception as e:
                    logger.error(f"[PID:{pid}] {wrapper_name} 结束首个令牌等待 span 失败: {str(e)}")

            # 创建一个 reasoning span 作为当前span的子span
            # 只有当模型支持推理时才创建推理span
            model_name = self._get_span_attribute(span, SpanAttributes.GEN_AI_REQUEST_MODEL_NAME)
            if self._is_reasoning_supported(model_name=model_name):
                reasoning_span = self.tracer.start_span(
                    "reasoning",
                    attributes={
                        SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
                        GEN_AI_REASONING_START_MARKER: REASONING_START_MARKER
                    }
                )
                # Store the reasoning_span reference at the class level to ensure it's available for cleanup
                self.current_reasoning_span = reasoning_span
                if hasattr(span, 'add_event'):
                    span.add_event("reasoning_started")
                logger.debug(f"[PID:{pid}] {wrapper_name} 创建推理 span")

        # 尝试解析JSON以提取token计数信息
        if chunk.startswith("data: ") and not chunk.startswith("data: [DONE]"):
            try:
                # 提取JSON部分
                json_str = chunk[6:].strip()
                chunk_data = json.loads(json_str)
                logger.debug(f"[PID:{pid}] {wrapper_name} 解析第 {chunk_count} 个数据块")

                # 捕获请求ID
                if "id" in chunk_data and chunk_count == 1:  # 通常第一个块包含ID信息
                    request_id = chunk_data["id"]
                    span.set_attribute(VSpanAttributes.GEN_AI_REQUEST_ID, request_id)
                    logger.debug(f"[PID:{pid}] {wrapper_name} 捕获请求ID: {request_id}")

                # 如果包含使用信息，提取token计数
                if "usage" in chunk_data:
                    prompt_tokens, completion_tokens, usage_attributes = self._process_usage_info(
                        chunk_data["usage"]
                    )
                    model_name = self.get_model_name()
                    self.record_token_usage(model_name, prompt_tokens, "input")
                    self.record_token_usage(model_name, completion_tokens, "output")
                    # 设置usage相关的属性
                    span.set_attributes(usage_attributes)

                # 从choices中提取内容
                if "choices" in chunk_data and chunk_data["choices"]:
                    choice_count = len(chunk_data["choices"])
                    logger.debug(f"[PID:{pid}] {wrapper_name} 数据块包含 {choice_count} 个选择")
                    for choice in chunk_data["choices"]:
                        index = choice.get("index", 0)
                        # 初始化该索引的输出收集
                        if index not in collected_outputs:
                            collected_outputs[index] = {
                                "content": "",
                                "role": "assistant",
                                "tool_calls": []
                            }

                        # 对于聊天完成
                        if "delta" in choice:
                            # 如果有角色信息，记录角色
                            if "role" in choice["delta"]:
                                # 添加对null/None角色的检查
                                if choice["delta"]["role"] is None:
                                    # 使用默认值
                                    collected_outputs[index]["role"] = "assistant"
                                    logger.debug(f"[PID:{pid}] {wrapper_name} 发现角色为null，使用默认值: assistant")
                                else:
                                    collected_outputs[index]["role"] = choice["delta"]["role"]
                                    logger.debug(f"[PID:{pid}] {wrapper_name} 收集角色信息: {choice['delta']['role']}")

                            # 收集内容文本
                            if "content" in choice["delta"] and choice["delta"]["content"]:
                                content = choice["delta"]["content"]
                                collected_outputs[index]["content"] += content
                                logger.debug(f"[PID:{pid}] {wrapper_name} 收集索引 {index} 的delta内容: {content}")
                                # 有文本内容的token，计数
                                total_tokens_streamed += stream_interval
                                logger.debug(f"[PID:{pid}] {wrapper_name} 发现delta内容，计数+{stream_interval}")

                                # 获取当前使用的模型名称
                                model_name = self._get_span_attribute(span, SpanAttributes.GEN_AI_REQUEST_MODEL_NAME)

                                # 只有当模型支持推理时才处理推理标记
                                if self._is_reasoning_supported(model_name=model_name):
                                    # 检测推理标记
                                    if REASONING_START_MARKER in content and not in_reasoning:
                                        in_reasoning = True
                                        reasoning_start_time = time.time()
                                        logger.debug(
                                            f"{wrapper_name} 检测到推理开始标记: {REASONING_START_MARKER}")
                                        # 提取推理内容开始部分
                                        reasoning_content += content

                                    elif REASONING_END_MARKER in content and in_reasoning:
                                        in_reasoning = False
                                        reasoning_end_time = time.time()
                                        # 提取推理内容结束部分
                                        reasoning_content += content

                                        # 处理推理结束
                                        self._process_reasoning_end(
                                            reasoning_end_time,
                                            reasoning_start_time,
                                            reasoning_content,
                                            span,
                                            pid,
                                            wrapper_name
                                        )

                                    elif in_reasoning:
                                        # 持续收集推理内容
                                        reasoning_content += content

                            # 对于工具调用
                            if "tool_calls" in choice["delta"] and choice["delta"]["tool_calls"]:
                                tool_calls_attributes = self._process_stream_tool_calls(
                                    choice,
                                    index,
                                    collected_outputs,
                                    pid,
                                    wrapper_name
                                )
                                if tool_calls_attributes:
                                    span.set_attributes(tool_calls_attributes)
                                    tool_calls_detected = True

                        # 对于文本完成
                        elif "text" in choice and choice["text"]:
                            # 收集内容
                            text = choice["text"]
                            collected_outputs[index]["content"] += text
                            logger.debug(f"[PID:{pid}] {wrapper_name} 收集索引 {index} 的文本内容: {text}")
                            # 有文本内容的token，计数
                            total_tokens_streamed += stream_interval
                            logger.debug(f"[PID:{pid}] {wrapper_name} 发现文本内容，计数+{stream_interval}")

                        # 检查是否已完成生成
                        if "finish_reason" in choice and choice["finish_reason"]:
                            span.set_attribute(GEN_AI_LLM_FINISH_REASON, choice["finish_reason"])
                            logger.debug(f"[PID:{pid}] {wrapper_name} 生成完成原因: {choice['finish_reason']}")
            except Exception as e:
                logger.warning(f"[PID:{pid}] Error parsing chunk: {str(e)}")
                logger.warning(f"[PID:{pid}] {wrapper_name} 解析数据块失败: {str(e)}")

        return (first_token_time, in_reasoning, reasoning_content, reasoning_start_time,
                total_tokens_streamed, tool_calls_detected, prompt_tokens, completion_tokens)

    @stop_on_exception(default_return={})
    def _extract_completion_attributes(self, response):
        """从完成响应中提取属性

        Args:
            response: 完成响应对象

        Returns:
            dict: 包含提取的属性的字典
        """
        attributes = {}

        # 提取请求ID
        if hasattr(response, "id"):
            attributes[VSpanAttributes.GEN_AI_REQUEST_ID] = response.id

        # 提取完成内容和结构化数据
        if hasattr(response, "choices"):
            # 文本补全模式
            completions = [choice.text if hasattr(choice, "text") else "" for choice in response.choices]

            # 构建输出值，在构建过程中就进行长度限制
            output_dict = {}
            total_length = 0
            max_length = MAX_CONTENT_LENGTH - 3

            for idx, completion in enumerate(completions):
                # 准备结构化的内容，使用与流式响应相同的格式
                content_key = f"{SpanAttributes.GEN_AI_COMPLETION}.{idx}.{MessageAttributes.MESSAGE_CONTENT}"
                role_key = f"{SpanAttributes.GEN_AI_COMPLETION}.{idx}.{MessageAttributes.MESSAGE_ROLE}"

                # 对内容进行截断
                truncated_content = self._truncate_string(completion)
                attributes[content_key] = truncated_content
                attributes[role_key] = "assistant"

                # 计算当前内容长度
                content_length = len(truncated_content)

                # 如果已经超过最大长度限制，则不再添加新的内容
                if total_length + content_length > max_length:
                    break

                # 添加到输出字典
                output_dict[str(idx)] = {"content": truncated_content}
                total_length += content_length

            # 如果内容被截断，添加省略号
            if total_length >= max_length:
                output_dict["truncated"] = True

            # 准备输出值
            output_value = json.dumps(output_dict, ensure_ascii=False)
            attributes[SpanAttributes.OUTPUT_VALUE] = output_value

        return attributes

    @stop_on_exception(default_return={})
    def _extract_chat_completion_attributes(self, response, is_chat):
        """从聊天完成响应中提取属性

        Args:
            response: 聊天完成响应对象
            is_chat: 是否是聊天模式

        Returns:
            dict: 包含提取的属性的字典
        """
        attributes = {}

        # 提取请求ID
        if hasattr(response, "id"):
            attributes[VSpanAttributes.GEN_AI_REQUEST_ID] = response.id

        # 处理完成内容
        if hasattr(response, "choices"):
            if is_chat:
                # 聊天模式
                output_dict = {}
                has_tool_calls = False
                total_length = 0
                max_length = MAX_CONTENT_LENGTH - 3

                for idx, choice in enumerate(response.choices):
                    # 准备角色和内容
                    role = "assistant"
                    content = choice.message.content if hasattr(choice.message,
                                                                "content") and choice.message.content is not None else ""

                    # 对内容进行截断
                    truncated_content = self._truncate_string(content)

                    # 添加结构化的内容属性
                    content_key = f"{SpanAttributes.GEN_AI_COMPLETION}.{idx}.{MessageAttributes.MESSAGE_CONTENT}"
                    role_key = f"{SpanAttributes.GEN_AI_COMPLETION}.{idx}.{MessageAttributes.MESSAGE_ROLE}"

                    attributes[content_key] = truncated_content
                    attributes[role_key] = role

                    # 计算当前内容长度
                    content_length = len(truncated_content)

                    # 如果已经超过最大长度限制，则不再添加新的内容
                    if total_length + content_length > max_length:
                        break

                    # 准备输出字典
                    output_entry = {"role": role}
                    if truncated_content:
                        output_entry["content"] = truncated_content
                        total_length += content_length

                    # 处理工具调用
                    if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                        has_tool_calls = True
                        tool_calls_data = []

                        for j, tool_call in enumerate(choice.message.tool_calls):
                            tool_call_entry = {}
                            if hasattr(tool_call, "function"):
                                function_data = {}
                                if hasattr(tool_call.function, "name"):
                                    function_data["name"] = tool_call.function.name
                                    # 添加工具调用名称属性
                                    attributes[
                                        f"{SpanAttributes.GEN_AI_COMPLETION}.{idx}.tool_calls.{j}.name"] = tool_call.function.name

                                if hasattr(tool_call.function, "arguments"):
                                    # 对参数进行截断
                                    truncated_arguments = self._truncate_string(tool_call.function.arguments)
                                    function_data["arguments"] = truncated_arguments
                                    # 添加工具调用参数属性
                                    attributes[
                                        f"{SpanAttributes.GEN_AI_COMPLETION}.{idx}.tool_calls.{j}.arguments"] = truncated_arguments

                                tool_call_entry["function"] = function_data
                            tool_calls_data.append(tool_call_entry)

                        output_entry["tool_calls"] = tool_calls_data

                    output_dict[str(idx)] = output_entry

                # 如果有工具调用，添加标志
                if has_tool_calls:
                    attributes[GEN_AI_LLM_HAS_TOOL_CALLS] = True

                # 如果内容被截断，添加省略号
                if total_length >= max_length:
                    output_dict["truncated"] = True

                # 准备输出值
                output_value = json.dumps(output_dict, ensure_ascii=False)
                attributes[SpanAttributes.OUTPUT_VALUE] = output_value

            else:
                # 文本补全模式 - 复用已有的提取方法
                return self._extract_completion_attributes(response)

        return attributes
