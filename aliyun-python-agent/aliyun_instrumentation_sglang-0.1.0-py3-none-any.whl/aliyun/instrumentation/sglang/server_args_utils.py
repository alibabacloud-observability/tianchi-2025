"""
服务器参数管理工具，提供跨进程共享配置的功能。
"""

import os
import tempfile
import pickle
import json
from aliyun.sdk.extension.arms.logger import getLogger

# 配置日志记录器
logger = getLogger(__name__)

# 定义server_args文件路径
_SERVER_ARGS_FILE = os.path.join(tempfile.gettempdir(), 'sglang_server_args.pkl')


def save_server_args_to_file(info, pid):
    """将server_args信息序列化并保存到文件，用于跨进程共享

    Args:
        info: 要保存的server_args信息字典
        pid: 进程ID，用于日志记录

    Returns:
        bool: 是否成功保存
    """
    try:
        with open(_SERVER_ARGS_FILE, 'wb') as f:
            pickle.dump(info, f)
        logger.debug(f"[PID:{pid}] 成功将server_args信息保存到文件: {_SERVER_ARGS_FILE}")
        return True
    except Exception as e:
        logger.error(f"[PID:{pid}] 保存server_args到文件失败: {str(e)}")
        return False


def load_server_args_from_file(pid):
    """从文件加载server_args信息，用于跨进程共享

    Args:
        pid: 进程ID，用于日志记录

    Returns:
        dict 或 None: 加载的server_args信息，如果加载失败则返回None
    """
    try:
        if os.path.exists(_SERVER_ARGS_FILE):
            with open(_SERVER_ARGS_FILE, 'rb') as f:
                info = pickle.load(f)
            logger.debug(f"[PID:{pid}] 从文件成功加载 server_args_info: {info}")
            return info
        else:
            logger.debug(f"[PID:{pid}] 文件 {_SERVER_ARGS_FILE} 不存在，无法加载 server_args_info")
            return None
    except Exception as e:
        logger.warning(f"[PID:{pid}] 从文件加载 server_args_info 失败: {str(e)}")
        return None


def extract_server_args_info(server_args, pid):
    """
    从server_args对象中提取关键信息 Args: server_args: 服务器参数对象,
        example: server_args=ServerArgs(
        model_path='deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B',
        tokenizer_path='deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B', tokenizer_mode='auto', skip_tokenizer_init=False,
        load_format='auto', trust_remote_code=False, dtype='auto', kv_cache_dtype='auto', quantization=None,
        quantization_param_path=None, context_length=None, device='cuda',
        served_model_name='deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B', chat_template=None, completion_template=None,
        is_embedding=False, revision=None, host='127.0.0.1', port=30000, mem_fraction_static=0.88,
        max_running_requests=None, max_total_tokens=None, chunked_prefill_size=2048, max_prefill_tokens=16384,
        schedule_policy='fcfs', schedule_conservativeness=1.0, cpu_offload_gb=0, page_size=1, tp_size=1,
        stream_interval=4, stream_output=False, random_seed=179840614, constrained_json_whitespace_pattern=None,
        watchdog_timeout=300, dist_timeout=None, download_dir=None, base_gpu_id=0, gpu_id_step=1, log_level='info',
        log_level_http=None, log_requests=False, log_requests_level=0, show_time_cost=False, enable_metrics=False,
        decode_log_interval=40, api_key=None, file_storage_path='sglang_storage', enable_cache_report=False,
        reasoning_parser=None, dp_size=1, load_balance_method='round_robin', ep_size=1, dist_init_addr=None, nnodes=1,
        node_rank=0, json_model_override_args='{}', lora_paths=None, max_loras_per_batch=8, lora_backend='triton',
        attention_backend='flashinfer', sampling_backend='flashinfer', grammar_backend='xgrammar',
        speculative_algorithm=None, speculative_draft_model_path=None, speculative_num_steps=5, speculative_eagle_topk=4,
        speculative_num_draft_tokens=8, speculative_accept_threshold_single=1.0, speculative_accept_threshold_acc=1.0,
        speculative_token_map=None, enable_double_sparsity=False, ds_channel_config_path=None, ds_heavy_channel_num=32,
        ds_heavy_token_num=256, ds_heavy_channel_type='qk', ds_sparse_decode_threshold=4096, disable_radix_cache=False,
        disable_cuda_graph=False, disable_cuda_graph_padding=False, enable_nccl_nvls=False,
        disable_outlines_disk_cache=False, disable_custom_all_reduce=False, disable_mla=False,
        disable_overlap_schedule=False, enable_mixed_chunk=False, enable_dp_attention=False, enable_ep_moe=False,
        enable_deepep_moe=False, enable_torch_compile=False, torch_compile_max_bs=32, cuda_graph_max_bs=8,
        cuda_graph_bs=None, torchao_config='', enable_nan_detection=False, enable_p2p_check=False,
        triton_attention_reduce_in_fp32=False, triton_attention_num_kv_splits=8, num_continuous_decode_steps=1,
        delete_ckpt_after_loading=False, enable_memory_saver=False, allow_auto_truncate=False,
        enable_custom_logit_processor=False, tool_call_parser=None, enable_hierarchical_cache=False, hicache_ratio=2.0,
        enable_flashinfer_mla=False, enable_flashmla=False, flashinfer_mla_disable_ragged=False, warmups=None,
        debug_tensor_dump_output_folder=None, debug_tensor_dump_input_file=None, debug_tensor_dump_inject=False,
        disaggregation_mode='null', disaggregation_bootstrap_port=8998)
    pid: 进程ID，用于日志记录

    Returns:
        dict: 包含提取的信息的字典
    """
    info = {}
    try:
        if hasattr(server_args, "max_parallel_requests"):
            info["max_parallel_requests"] = server_args.max_parallel_requests
        if hasattr(server_args, "max_num_batched_tokens"):
            info["max_num_batched_tokens"] = server_args.max_num_batched_tokens
        # 流式传输和模型参数
        if hasattr(server_args, "stream_interval"):
            info["stream_interval"] = server_args.stream_interval
        else:
            # 如果没有设置 stream_interval，默认为 1
            info["stream_interval"] = 1
            logger.debug(f"[PID:{pid}] stream_interval 未设置，使用默认值 1")

        if hasattr(server_args, "served_model_name"):
            info["served_model_name"] = server_args.served_model_name
        if hasattr(server_args, "chunked_prefill_size"):
            info["chunked_prefill_size"] = server_args.chunked_prefill_size
        if hasattr(server_args, "max_prefill_tokens"):
            info["max_prefill_tokens"] = server_args.max_prefill_tokens

        logger.debug(f"[PID:{pid}] 成功提取server_args信息: {json.dumps(info)}")
    except Exception as e:
        logger.warning(f"[PID:{pid}] 提取server_args信息时出错: {str(e)}")

    return info
