"""
Metrics instrumentation implementation for SGLang.
"""

import time
from typing import Any, Callable, Mapping, Tuple, Union
from opentelemetry.metrics import get_meter
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.semconv.metrics import MetricUnit
from aliyun.sdk.extension.arms.common.utils.metrics_utils import get_llm_common_attributes
from .utils import is_instrumentation_enabled
from .constants import (
    METRIC_NUM_RUNNING_REQS,
    METRIC_LOG_COUNT,
    METRIC_NUM_USED_TOKENS,
    METRIC_TOKEN_USAGE,
    METRIC_GEN_THROUGHPUT,
    METRIC_NUM_QUEUE_REQS,
    METRIC_CACHE_HIT_RATE,
    METRIC_SPEC_ACCEPT_LENGTH,
    METRIC_PROMPT_TOKENS_TOTAL,
    METRIC_GENERATION_TOKENS_TOTAL,
    METRIC_NUM_REQUESTS_TOTAL,
    METRIC_TIME_TO_FIRST_TOKEN,
    METRIC_TIME_PER_OUTPUT_TOKEN,
    METRIC_E2E_REQUEST_LATENCY,
    METRIC_CACHED_TOKENS_TOTAL,
    METRIC_TIME_INTER_TOKEN_LATENCY_SECONDS,
)

# Configure logging
logger = getLogger(__name__)

# Import SGLang metrics classes with try-catch protection
try:
    from sglang.srt.metrics.collector import SchedulerMetricsCollector, SchedulerStats, TokenizerMetricsCollector

    HAS_SCHEDULER_METRICS = True
    HAS_SCHEDULER_STATS = True
    HAS_TOKENIZER_METRICS = True
except ImportError as e:
    logger.warning(f"Failed to import SGLang metrics classes: {str(e)}")
    HAS_SCHEDULER_METRICS = False
    HAS_SCHEDULER_STATS = False
    HAS_TOKENIZER_METRICS = False


class MetricsWrapper:
    """Wrapper class for SGLang metrics instrumentation."""

    def __init__(self):
        self.meter = get_meter(
            __name__,
            "0.1.0",
            None,
            schema_url="https://opentelemetry.io/schemas/1.11.0",
        )
        self.last_log_time = time.time()
        logger.info("Initializing MetricsWrapper")
        self._setup_metrics()

    def _setup_metrics(self):
        """Setup all the metrics gauges."""
        # Create gauge metrics
        self.num_running_reqs = self.meter.create_counter(
            name=METRIC_NUM_RUNNING_REQS,
            description="Number of currently running requests",
            unit=MetricUnit.COUNT
        )
        self.log_count = self.meter.create_counter(
            name=METRIC_LOG_COUNT,
            description="Count of log stats",
            unit=MetricUnit.COUNT
        )
        self.num_used_tokens = self.meter.create_counter(
            name=METRIC_NUM_USED_TOKENS,
            description="Number of tokens currently in use",
            unit=MetricUnit.COUNT
        )
        self.token_usage = self.meter.create_counter(
            name=METRIC_TOKEN_USAGE,
            description="Token usage ratio",
            unit=MetricUnit.COUNT
        )
        self.gen_throughput = self.meter.create_counter(
            name=METRIC_GEN_THROUGHPUT,
            description="Generation throughput in tokens per second",
            unit=MetricUnit.COUNT
        )
        self.num_queue_reqs = self.meter.create_counter(
            name=METRIC_NUM_QUEUE_REQS,
            description="Number of requests in queue",
            unit=MetricUnit.COUNT
        )
        self.cache_hit_rate = self.meter.create_counter(
            name=METRIC_CACHE_HIT_RATE,
            description="Cache hit rate",
            unit=MetricUnit.COUNT
        )
        self.spec_accept_length = self.meter.create_counter(
            name=METRIC_SPEC_ACCEPT_LENGTH,
            description="Speculative accept length",
            unit=MetricUnit.COUNT
        )

        # Add TokenizerMetricsCollector metrics
        self.prompt_tokens_total = self.meter.create_counter(
            name=METRIC_PROMPT_TOKENS_TOTAL,
            description="Total number of prompt tokens",
            unit=MetricUnit.COUNT
        )
        self.generation_tokens_total = self.meter.create_counter(
            name=METRIC_GENERATION_TOKENS_TOTAL,
            description="Total number of generation tokens",
            unit=MetricUnit.COUNT
        )
        self.num_requests_total = self.meter.create_counter(
            name=METRIC_NUM_REQUESTS_TOTAL,
            description="Total number of requests",
            unit=MetricUnit.COUNT
        )
        self.cached_tokens_total = self.meter.create_counter(
            name=METRIC_CACHED_TOKENS_TOTAL,
            description="Number of cached prompt tokens.",
            unit=MetricUnit.COUNT
        )
        self.time_to_first_token = self.meter.create_counter(
            name=METRIC_TIME_TO_FIRST_TOKEN,
            description="Time to first token in seconds",
            unit=MetricUnit.S
        )
        self.time_per_output_token = self.meter.create_counter(
            name=METRIC_TIME_PER_OUTPUT_TOKEN,
            description="Time per output token in seconds",
            unit=MetricUnit.S
        )
        self.inter_token_latency_seconds = self.meter.create_counter(
            name=METRIC_TIME_INTER_TOKEN_LATENCY_SECONDS,
            description="Time inter-token latency in seconds",
            unit=MetricUnit.S
        )
        self.e2e_request_latency = self.meter.create_counter(
            name=METRIC_E2E_REQUEST_LATENCY,
            description="End-to-end request latency in seconds",
            unit=MetricUnit.S
        )

    def _log_gauge(self, metric, value: Union[float, int]):
        """Log a gauge metric with common attributes."""
        try:
            attr = get_llm_common_attributes()
            metric.add(value, attributes=attr)
        except Exception as e:
            logger.exception(f"Failed to log gauge metric: {str(e)}")

    def observe_one_finished_request(self, prompt_tokens: int, generation_tokens: int, cached_tokens: int,
                                     e2e_latency: float):
        """Observe metrics for a finished request."""
        try:
            attr = get_llm_common_attributes()
            self.prompt_tokens_total.add(prompt_tokens, attributes=attr)
            self.generation_tokens_total.add(generation_tokens, attributes=attr)
            self.cached_tokens_total.add(cached_tokens, attributes=attr)
            self.num_requests_total.add(1, attributes=attr)
            if generation_tokens >= 1:
                self._log_gauge(self.time_per_output_token, e2e_latency / generation_tokens)
        except Exception as e:
            logger.warning(f"Failed to observe finished request metrics: {str(e)}")

    def observe_time_to_first_token(self, value: Union[float, int]):
        """Observe time to first token metric."""
        self._log_gauge(self.time_to_first_token, value)

    def observe_inter_token_latency(self, value: Union[float, int]):
        """Observe time per output token metric."""
        self._log_gauge(self.inter_token_latency_seconds, value)

    def observe_e2e_request_latency(self, value: Union[float, int]):
        """Observe end-to-end request latency metric."""
        self._log_gauge(self.e2e_request_latency, value)

    def log_stats(self, stats: Any):
        """Log statistics metrics.

        Args:
            stats: Stats object containing statistics
        """
        try:
            self._log_gauge(self.num_running_reqs, stats.num_running_reqs)
            self._log_gauge(self.num_used_tokens, stats.num_used_tokens)
            self._log_gauge(self.token_usage, stats.token_usage)
            self._log_gauge(self.gen_throughput, stats.gen_throughput)
            self._log_gauge(self.num_queue_reqs, stats.num_queue_reqs)
            self._log_gauge(self.log_count, 1)
            if hasattr(stats, 'cache_hit_rate'):
                self._log_gauge(self.cache_hit_rate, stats.cache_hit_rate)
            self._log_gauge(self.spec_accept_length, stats.spec_accept_length)
            self.last_log_time = time.time()
            logger.debug(f"Successfully logged statistics metrics: running_reqs={stats.num_running_reqs}, "
                         f"used_tokens={stats.num_used_tokens}, token_usage={stats.token_usage}, "
                         f"gen_throughput={stats.gen_throughput}, queue_reqs={stats.num_queue_reqs}")
        except Exception as e:
            logger.exception(f"Failed to log statistics: {str(e)}")


class StatsWrapper:
    """Wrapper for statistics logging."""

    def __init__(self):
        self.metrics_wrapper = MetricsWrapper()

    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """主入口方法，协调统计信息收集流程"""
        if not self._should_instrument():
            return wrapped(*args, **kwargs)

        result = self._call_wrapped_function(wrapped, args, kwargs)

        try:
            stats = self._get_or_initialize_stats(instance)
            if stats:
                self._log_statistics(stats)
        except Exception as e:
            logger.exception(f"exception in StatsWrapper: {str(e)}")

        return result

    def _should_instrument(self) -> bool:
        """检查是否应该启用埋点功能"""
        return is_instrumentation_enabled()

    def _call_wrapped_function(
            self,
            wrapped: Callable[..., Any],
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """调用被包装的原始函数"""
        return wrapped(*args, **kwargs)

    def _get_or_initialize_stats(self, instance: Any) -> Any:
        """获取或初始化统计信息对象"""
        stats = None

        # Get or calculate stats based on enable_metrics
        if self._has_existing_stats(instance):
            stats = instance.stats
        else:
            self._initialize_metrics_if_available(instance)
            self._initialize_stats_if_available(instance)
            if hasattr(instance, 'stats'):
                stats = instance.stats

        return stats

    def _has_existing_stats(self, instance: Any) -> bool:
        """检查实例是否已有统计信息"""
        return getattr(instance, 'enable_metrics', False) and hasattr(instance, 'stats')

    def _initialize_metrics_if_available(self, instance: Any) -> None:
        """如果可用则初始化指标收集器"""
        if HAS_SCHEDULER_METRICS:
            # Auto enable metrics and initialize collector
            instance.enable_metrics = True
            instance.metrics_collector = SchedulerMetricsCollector(
                labels={
                    "model_name": instance.server_args.served_model_name,
                }
            )

    def _initialize_stats_if_available(self, instance: Any) -> None:
        """如果可用则初始化统计信息"""
        if HAS_SCHEDULER_STATS and instance.stats is None:
            instance.stats = SchedulerStats()

    def _log_statistics(self, stats: Any) -> None:
        """记录统计信息"""
        self.metrics_wrapper.log_stats(stats)


class TokenizerMetricsWrapper:
    """Wrapper for tokenizer metrics logging."""

    def __init__(self):
        self.metrics_wrapper = MetricsWrapper()

    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """主入口方法，协调tokenizer指标收集流程"""
        if not self._should_instrument():
            return wrapped(*args, **kwargs)

        result = self._call_wrapped_function(wrapped, args, kwargs)

        try:
            method_name = self._get_method_name(wrapped)
            self._handle_method_metrics(method_name, args)
        except Exception as e:
            logger.exception(f"exception in TokenizerMetricsWrapper: {str(e)}")

        return result

    def _should_instrument(self) -> bool:
        """检查是否应该启用埋点功能"""
        return is_instrumentation_enabled()

    def _call_wrapped_function(
            self,
            wrapped: Callable[..., Any],
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """调用被包装的原始函数"""
        return wrapped(*args, **kwargs)

    def _get_method_name(self, wrapped: Callable[..., Any]) -> str:
        """获取被包装方法的名称"""
        return wrapped.__name__

    def _handle_method_metrics(self, method_name: str, args: Tuple[Any, ...]) -> None:
        """根据方法名称处理不同的指标"""
        if method_name == 'observe_one_finished_request':
            self._handle_finished_request_metrics(args)
        elif method_name == 'observe_time_to_first_token':
            self._handle_time_to_first_token_metrics(args)
        elif method_name == 'observe_inter_token_latency':
            self._handle_inter_token_latency_metrics(args)

    def _handle_finished_request_metrics(self, args: Tuple[Any, ...]) -> None:
        """处理完成请求的指标"""
        prompt_tokens, generation_tokens, cached_tokens, e2e_latency = args[0], args[1], args[2], args[3]
        self.metrics_wrapper.observe_one_finished_request(
            prompt_tokens, generation_tokens, cached_tokens, e2e_latency
        )

    def _handle_time_to_first_token_metrics(self, args: Tuple[Any, ...]) -> None:
        """处理首个token时间指标"""
        value = args[0]
        self.metrics_wrapper.observe_time_to_first_token(value)

    def _handle_inter_token_latency_metrics(self, args: Tuple[Any, ...]) -> None:
        """处理token间延迟指标"""
        value = args[0]
        self.metrics_wrapper.observe_inter_token_latency(value)
