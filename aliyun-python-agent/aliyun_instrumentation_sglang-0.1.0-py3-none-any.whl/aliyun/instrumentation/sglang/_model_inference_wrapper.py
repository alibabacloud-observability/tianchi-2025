"""
Instrumentation implementation for SGLang.
"""
import time
import os
from aliyun.sdk.extension.arms.logger import getLogger
import json
from typing import Any, Callable, Dict, Optional, Mapping, Tuple

from opentelemetry import trace
from opentelemetry.metrics import get_meter
from aliyun.semconv.trace import (
    AliyunSpanKindValues,
    SpanAttributes,
    VSpanAttributes,
)
from .utils import (
    is_instrumentation_enabled,
    record_error,
)
from ._wrapper import BaseWrapper
from .chunk_timing_stats import ChunkTimingStats
from .constants import (
    METRIC_ATTRIBUTES_DEFAULT,
    GEN_AI_LLM_RESPONSE_CHUNK_COUNT,
    GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_AVG,
    GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_MAX,
    GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_MIN,
    GEN_AI_LLM_MEAN_ITL,
    GEN_AI_LLM_MEAN_TPOT,
)
from .stop_on_exception import stop_on_exception

# Configure logging
logger = getLogger(__name__)

# Use try/except to import SGLang-specific types
try:
    from sglang.srt.metrics.collector import TokenizerMetricsCollector
    HAS_TOKENIZER_METRICS = True
except ImportError:
    logger.warning("Import SGLang API failed. Make sure SGLang is installed properly.")
    HAS_TOKENIZER_METRICS = False


class ModelInferenceWrapper(BaseWrapper):
    """Wrapper for model inference."""

    def __init__(self, tracer):
        super().__init__(tracer)
        self.meter = get_meter(
            __name__,
            schema_url="https://opentelemetry.io/schemas/1.11.0",
        )

        # Initialize counters for key metrics
        self.metrics_attributes = METRIC_ATTRIBUTES_DEFAULT

    @stop_on_exception(default_return=None)
    def _init_metrics_if_needed(self, instance: Any) -> None:
        """Initialize metrics collector if needed and available.

        Args:
            instance: The instance to initialize metrics for.
        """
        if not getattr(instance, 'enable_metrics', False) and HAS_TOKENIZER_METRICS:
            instance.metrics_collector = TokenizerMetricsCollector(
                labels={
                    "model_name": instance.server_args.served_model_name,
                }
            )
            instance.enable_metrics = True
            logger.info("Initializing metrics collector.")

    def _get_stream_interval(self, pid: int) -> int:
        """Get stream interval from server args info.

        Args:
            pid: Process ID for logging

        Returns:
            Stream interval value
        """
        stream_interval = 1  # 默认值
        if self.server_args_info and "stream_interval" in self.server_args_info:
            stream_interval = self.server_args_info["stream_interval"]
            logger.debug(f"[PID:{pid}]使用server_args_info中的stream_interval: {stream_interval}")
        else:
            logger.debug(f"[PID:{pid}]使用默认stream_interval: {stream_interval}")
        return stream_interval

    def _create_inference_span(self):
        """Create a new inference span.

        Returns:
            The created span
        """
        return self.tracer.start_span(
            "model.inference",
            attributes={
                SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            }
        )

    def _record_first_token_metrics(self, span, timing_stats, start_time: float, pid: int):
        """Record first token metrics.

        Args:
            span: The span to record metrics on
            timing_stats: ChunkTimingStats instance
            start_time: Request start time
            pid: Process ID for logging
        """
        time_to_first_token = timing_stats.get_time_to_first_token(start_time)
        if time_to_first_token is not None:
            span.set_attribute(
                VSpanAttributes.GEN_AI_LATENCY_TIME_TO_FIRST_TOKEN,
                time_to_first_token
            )
            logger.debug(f"[PID:{pid}] ModelInferenceWrapper time to first token: {time_to_first_token:.3f}s")

    def _record_chunk_interval_metrics(self, span, timing_stats, pid: int, interval: float):
        """Record chunk interval metrics.

        Args:
            span: The span to record metrics on
            timing_stats: ChunkTimingStats instance
            pid: Process ID for logging
            interval: Current chunk interval
        """
        if interval is not None:
            logger.debug(
                f"[PID:{pid}] ModelInferenceWrapper 数据块 {timing_stats.chunk_count} 间隔时间: {interval:.3f}s")

    def _calculate_and_record_chunk_statistics(self, span, timing_stats, stream_interval: int, pid: int):
        """Calculate and record chunk timing statistics.

        Args:
            span: The span to record metrics on
            timing_stats: ChunkTimingStats instance
            stream_interval: Stream interval value
            pid: Process ID for logging
        """
        avg_interval = timing_stats.calculate_avg_interval()
        if avg_interval is not None:
            # 计算平均ITL (Inter-Token Latency)
            total_tokens = stream_interval * timing_stats.chunk_count
            mean_itl = timing_stats.total_interval / total_tokens
            span.set_attribute(GEN_AI_LLM_MEAN_ITL, mean_itl)
            span.set_attribute(GEN_AI_LLM_MEAN_TPOT, mean_itl)  # TPOT取值与ITL相同

            # 记录数据块统计数据
            span.set_attribute(GEN_AI_LLM_RESPONSE_CHUNK_COUNT, timing_stats.chunk_count)
            span.set_attribute(GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_AVG, avg_interval)
            span.set_attribute(GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_MAX, timing_stats.max_interval)
            # 确保最小间隔有效
            min_interval = timing_stats.get_min_interval()
            if min_interval is not None:
                span.set_attribute(GEN_AI_LLM_RESPONSE_CHUNK_INTERVAL_MIN, min_interval)

            logger.debug(
                f"[PID:{pid}] ModelInferenceWrapper 响应数据块统计: 总数={timing_stats.chunk_count}, 平均间隔={avg_interval:.3f}s, 最大间隔={timing_stats.max_interval:.3f}s, 最小间隔={min_interval if min_interval is not None else 'N/A'}s")

    def _record_latency_metrics(self, span, start_time: float, pid: int):
        """Record latency metrics.

        Args:
            span: The span to record metrics on
            start_time: Request start time
            pid: Process ID for logging

        Returns:
            Total latency
        """
        latency = time.time() - start_time
        span.set_attribute(VSpanAttributes.GEN_AI_LATENCY_E2E, latency)
        logger.debug(f"[PID:{pid}] ModelInferenceWrapper end-to-end latency: {latency:.3f}s")
        return latency

    def _record_model_timing_metrics(self, span, instance: Any, pid: int):
        """Record model execution and forward timing metrics.

        Args:
            span: The span to record metrics on
            instance: Model instance
            pid: Process ID for logging
        """
        # Record model execution time
        if hasattr(instance, "model_execute_time"):
            model_execute_time = instance.model_execute_time
            span.set_attribute(
                VSpanAttributes.GEN_AI_LATENCY_TIME_IN_MODEL_EXECUTE,
                model_execute_time
            )
            logger.debug(f"[PID:{pid}] ModelInferenceWrapper model execute time: {model_execute_time:.3f}s")

        # Record model forward time
        if hasattr(instance, "model_forward_time"):
            model_forward_time = instance.model_forward_time
            span.set_attribute(
                VSpanAttributes.GEN_AI_LATENCY_TIME_IN_MODEL_FORWARD,
                model_forward_time
            )
            logger.debug(f"[PID:{pid}] ModelInferenceWrapper model forward time: {model_forward_time:.3f}s")

    def _log_span_attributes(self, timing_stats, latency: float, instance: Any, pid: int):
        """Log all span attributes for debugging.

        Args:
            timing_stats: ChunkTimingStats instance
            latency: Total latency
            instance: Model instance
            pid: Process ID for logging
        """
        time_to_first_token = timing_stats.get_time_to_first_token(0)  # We don't have start_time here
        avg_interval = timing_stats.calculate_avg_interval()

        span_attrs = {
            "latency_e2e": latency,
            "time_to_first_token": time_to_first_token,
            "model_execute_time": getattr(instance, "model_execute_time", None),
            "model_forward_time": getattr(instance, "model_forward_time", None),
            "response_chunk_count": timing_stats.chunk_count,
            "response_chunk_interval_avg": avg_interval,
            "response_chunk_interval_max": timing_stats.max_interval,
            "response_chunk_interval_min": timing_stats.get_min_interval()
        }
        logger.debug(
            f"[PID:{pid}] ModelInferenceWrapper span attributes: {json.dumps(span_attrs, ensure_ascii=False)}")

    async def _process_generator_with_instrumentation(self, generator, span, timing_stats, start_time: float, stream_interval: int, pid: int):
        """Process the generator and record instrumentation data.

        Args:
            generator: The async generator to process
            span: The span to record metrics on
            timing_stats: ChunkTimingStats instance
            start_time: Request start time
            stream_interval: Stream interval value
            pid: Process ID for logging

        Yields:
            Results from the generator
        """
        async for result in generator:
            current_time = time.time()
            timing_stats.increment_chunk_count()

            # 更新数据块时间统计
            is_first_token, time_to_first_token, interval = timing_stats.update_with_current_time(current_time, start_time)

            # 在外层处理span和指标记录
            if is_first_token and time_to_first_token is not None:
                self._record_first_token_metrics(span, timing_stats, start_time, pid)

            # 记录数据块间隔时间的日志
            self._record_chunk_interval_metrics(span, timing_stats, pid, interval)

            yield result

    def _handle_exception(self, span, exception: Exception, pid: int):
        """Handle exceptions during processing.

        Args:
            span: The span to record error on
            exception: The exception that occurred
            pid: Process ID for logging
        """
        logger.error(f"[PID:{pid}] ModelInferenceWrapper error: {str(exception)}")
        record_error(span, exception)

    def _prepare_instrumentation_context(self, args, kwargs):
        """Prepare the instrumentation context and parameters.

        Args:
            args: Function arguments
            kwargs: Function keyword arguments

        Returns:
            Tuple of (start_time, pid, stream_interval, span)
        """
        start_time = time.time()
        pid = os.getpid()
        logger.debug(f"[PID:{pid}] ModelInferenceWrapper input parameters: args={args}, kwargs={kwargs}")

        # Get stream interval parameter
        stream_interval = self._get_stream_interval(pid)

        # Create span but don't use context manager to avoid GeneratorExit issues
        span = self._create_inference_span()

        return start_time, pid, stream_interval, span

    def _setup_span_context(self, span):
        """Set up the span context.

        Args:
            span: The span to set as current

        Returns:
            The context token
        """
        return trace.set_span_in_context(span)

    async def _process_wrapped_generator(self, wrapped, args, kwargs, span, timing_stats, start_time, stream_interval, pid):
        """Process the wrapped generator with instrumentation.

        Args:
            wrapped: The wrapped function
            args: Function arguments
            kwargs: Function keyword arguments
            span: The span to record metrics on
            timing_stats: ChunkTimingStats instance
            start_time: Request start time
            stream_interval: Stream interval value
            pid: Process ID for logging

        Yields:
            Results from the generator
        """
        # Process the generator
        generator = wrapped(*args, **kwargs)

        # Process generator with instrumentation
        async for result in self._process_generator_with_instrumentation(
            generator, span, timing_stats, start_time, stream_interval, pid
        ):
            yield result

    def _finalize_instrumentation(self, span, timing_stats, start_time, stream_interval, instance, pid):
        """Finalize instrumentation by recording final metrics.

        Args:
            span: The span to record metrics on
            timing_stats: ChunkTimingStats instance
            start_time: Request start time
            stream_interval: Stream interval value
            instance: Model instance
            pid: Process ID for logging
        """
        # Calculate and record chunk statistics
        self._calculate_and_record_chunk_statistics(span, timing_stats, stream_interval, pid)

        # Record latency metrics
        latency = self._record_latency_metrics(span, start_time, pid)

        # Record model timing metrics
        self._record_model_timing_metrics(span, instance, pid)

        # Log all span attributes
        self._log_span_attributes(timing_stats, latency, instance, pid)

    async def _run_with_instrumentation(self, wrapped, instance, args, kwargs):
        """Run the wrapped function with full instrumentation.

        Args:
            wrapped: The wrapped function
            instance: The instance
            args: Function arguments
            kwargs: Function keyword arguments

        Yields:
            Results from the generator
        """
        # Initialize metrics if needed
        self._init_metrics_if_needed(instance)

        # Prepare instrumentation context
        start_time, pid, stream_interval, span = self._prepare_instrumentation_context(args, kwargs)

        try:
            # Set up span context
            token = self._setup_span_context(span)

            # Initialize timing stats
            timing_stats = ChunkTimingStats()

            # Process the wrapped generator with instrumentation
            async for result in self._process_wrapped_generator(
                wrapped, args, kwargs, span, timing_stats, start_time, stream_interval, pid
            ):
                yield result

            # Finalize instrumentation
            self._finalize_instrumentation(span, timing_stats, start_time, stream_interval, instance, pid)

        except Exception as e:
            self._handle_exception(span, e, pid)
            raise
        finally:
            # Always end the span
            span.end()

    async def _run_without_instrumentation(self, wrapped, args, kwargs):
        """Run the wrapped function without instrumentation.

        Args:
            wrapped: The wrapped function
            args: Function arguments
            kwargs: Function keyword arguments

        Yields:
            Results from the generator
        """
        async for result in wrapped(*args, **kwargs):
            yield result

    async def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Main entry point for the wrapper.

        Args:
            wrapped: The wrapped function
            instance: The instance
            args: Function arguments
            kwargs: Function keyword arguments

        Yields:
            Results from the generator
        """
        if not is_instrumentation_enabled():
            async for result in self._run_without_instrumentation(wrapped, args, kwargs):
                yield result
        else:
            async for result in self._run_with_instrumentation(wrapped, instance, args, kwargs):
                yield result
