
class ChunkTimingStats:
    """封装数据块时间相关的统计数据"""

    def __init__(self):
        """初始化数据块时间统计信息"""
        self.first_token_time = None  # 首个令牌时间
        self.last_chunk_time = None   # 上一个数据块的时间
        self.max_interval = 0         # 最大间隔时间
        self.min_interval = float('inf')  # 最小间隔时间，初始设为无穷大
        self.total_interval = 0       # 总间隔时间
        self.interval_count = 0       # 间隔计数
        self.chunk_count = 0          # 数据块计数

    def increment_chunk_count(self):
        """增加数据块计数"""
        self.chunk_count += 1
        return self.chunk_count

    def update_with_current_time(self, current_time, start_time):
        """使用当前时间更新统计信息

        Args:
            current_time: 当前时间
            start_time: 开始时间

        Returns:
            tuple: (is_first_token, time_to_first_token, interval) - 是否是第一个数据块的标志、首个令牌时间和当前计算的间隔时间
        """
        # 记录是否为第一个数据块的标志
        is_first_token = False
        time_to_first_token = None
        interval = None

        # 处理首个令牌时间
        if self.first_token_time is None:
            is_first_token = True
            self.first_token_time = current_time
            time_to_first_token = self.first_token_time - start_time

        # 更新数据块间隔时间
        if self.last_chunk_time is not None:
            interval = current_time - self.last_chunk_time
            self.max_interval = max(self.max_interval, interval)
            self.min_interval = min(self.min_interval, interval)
            self.total_interval += interval
            self.interval_count += 1

        # 更新上一数据块时间
        self.last_chunk_time = current_time

        return is_first_token, time_to_first_token, interval

    def calculate_avg_interval(self):
        """计算平均间隔时间

        Returns:
            float: 平均间隔时间，如果没有间隔则返回None
        """
        if self.interval_count > 0:
            return self.total_interval / self.interval_count
        return None

    def get_min_interval(self):
        """获取最小间隔时间

        Returns:
            float: 最小间隔时间，如果没有有效值则返回None
        """
        if self.min_interval != float('inf'):
            return self.min_interval
        return None

    def get_time_to_first_token(self, start_time):
        """计算首个令牌的时间

        Args:
            start_time: 开始时间

        Returns:
            float: 首个令牌时间，如果没有则返回None
        """
        if self.first_token_time is not None:
            return self.first_token_time - start_time
        return None

