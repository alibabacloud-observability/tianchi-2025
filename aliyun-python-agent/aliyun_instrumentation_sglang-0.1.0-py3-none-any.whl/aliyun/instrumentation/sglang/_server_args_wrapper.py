"""
Server arguments wrapper implementation for SGLang.
"""

import os
import json
from aliyun.sdk.extension.arms.logger import getLogger
from .server_args_utils import (
    save_server_args_to_file,
    extract_server_args_info
)

# Configure logging
logger = getLogger(__name__)

# 全局变量，用于存储server_args
_server_args = None

def server_args_wrapper(wrapped, instance, args, kwargs):
    """包装_launch_subprocesses以捕获server_args"""
    global _server_args
    server_args = args[0] if args else kwargs.get("server_args")

    if server_args:
        _server_args = server_args
        pid = os.getpid()
        logger.debug(f"[PID:{pid}] 捕获 server_args: {server_args}")

        # 提取server_args信息
        info = extract_server_args_info(server_args, pid)

        if info:
            logger.debug(f"[PID:{pid}] Server配置: {json.dumps(info)}")

            # 将server_args信息保存到文件
            save_server_args_to_file(info, pid)

    # 调用原始函数
    return wrapped(*args, **kwargs) 