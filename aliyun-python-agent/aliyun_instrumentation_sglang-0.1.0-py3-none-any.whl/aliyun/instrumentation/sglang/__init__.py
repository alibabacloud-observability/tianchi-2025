"""OpenTelemetry instrumentation for SGLang."""

import os
import pkg_resources
from typing import Any, Collection
from opentelemetry import trace as trace_api
from aliyun.opentelemetry.instrumentation.instrumentor import BaseInstrumentor
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.instrumentation.sglang.package import _instruments
from ._completions_wrapper import CompletionsWrapper
from ._chat_completions_wrapper import ChatCompletionsWrapper
from ._model_inference_wrapper import ModelInferenceWrapper
from ._metrics_wrapper import StatsWrapper, TokenizerMetricsWrapper
from .utils import (
    is_instrumentation_enabled,
)
from wrapt import wrap_function_wrapper
from ._server_args_wrapper import server_args_wrapper
logger = getLogger(__name__)


class AliyunSGLangInstrumentor(BaseInstrumentor):
    """An instrumentor for SGLang."""

    def instrumentation_dependencies(self) -> Collection[str]:
        return _instruments

    def _instrument(self, **kwargs: Any) -> None:
        """Instrument SGLang library.

        Args:
            **kwargs: Optional arguments for instrumentation.
                     Accepts tracer_provider.
        """
        """Instrument SGLang framework."""
        if not is_instrumentation_enabled():
            return

        if not (tracer_provider := kwargs.get("tracer_provider")):
            tracer_provider = trace_api.get_tracer_provider()

        # Get tracer
        tracer = tracer_provider.get_tracer(
            "aliyun.instrumentation.sglang",
            schema_url="https://opentelemetry.io/schemas/1.11.0",
        )
        # Initialize wrappers
        completions_wrapper = CompletionsWrapper(tracer)
        chat_completions_wrapper = ChatCompletionsWrapper(tracer)
        model_wrapper = ModelInferenceWrapper(tracer)
        stats_wrapper = StatsWrapper()


        # 包装_launch_subprocesses以捕获server_args
        wrap_function_wrapper(
            "sglang.srt.entrypoints.engine",
            "_launch_subprocesses",
            server_args_wrapper
        )

        # Wrap adapter methods instead of HTTP routes
        # the code was refactored in https://github.com/sgl-project/sglang/pull/7167 in sglang 0.4.8
        if self._before_v048():
            wrap_function_wrapper(
                "sglang.srt.openai_api.adapter",
                "v1_completions",
                completions_wrapper
            )
            
            wrap_function_wrapper(
                "sglang.srt.openai_api.adapter",
                "v1_chat_completions",
                chat_completions_wrapper
            )
        else:        
            wrap_function_wrapper(
                "sglang.srt.entrypoints.openai.serving_completions",
                "OpenAIServingCompletion.handle_request",
                completions_wrapper
            )

            wrap_function_wrapper(
                "sglang.srt.entrypoints.openai.serving_chat",
                "OpenAIServingChat.handle_request",
                chat_completions_wrapper
            )

        # Wrap model inference
        wrap_function_wrapper(
            "sglang.srt.managers.tokenizer_manager",
            "TokenizerManager.generate_request",
            model_wrapper
        )

        # Instrument metrics methods
        wrap_function_wrapper(
            "sglang.srt.managers.scheduler",
            "Scheduler.log_prefill_stats",
            stats_wrapper
        )
        wrap_function_wrapper(
            "sglang.srt.managers.scheduler",
            "Scheduler.log_decode_stats",
            stats_wrapper
        )

        # Add tokenizer metrics wrappers
        tokenizer_metrics_wrapper = TokenizerMetricsWrapper()
        wrap_function_wrapper(
            "sglang.srt.metrics.collector",
            "TokenizerMetricsCollector.observe_one_finished_request",
            tokenizer_metrics_wrapper
        )
        wrap_function_wrapper(
            "sglang.srt.metrics.collector",
            "TokenizerMetricsCollector.observe_time_to_first_token",
            tokenizer_metrics_wrapper
        )
        wrap_function_wrapper(
            "sglang.srt.metrics.collector",
            "TokenizerMetricsCollector.observe_inter_token_latency",
            tokenizer_metrics_wrapper
        )

        pid = os.getpid()
        logger.info(f"[PID:{pid}] SGLang instrumentation applied successfully")

    def _uninstrument(self, **kwargs: Any) -> None:
        """Remove SGLang instrumentation."""
        pass

    def _before_v048(self):
        try:
            sglang_version = pkg_resources.get_distribution("sglang").version
            return pkg_resources.parse_version(sglang_version) < pkg_resources.parse_version("0.4.8")
        except pkg_resources.DistributionNotFound:
            return False

# For backwards compatibility
__version__ = "0.1.0"
__all__ = ["AliyunSGLangInstrumentor"]
