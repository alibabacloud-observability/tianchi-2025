"""
Utility functions for SGLang instrumentation.
"""

import os
from typing import Any, Dict, Optional

import time
from opentelemetry.trace import Span, Status, StatusCode

from .constants import (
    ATTR_ERROR,
    ATTR_INPUT_TOKENS,
    ATTR_LATENCY,
    ATTR_MAX_TOKENS,
    ATTR_MODEL_NAME,
    ATTR_OUTPUT_TOKENS,
    ATTR_TEMPERATURE,
    ENV_ENABLED,
)
from aliyun.sdk.extension.arms.controller.controller import sglangController


def is_instrumentation_enabled() -> bool:
    """Check if instrumentation is enabled via environment variable."""
    return os.getenv(ENV_ENABLED, "true").lower() == "true" and sglangController.is_open()


def add_common_attributes(span: Span, request_data: Dict[str, Any]) -> None:
    """Add common attributes to span."""
    if "model" in request_data:
        span.set_attribute(ATTR_MODEL_NAME, request_data["model"])

    if "temperature" in request_data:
        span.set_attribute(ATTR_TEMPERATURE, request_data["temperature"])

    if "max_tokens" in request_data:
        span.set_attribute(ATTR_MAX_TOKENS, request_data["max_tokens"])


def record_error(span: Span, error: Exception) -> None:
    """Record error in span."""
    span.set_status(Status(StatusCode.ERROR))
    span.set_attribute(ATTR_ERROR, str(error))
    span.record_exception(error)


def record_latency(span: Span, start_time: float) -> None:
    """Record latency in span."""
    latency = time.time() - start_time
    span.set_attribute(ATTR_LATENCY, latency)


def record_token_counts(span: Span, input_tokens: int, output_tokens: Optional[int] = None) -> None:
    """Record token counts in span."""
    span.set_attribute(ATTR_INPUT_TOKENS, input_tokens)
    if output_tokens is not None:
        span.set_attribute(ATTR_OUTPUT_TOKENS, output_tokens)
