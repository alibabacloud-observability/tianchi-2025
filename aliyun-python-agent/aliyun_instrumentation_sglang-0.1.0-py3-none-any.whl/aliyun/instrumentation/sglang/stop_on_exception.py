from typing import Any, Callable
from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)


def stop_on_exception(
        default_return: Any = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def decorator(wrapped: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return wrapped(*args, **kwargs)
            except Exception:
                _logger.exception(f"Fail to process data, func name: {wrapped.__name__}")
                return default_return

        return wrapper
    return decorator
