"""
Instrumentation implementation for SGLang.
"""
import time
import os
from aliyun.sdk.extension.arms.logger import getLogger
from typing import Any, Callable, Mapping, Tuple

from opentelemetry.trace import Span
from fastapi.responses import StreamingResponse
from aliyun.semconv.trace import (
    VSpanAttributes,
)
from .utils import (
    is_instrumentation_enabled,
    record_error,
)
from ._wrapper import BaseWrapper
from .stop_on_exception import stop_on_exception

# Configure logging
logger = getLogger(__name__)

# 全局变量，用于存储server_args
_server_args = None

# 定义server_args文件路径
import tempfile

_SERVER_ARGS_FILE = os.path.join(tempfile.gettempdir(), 'sglang_server_args.pkl')


class ChatCompletionsWrapper(BaseWrapper):
    """包装 API 响应以添加埋点功能，同时支持流式和非流式响应"""

    async def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """主入口方法，协调整个请求处理流程"""
        if not self._should_instrument():
            return await wrapped(*args, **kwargs)

        start_time = time.time()
        pid = os.getpid()
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 开始处理请求")

        # 提取请求参数
        raw_request = self._extract_raw_request(args, kwargs, pid)
        if not raw_request:
            return await wrapped(*args, **kwargs)

        try:
            # 提取请求参数和配置
            request_config = await self._prepare_request_config(raw_request, pid)

            if request_config['is_stream']:
                return await self._handle_streaming_request(
                    wrapped, args, kwargs, request_config, pid
                )
            else:
                return await self._handle_non_streaming_request(
                    wrapped, args, kwargs, request_config, start_time, pid
                )

        except Exception as e:
            logger.error(f"[PID:{pid}] ChatCompletionsWrapper setup error: {str(e)}", exc_info=True)
            return await wrapped(*args, **kwargs)

    def _should_instrument(self) -> bool:
        """检查是否应该启用埋点功能"""
        if not is_instrumentation_enabled():
            logger.debug("埋点功能未启用，直接调用原始函数")
            return False
        return True

    def _extract_raw_request(self, args: Tuple[Any, ...], kwargs: Mapping[str, Any], pid: int) -> Any:
        """提取原始请求对象"""
        raw_request = args[1] if len(args) > 1 else kwargs.get('raw_request')

        if not raw_request:
            logger.error(f"[PID:{pid}] ChatCompletionsWrapper: raw_request not found in args or kwargs")

        return raw_request

    async def _prepare_request_config(self, raw_request: Any, pid: int) -> dict:
        """准备请求配置信息"""
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 提取请求参数")
        span_name, span_attributes, is_chat, is_stream, request_json = await self._extract_request_parameters(
            raw_request, pid
        )

        return {
            'span_name': span_name,
            'span_attributes': span_attributes,
            'is_chat': is_chat,
            'is_stream': is_stream,
            'request_json': request_json
        }

    async def _handle_non_streaming_request(
            self,
            wrapped: Callable[..., Any],
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
            request_config: dict,
            start_time: float,
            pid: int
    ) -> Any:
        """处理非流式请求"""
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 处理非流式请求")

        with self.tracer.start_as_current_span(
                request_config['span_name'],
                attributes=request_config['span_attributes']
        ) as span:
            try:
                # 调用原始函数
                response = await self._call_wrapped_function(wrapped, args, kwargs, pid)

                # 处理响应属性
                self._handle_non_streaming_response(
                    response, span, start_time, pid, request_config['is_chat']
                )

                return response

            except Exception as e:
                logger.error(f"[PID:{pid}] ChatCompletionsWrapper error: {str(e)}", exc_info=True)
                record_error(span, e)
                raise

    async def _handle_streaming_request(
            self,
            wrapped: Callable[..., Any],
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
            request_config: dict,
            pid: int
    ) -> Any:
        """处理流式请求"""
        # 调用原始函数获取 StreamingResponse
        response = await self._call_wrapped_function(wrapped, args, kwargs, pid)

        # 验证响应类型
        if not self._is_valid_streaming_response(response, pid):
            return response

        # 创建增强的流式响应
        return await self._create_enhanced_streaming_response(response, request_config, pid)

    async def _call_wrapped_function(
            self,
            wrapped: Callable[..., Any],
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
            pid: int
    ) -> Any:
        """调用被包装的原始函数"""
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 调用原始函数")
        response = await wrapped(*args, **kwargs)
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 原始函数调用完成")
        return response

    def _is_valid_streaming_response(self, response: Any, pid: int) -> bool:
        """验证是否为有效的流式响应"""
        if not isinstance(response, StreamingResponse):
            logger.warning(f"[PID:{pid}] Expected StreamingResponse but got {type(response)}")
            return False
        return True

    async def _create_enhanced_streaming_response(
            self,
            response: StreamingResponse,
            request_config: dict,
            pid: int
    ) -> StreamingResponse:
        """创建增强的流式响应"""
        # 获取原始的生成器函数并创建增强的生成器
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 获取原始生成器并创建增强生成器")
        original_generator = response.body_iterator
        instrumented_generator = await self._create_instrumented_stream_generator(
            original_generator,
            request_config['span_name'],
            request_config['span_attributes'],
            pid,
            "ChatCompletionsWrapper"
        )

        # 创建一个新的StreamingResponse，使用我们的instrumented生成器
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 创建新的StreamingResponse")
        new_response = StreamingResponse(
            content=instrumented_generator(),
            status_code=response.status_code,
            headers=response.headers,
            media_type=response.media_type,
            background=response.background
        )
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper 返回包装后的流式响应")

        return new_response

    @stop_on_exception(default_return=None)
    def _handle_non_streaming_response(
            self,
            response: Any,
            span: Span,
            start_time: float,
            pid: int,
            is_chat: bool
    ) -> Any:
        """处理非流式响应，记录相关属性和指标"""
        # 提取响应属性
        attributes = self._extract_chat_completion_attributes(response, is_chat)
        span.set_attributes(attributes)

        # 记录延迟
        latency = time.time() - start_time
        span.set_attribute(VSpanAttributes.GEN_AI_LATENCY_E2E, latency)
        logger.debug(f"[PID:{pid}] ChatCompletionsWrapper non-streaming end-to-end latency: {latency:.3f}s")

        # 记录使用统计信息
        if hasattr(response, "usage"):
            prompt_tokens, completion_tokens, usage_attributes = self._record_usage_statistics(response.usage)
            span.set_attributes(usage_attributes)
            model_name = self.get_model_name()
            self.record_token_usage(model_name, prompt_tokens, "input")
            self.record_token_usage(model_name, completion_tokens, "output")
