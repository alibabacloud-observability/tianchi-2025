# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import datetime
import os
import sys
from os.path import dirname, abspath, pathsep

from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.config import constant
from aliyun.opentelemetry.instrumentation.auto_instrumentation._load import (
    _init_agent,
    _init_gevent_agent,
    _init_llm,
    _init_system,
    _is_open_gevent,
    _load_configurators,
    _load_distro,
    _load_instrumentors,
)
from aliyun.opentelemetry.instrumentation.utils import _python_path_without_directory
from aliyun.opentelemetry.instrumentation.version import (
    __agent_version__
)

logger = getLogger(__name__, add_sls_log_handler=False)

def initialize():
    logger.warning(f"Load Aliyun python agent version: {__agent_version__}, start time: {datetime.datetime.now()}")
    print(f"Load Aliyun python agent version: {__agent_version__}, start time: {datetime.datetime.now()}", file=sys.stderr)

    # macos系统上，可以考虑把APSARA_APM_INSTRUMENTATION_CHILD_PROCESS设置成false
    # 否则可能会产生agent无限递归挂载的问题
    inst_child_process = os.getenv(constant.APSARA_APM_INSTRUMENTATION_CHILD_PROCESS, "true")
    if not inst_child_process or inst_child_process.lower() == "false":
        if os.getenv("PYTHONPATH", None):
            # prevents auto-instrumentation of subprocesses if code execs another python process
            os.environ["PYTHONPATH"] = _python_path_without_directory(
                os.environ["PYTHONPATH"], dirname(abspath(__file__)), pathsep
            )

    try:
        if not _is_open_gevent():
            _init_agent()
            _init_system()
            distro = _load_distro()
            distro.configure()
            _load_configurators()
            _load_instrumentors(distro)
            _init_llm()
        elif _is_open_gevent():
            logger.info(f"init gevent agent info")
            _init_gevent_agent()

    except Exception:  # pylint: disable=broad-except
        logger.exception("Failed to auto initialize opentelemetry")


initialize()
logger.warning(
    f"Aliyun python agent is started , time: {datetime.datetime.now()}, current pid is {os.getpid()}, ppid is {os.getppid()}")
print(
    f"Aliyun python agent is started , time: {datetime.datetime.now()}, current pid is {os.getpid()}, ppid is {os.getppid()}", file=sys.stderr)
