# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import time
from abc import ABC
from importlib import util as importlib_util
from os import environ
from typing import Any, Awaitable, Callable, Iterable, Iterator, Mapping, Tuple

from aliyun.opentelemetry.sdk.trace.sampling import ParentBasedTraceIdRatio

from aliyun.sdk.extension.arms.self_monitor.self_monitor import _self_monitor_metrics
from aliyun.sdk.extension.arms.config.constant import (
    ARMS_AGENT_ENABLE_KEY,
    PROFILER_SAMPLING_ENABLE_KEY,
    PROFILER_SAMPLING_RATE_KEY,
    COMPONENT_LIST, PROFILER_APP_TAGS, PROFILER_NETWORK_STRATEGY, PROFILER_COLLECTOR_ENDPOINT, CMS_WORKSPACE,
    SLS_PROJECT, CMS_WORKSPACE_KEY_IN_SPAN, ARMS_SERVICE_ID_KEY_IN_SPAN, PROFILER_SELF_MONITOR_KEY
)
from aliyun.sdk.extension.arms.controller.controller import (
    controllerManager,
)
from aliyun.sdk.extension.arms.controller import COMPONENT_CONTROLLER_LIST
from aliyun.sdk.extension.arms.logger import getLogger

from pkg_resources import iter_entry_points
from wrapt import wrap_function_wrapper

from aliyun.opentelemetry.instrumentation.dependencies import (
    get_dist_dependency_conflicts,
)
from aliyun.opentelemetry.instrumentation.distro import BaseDistro, DefaultDistro
from aliyun.opentelemetry.instrumentation.environment_variables import (
    OTEL_PYTHON_CONFIGURATOR,
    OTEL_PYTHON_DISABLED_INSTRUMENTATIONS,
    OTEL_PYTHON_DISTRO,
)
from aliyun.opentelemetry.instrumentation.instrumentor import BaseInstrumentor
from aliyun.opentelemetry.instrumentation.version import (
    __agent_version__,
    __version__,
)
from aliyun.opentelemetry.sdk.trace.sampling import Sampler, TraceIdRatioBased
from opentelemetry.trace import get_tracer_provider, set_tracer_provider

from aliyun.opentelemetry.instrumentation.utils import is_uwsgi, is_gunicorn, is_uvicorn
from aliyun.opentelemetry.instrumentation.gevent_state import global_gevent_state

_load_instruments = []

start_time = int(round(time.time() * 1000))


def send_agent_info():
    from aliyun.sdk.extension.arms.metadata.util import gen_k8s_metadata, get_host_metadata
    from aliyun.sdk.extension.arms.utils import (
        get_hostname,
        is_llm_app,
        llm_app_type,
    )
    from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
    from aliyun.sdk.extension.arms.metadata import add_agent_info, AgentInfoMetadata
    from aliyun.sdk.extension.arms.proto.agent_info_pb2 import (
        AgentInfo)
    from aliyun.sdk.extension.arms.tag import arms_tag_service
    global start_time
    agent_info = AgentInfo()
    agent_info.hostname = get_hostname()
    agent_info.ip = ArmsEnv.instance().ip
    agent_info.agentVersion = __agent_version__
    agent_info.agentId = ArmsEnv.instance().agentId
    agent_info.hostTags = arms_tag_service.global_arms_tag_service.norm_host_tags_string
    agent_info.appTags = arms_tag_service.global_arms_tag_service.norm_app_tags_string
    import platform
    agent_info.vmVersion = platform.python_version()
    agent_info.applicationName = ArmsEnv.instance().appName
    agent_info.appName = ArmsEnv.instance().appName
    agent_info.serviceType = 0
    agent_info.licenseKey = ArmsEnv.instance().licenseKey
    agent_info.language = "python"
    timestemp = int(round(time.time() * 1000))
    agent_info.startTimestamp = start_time
    agent_info.timestamp = timestemp
    agent_info.uuId = f"{ArmsEnv.instance().uuid}"
    agent_info.agentEnv = ArmsEnv.instance().agentEnv
    agent_info.appClusterIdTag = ArmsEnv.instance().clusterId
    agent_info.applicationName = ArmsEnv.instance().clusterName
    agent_info.ports = "80"
    agent_info.memTotalSize = "4096"
    agent_info.pid = os.getpid()
    agent_info.processorNum = "1"
    agent_info.agentTags["agent_type"] = "python_agent"
    agent_info.agentArgs = f"is_llm={is_llm_app()};genai_type={llm_app_type()}"
    _logger.debug(f"agent_info: {agent_info}")
    # 云监控2.0支持workspace
    agent_info.acsArmsServiceId = ArmsEnv.instance().service_id
    agent_info.acsCmsWorkspace = ArmsEnv.instance().workspace
    # k8s metadata & host metadata
    k8s_meta_obj = gen_k8s_metadata()
    if k8s_meta_obj:
        agent_info.k8sMetadata = k8s_meta_obj.to_json()
    host_meta_obj = get_host_metadata()
    if host_meta_obj:
        agent_info.hostMetadata = host_meta_obj.to_json()
    add_agent_info(AgentInfoMetadata(agent_info=agent_info))


def send_sts_credential():
    from aliyun.sdk.extension.arms.metadata import CredentialMetadata, add_credential_metadata
    from aliyun.sdk.extension.arms.proto.arms_credential_pb2 import ArmsSTSCredential
    credential = ArmsSTSCredential()
    credential.STSUseCase = "PYTHON_AGENT_LOG_TO_SLS"
    add_credential_metadata(metadata=CredentialMetadata(credential=credential))


_logger = getLogger(__name__)


def _load_distro() -> BaseDistro:
    distro_name = environ.get(OTEL_PYTHON_DISTRO, None)
    for entry_point in iter_entry_points("opentelemetry_distro"):
        try:
            # If no distro is specified, use first to come up.
            if distro_name is None or distro_name == entry_point.name:
                try:
                    distro = entry_point.load()()
                except BaseException:
                    continue
                if not isinstance(distro, BaseDistro):
                    _logger.debug(
                        "%s is not an OpenTelemetry Distro. Skipping",
                        entry_point.name,
                    )
                    continue
                _logger.debug(
                    "Distribution %s will be configured", entry_point.name
                )
                return distro
        except Exception as exc:  # pylint: disable=broad-except
            _logger.exception(
                "Distribution %s configuration failed", entry_point.name
            )
            # raise exc
    return DefaultDistro()


def _load_instrumentors(distro):
    package_to_exclude = environ.get(OTEL_PYTHON_DISABLED_INSTRUMENTATIONS, [])
    if isinstance(package_to_exclude, str):
        package_to_exclude = package_to_exclude.split(",")
        # to handle users entering "requests , flask" or "requests, flask" with spaces
        package_to_exclude = [x.strip() for x in package_to_exclude]

    for entry_point in iter_entry_points("opentelemetry_pre_instrument"):
        entry_point.load()()

    for entry_point in iter_entry_points("opentelemetry_instrumentor"):
        if entry_point.name in package_to_exclude:
            _logger.debug(
                "Instrumentation skipped for library %s", entry_point.name
            )
            continue

        try:
            if entry_point.dist is None:
                continue
            conflict = get_dist_dependency_conflicts(entry_point.dist)
            if conflict:
                _logger.debug(
                    "Skipping instrumentation %s: %s",
                    entry_point.name,
                    conflict,
                )
                continue

            # tell instrumentation to not run dep checks again as we already did it above
            should_skip = _should_skip(entry_point.module_name, entry_point.name)
            if not should_skip:
                distro.load_instrumentor(entry_point, skip_dep_check=True)
                instrumentor: BaseInstrumentor = entry_point.load()
                _load_instruments.append(instrumentor)
                _logger.info("Instrumented %s", entry_point.name)
            else:
                _logger.warning("Instrumented can not be instrument %s", entry_point.module_name)
        except Exception as exc:  # pylint: disable=broad-except
            _logger.warning(f"Instrumenting of %s failed: {entry_point.name} exc info {exc}", )
            # raise exc

    for entry_point in iter_entry_points("opentelemetry_post_instrument"):
        entry_point.load()()


_release_list = [
    "fastapi",
    "aiohttp-client",
    "django",
    "flask",
    # "threading",
    "requests",
    "httpx",
    "logging",
]
_beta_list = [
    "redis",
    "sqlalchemy",
    "pymysql",
    "httpx",
    "celery",
    "psycopg2",
    "psycopg",
    "alibaba_extension_metrics",
    "system_metrics"
]


# check if aliyun instrument
def _should_skip(module_name, instrument_name):
    # 为了保证开源插件/用户自定义插件的兼容性
    # 这里不对插件的名字做限制，即使不是aliyun前缀开头的instrumentor我们也要加载、
    # 后续可能会有插件的exclude策略，可以在这里添加
    return False


def _load_configurators():
    configurator_name = environ.get(OTEL_PYTHON_CONFIGURATOR, None)
    configured = None
    for entry_point in iter_entry_points("opentelemetry_configurator"):
        if configured is not None:
            _logger.warning(
                "Configuration of %s not loaded, %s already loaded",
                entry_point.name,
                configured,
            )
            continue
        try:
            if (
                    configurator_name is None
                    or configurator_name == entry_point.name
            ):
                entry_point.load()().configure(auto_instrumentation_version=__version__)  # type: ignore
                configured = entry_point.name
            else:
                _logger.warning(
                    "Configuration of %s not loaded because %s is set by %s",
                    entry_point.name,
                    configurator_name,
                    OTEL_PYTHON_CONFIGURATOR,
                )
        except Exception as exc:  # pylint: disable=broad-except
            _logger.exception("Configuration of %s failed", entry_point.name)
            # raise exc


def _init_llm():
    try:
        from aliyun.instrumentation.sglang import AliyunSGLangInstrumentor
        AliyunSGLangInstrumentor().instrument()
        _logger.info("Instrumented SGLang")
    except Exception as exc:
        _logger.warning(f"Instrumentation error, instrumentor: SGLang, Exception Info:{exc}")

    try:
        from aliyun.instrumentation.dify import AliyunDifyInstrumentor
        AliyunDifyInstrumentor().instrument()
        _logger.info("Instrumented Dify")
    except Exception as exc:
        _logger.warning(f"Instrumented can not be instrument, instrumentor: Dify, Exception Info:{exc}")
        
    try:
        if importlib_util.find_spec("vllm"):
            from aliyun.instrumentation.vllm import AliyunVLLMInstrumentor
            AliyunVLLMInstrumentor().instrument()
            _logger.info("Instrumented vLLM")
    except Exception as exc:
        _logger.warning(f"Instrumented can not be instrument, instrumentor: vLLM, Exception Info:{exc}")
        
    try:
        if importlib_util.find_spec("langchain_core"):
            from aliyun.instrumentation.langchain import (
                AliyunLangChainInstrumentor,
            )

            langchain_instrument = AliyunLangChainInstrumentor()
            langchain_instrument.instrument()
            _load_instruments.append(langchain_instrument)
            _logger.info("Instrumented Langchain")
    except Exception as exc:
        _logger.warning(f"Instrumented can not be instrument, instrumentor: Langchain, Exception Info::{exc}")

    try:
        if importlib_util.find_spec("dashscope"):
            from aliyun.instrumentation.dashscope import (
                AliyunDashScopeInstrumentor,
            )

            dashscope_instrument = AliyunDashScopeInstrumentor()
            dashscope_instrument.instrument()
            _load_instruments.append(dashscope_instrument)
            _logger.info("Instrumented Dashscope")
    except Exception as exc:
        _logger.warning(f"Instrumented can not be instrument, instrumentor: Dashscope, Exception Info::{exc}")

    try:
        if importlib_util.find_spec("llama_index"):
            from aliyun.instrumentation.llama_index import (
                AliyunLlamaIndexInstrumentor,
            )

            llama_index_instrument = AliyunLlamaIndexInstrumentor()
            llama_index_instrument.instrument()
            _load_instruments.append(llama_index_instrument)
            _logger.info("Instrumented Llama Index")
    except Exception as exc:
        _logger.warning(f"Instrumented can not be instrument, instrumentor: Llama Index, Exception Info::{exc}")

    try:
        if (not importlib_util.find_spec("llama_index")) and importlib_util.find_spec("openai"):
            from aliyun.instrumentation.openai import AliyunOpenAIInstrumentor

            openai_instrument = AliyunOpenAIInstrumentor()
            openai_instrument.instrument()
            _load_instruments.append(openai_instrument)
            _logger.info("llm Instrumented openai")
    except Exception as exc:
        _logger.warning(f"Instrumented can not be instrument, instrumentor: openai, Exception Info::{exc}")

    try:
        if importlib_util.find_spec("mcp"):
            from aliyun.instrumentation.mcp import AliyunMCPInstrumentor

            mcp_instrument = AliyunMCPInstrumentor()
            mcp_instrument.instrument()
            _load_instruments.append(mcp_instrument)
            _logger.info("Instrumented mcp")
    except Exception as exc:
        _logger.warning(f"Instrumented can not be instrument, instrumentor: mcp, Exception Info::{exc}", exc_info=True)

def _init_system():
    try:
        from aliyun.opentelemetry.instrumentation.extension.alibaba.metrics import (
            MetricsInstrumentor,
        )

        metrics_instrument = MetricsInstrumentor()
        metrics_instrument.instrument()
        _load_instruments.append(metrics_instrument)
    except Exception as exc:
        pass
    try:
        from aliyun.opentelemetry.instrumentation.extension.alibaba.system_metrics import (
            SystemMetricsInstrumentor,
        )

        system_metrics_instrument = SystemMetricsInstrumentor(
            config={
                "process.runtime.gc_count": None,
                "process.runtime.thread_count": None,
                "process.runtime.context_switches": [
                    "involuntary",
                    "voluntary",
                ],
            }
        )
        system_metrics_instrument.instrument()
        _load_instruments.append(system_metrics_instrument)
    except Exception as exc:
        pass


_tag_generator = None


def _agent_heartbeat():
    from aliyun.sdk.extension.arms.controller.controller import agentInfoController
    if not agentInfoController.is_open():
        return
    send_agent_info()
    send_sts_credential()
    global _tag_generator
    if _tag_generator is not None and _tag_generator.is_inited():
        _tag_generator.generate_tag()
    else:
        _logger.warning("-----_tag_generator is not inited, please init ---")


def _start_agent_heartbeat():
    from aliyun.sdk.extension.arms.common.heartbeat.heartbeat import Heartbeat
    heartbeat = Heartbeat(call=_agent_heartbeat)
    heartbeat.run()


sampler = ParentBasedTraceIdRatio(1)


def reopen_agent():
    controllerManager.open_all()


def close_agent():
    controllerManager.close_all()


def set_sampler_rate(rate=0.1):
    """
    reset sampler
    """
    global sampler
    if 0 <= rate <= 1.0:
        sampler = ParentBasedTraceIdRatio(rate)


client = None


def handler_config():
    """
    handler config from config
    """
    from aliyun.sdk.extension.arms.config.config import get_config_properties
    from aliyun.sdk.extension.arms.tag import arms_tag_service
    config = get_config_properties(client=client)
    _logger.warning(f"handler_config: {client.get_config()}")
    if config is not None:
        rate = config.get_property(PROFILER_SAMPLING_RATE_KEY)
        if rate is not None and isinstance(rate, (int, float)):
            rate /= 100
            set_sampler_rate(rate)
        is_enable = config.get_property(ARMS_AGENT_ENABLE_KEY)
        if is_enable is not None and is_enable is False:
            close_agent()
        else:
            reopen_agent()
            _update_instrument_stats(config)
        # tag related
        arms_tag_service.global_arms_tag_service.app_tags_string = config.get_property(PROFILER_APP_TAGS)
        # endpoint config
        from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state
        global_arms_endpoints_state.network_strategy = config.get_property(PROFILER_NETWORK_STRATEGY)
        global_arms_endpoints_state.one_endpoint = config.get_property(PROFILER_COLLECTOR_ENDPOINT)
        # 自监控
        self_monitor_enable = config.get_property(PROFILER_SELF_MONITOR_KEY)
        if self_monitor_enable is not None and self_monitor_enable is False:
            _self_monitor_metrics.set_self_monitor_enable(False)

def _update_instrument_stats(config):
    for key in COMPONENT_LIST:
        component = COMPONENT_LIST[key]
        component_flag = config.get_property(component)
        if component_flag is not None:
            if component_flag is True:
                controllerManager.open(key)
            else:
                controllerManager.close(key)


def _init_config():
    from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
    from aliyun.sdk.extension.arms.config.acm import AmrsACMConfig
    from aliyun.sdk.extension.arms.tag import arms_tag_service
    global client
    client = AmrsACMConfig()
    client.init_acm_client(
        region_id=ArmsEnv.instance().regionId,
        app_id=ArmsEnv.instance().getAppId(),
    )
    handler_config()
    _init_env_controller()
    arms_tag_service.global_arms_tag_service.init_tags()
    client.register_callback(handler_config)


def _init_agent():
    from aliyun.sdk.extension.arms.utils import get_local_ip
    from aliyun.sdk.extension.arms.metadata import (
        init_metadata
    )
    from aliyun.sdk.extension.arms.exporters.trace_exporter import (
        Compression,
        OTLPSpanExporter,
    )
    from aliyun.sdk.extension.arms.trace import (
        TracerProvider as AliyunTracerProvider,
    )
    from aliyun.sdk.extension.arms.exporters.arms_metrics_exporter import (
        ArmsMetricsExporter,
    )
    from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv

    from aliyun.sdk.extension.arms.tag.tag_generator import TagGenerator
    from aliyun.opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
    )
    from aliyun.opentelemetry.sdk import resources
    from aliyun.sdk.extension.arms.services.arms_periodic_metric_reader import (
        ArmsPeriodicMetricReader,
    )
    from aliyun.opentelemetry.sdk.trace.sampling import Sampler, TraceIdRatioBased
    from opentelemetry.metrics import set_meter_provider
    from aliyun.opentelemetry.sdk.metrics import MeterProvider
    from aliyun.sdk.extension.arms.tag import arms_tag_service

    app_name = None
    if name := os.getenv("ARMS_APP_NAME"):
        app_name = name
    _logger.warning(f"app name is: {app_name}")
    _init_config()

    tags = {}
    if arms_tag_service.global_arms_tag_service.host_tags:
        tags.update(arms_tag_service.global_arms_tag_service.host_tags)
    if arms_tag_service.global_arms_tag_service.app_tags:
        tags.update(arms_tag_service.global_arms_tag_service.app_tags)

    tags.update({
        "service.name": app_name,
        "source": "python",
        "arms.appId": ArmsEnv.instance().agentId,
        "ipv4": ArmsEnv.instance().ip,
        "agentVersion": __agent_version__,
        CMS_WORKSPACE_KEY_IN_SPAN: ArmsEnv.instance().workspace,
        ARMS_SERVICE_ID_KEY_IN_SPAN: ArmsEnv.instance().service_id
    })

    armsResource = resources.Resource.create(
        tags
    )

    header = {
        "Content-Type": "application/x-protobuf",
        "licenseKey": ArmsEnv.instance().licenseKey,
        "content.type": "span",
        "X-ARMS-Encoding": "snappy",
        "data.type": "",
    }
    from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state
    if global_arms_endpoints_state.use_one_endpoints:
        header.update({CMS_WORKSPACE: ArmsEnv.instance().workspace, SLS_PROJECT: global_arms_endpoints_state.sls_project})
    exporter = OTLPSpanExporter(
        headers=header, compression=Compression.Snappy
    )
    tracerProvider = AliyunTracerProvider(
        resource=armsResource, sampler=sampler
    )

    tracerProvider.add_span_processor(
        BatchSpanProcessor(span_exporter=exporter)
    )
    set_tracer_provider(tracerProvider)

    # TODO @qianlu set metrics exporter ...
    #   self monitor & metrics
    armsMetricReader = ArmsPeriodicMetricReader(exporter=ArmsMetricsExporter())
    meterProvider = MeterProvider(
        metric_readers=[armsMetricReader], resource=armsResource
    )
    set_meter_provider(meterProvider)
    global _tag_generator
    if _tag_generator is None:
        _tag_generator = TagGenerator()

    _tag_generator.set_meter_provider(meterProvider)
    init_metadata()
    _start_agent_heartbeat()


def _is_open_gevent():
    gevent_enable = os.getenv("GEVENT_ENABLE", "false")
    if gevent_enable == "true":
        return True
    return False


def _init_gevent_agent():
    wrap_function_wrapper(
        module="gevent.monkey",
        name="patch_all",
        wrapper=GeventWrapper(),
    )


def _init_env_controller():
    for key, value in COMPONENT_CONTROLLER_LIST.items():
        name = value["name"]
        default = value["default"]
        flag = True
        flagstr = os.getenv(key, "")
        if flagstr == "":
            continue
        if flagstr == "false":
            flag = False
        if flag:
            controllerManager.open(name)
        else:
            controllerManager.close(name)


class GeventWrapper(ABC):
    def __init__(self):
        pass

    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[type, Any],
            kwargs: Mapping[str, Any],
    ) -> Any:
        st = time.time_ns()
        _logger.warning(f"[GeventWrapper] calling")
        res = wrapped(*args, **kwargs)
        global_gevent_state.inited = True
        _init_agent()
        _init_system()
        distro = _load_distro()
        distro.configure()
        _load_configurators()
        _load_instrumentors(distro)
        _init_llm()
        d = (time.time_ns() - st) / 1_000_000
        _logger.warning(f"end init gevent wrapper,cost {d} ms")
        return True
