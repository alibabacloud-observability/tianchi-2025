class GeventState:
    def __init__(self):
        self.inited = False


global_gevent_state = GeventState()