from aliyun.sdk.extension.arms.logger import getLogger
import time
from typing import Optional
from copy import deepcopy

from opentelemetry import trace as trace_api
from opentelemetry.util.types import Attributes
from opentelemetry.metrics import get_meter
from aliyun.sdk.extension.arms.semconv.metrics import ArmsCommonServiceMetrics
from aliyun.sdk.extension.arms.common.utils.metrics_utils import get_llm_common_attributes
from aliyun.semconv.trace import SpanAttributes, AliyunSpanKindValues
from aliyun.instrumentation.openai.version import __version__

logger = getLogger(__name__)

# Initialize metrics
meter = get_meter(
    __name__,
    __version__,
    None,
    schema_url="https://opentelemetry.io/schemas/1.11.0",
)


class _WithSpan:
    __slots__ = (
        "_span",
        "_extra_attributes",
        "_is_finished",
        "_start_time_utc_nano",
    )

    def __init__(
        self,
        span: trace_api.Span,
        extra_attributes: Attributes = None,
        start_time_utc_nano: int = None,
    ) -> None:
        self._span = span
        self._extra_attributes = extra_attributes
        self._start_time_utc_nano = start_time_utc_nano
        try:
            self._is_finished = not self._span.is_recording()
        except Exception:
            logger.exception("Failed to check if span is recording")
            self._is_finished = True

    @property
    def is_finished(self) -> bool:
        return self._is_finished

    def record_exception(self, exception: Exception) -> None:
        if self._is_finished:
            return
        try:
            self._span.record_exception(exception)
        except Exception:
            logger.exception("Failed to record exception on span")

    def add_event(self, name: str) -> None:
        if self._is_finished:
            return
        try:
            self._span.add_event(name)
        except Exception:
            logger.exception("Failed to add event to span")

    def finish_tracing(
        self,
        status: Optional[trace_api.Status] = None,
        attributes: Attributes = None,
        extra_attributes: Attributes = None,
    ) -> None:
        if self._is_finished:
            return
        
        # Collect all attributes for metrics generation
        all_attributes = {}
        for mapping in (
            attributes,
            self._extra_attributes,
            extra_attributes,
        ):
            if not mapping:
                continue
            for key, value in mapping.items():
                if value is None:
                    continue
                all_attributes[key] = value
                try:
                    self._span.set_attribute(key, value)
                except Exception:
                    logger.exception("Failed to set attribute on span")
        
        # Generate metrics if this is an LLM span
        try:
            self._generate_llm_metrics(all_attributes)
        except Exception:
            logger.exception("Failed to generate LLM metrics")
            
        if status is not None:
            try:
                self._span.set_status(status=status)
            except Exception:
                logger.exception("Failed to set status code on span")
        try:
            self._span.end()
        except Exception:
            logger.exception("Failed to end span")
        self._is_finished = True

    def _generate_llm_metrics(self, span_attributes: dict) -> None:
        """Generate metrics from span attributes"""
        span_kind = self._span.attributes.get(SpanAttributes.GEN_AI_SPAN_KIND)
        if not span_kind:
            return
            
        try:
            arms_metrics = ArmsCommonServiceMetrics(meter)
            metrics_attributes = get_llm_common_attributes()
            metrics_attributes["spanKind"] = span_kind
            
            # Record call count
            arms_metrics.calls_count.add(1, attributes=metrics_attributes)
            
            # Calculate and record duration
            duration = (time.time_ns() - self._start_time_utc_nano) / 1_000_000_000
            arms_metrics.calls_duration_seconds.record(duration, attributes=metrics_attributes)
            
            # Record LLM-specific metrics if this is an LLM span
            if span_kind == AliyunSpanKindValues.LLM.value:
                model_name = "UNSET"
                if name := span_attributes.get(SpanAttributes.GEN_AI_RESPONSE_MODEL_NAME):
                    model_name = name
                elif name := span_attributes.get(SpanAttributes.GEN_AI_REQUEST_MODEL_NAME):
                    model_name = name
                metrics_attributes["modelName"] = model_name
                
                # Record input tokens
                if input_token := span_attributes.get(SpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS):
                    input_attributes = deepcopy(metrics_attributes)
                    input_attributes["usageType"] = "input"
                    arms_metrics.llm_usage_tokens.add(input_token, attributes=input_attributes)
                
                # Record output tokens
                if output_token := span_attributes.get(SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS):
                    output_attributes = deepcopy(metrics_attributes)
                    output_attributes["usageType"] = "output"
                    arms_metrics.llm_usage_tokens.add(output_token, attributes=output_attributes)
                    
        except Exception as e:
            logger.exception(f"Failed to generate LLM metrics: {str(e)}")
