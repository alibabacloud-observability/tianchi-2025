

from aliyun.instrumentation.openai.internal._request import (
    _Request as Request, _AsyncRequest as AsyncRequest
)

__all__ = ["Request","AsyncRequest"]
