import json
from aliyun.sdk.extension.arms.logger import getLogger
import sys
import warnings
from functools import lru_cache
from importlib.metadata import version
from typing import (
    Any,
    Iterator,
    List,
    Mapping,
    NamedTuple,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    Union,
    cast,
)

from aliyun.instrumentation.openai.internal._with_span import _WithSpan
from aliyun.semconv.trace import AliyunMimeTypeValues, SpanAttributes
from opentelemetry import trace as trace_api
from opentelemetry.util.types import Attributes, AttributeValue

logger = getLogger(__name__)


@lru_cache
def _get_openai_version() -> Tuple[int, int, int]:
    return cast(Tuple[int, int, int], tuple(map(int, version("openai").split(".")[:3])))


class _ValueAndType(NamedTuple):
    value: str
    type: AliyunMimeTypeValues


def _io_value_and_type(obj: Any) -> _ValueAndType:
    if hasattr(obj, "model_dump_json") and callable(obj.model_dump_json):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                # `warnings=False` in `model_dump_json()` is only supported in Pydantic v2
                value = obj.model_dump_json(exclude_unset=True)
            assert isinstance(value, str)
        except Exception:
            logger.exception("Failed to get model dump json")
        else:
            return _ValueAndType(value, AliyunMimeTypeValues.JSON)
    if not isinstance(obj, str) and isinstance(obj, (Sequence, Mapping)):
        try:
            # 在序列化之前过滤掉base64图片数据
            filtered_obj = _filter_base64_images(obj)
            value = json.dumps(filtered_obj)
        except Exception:
            logger.exception("Failed to dump json")
        else:
            return _ValueAndType(value, AliyunMimeTypeValues.JSON)
    return _ValueAndType(str(obj), AliyunMimeTypeValues.TEXT)


def _as_input_attributes(
    value_and_type: Optional[_ValueAndType],
) -> Iterator[Tuple[str, AttributeValue]]:
    if not value_and_type:
        return
    row_text = bytes(value_and_type.value, "utf-8").decode("unicode_escape")
    input_val = row_text.encode("utf-8", errors="surrogatepass")
    yield SpanAttributes.INPUT_VALUE, input_val
    # It's assumed to be TEXT by default, so we can skip to save one attribute.
    if value_and_type.type is not AliyunMimeTypeValues.TEXT:
        yield SpanAttributes.INPUT_MIME_TYPE, value_and_type.type.value


def _as_output_attributes(
    value_and_type: Optional[_ValueAndType],
) -> Iterator[Tuple[str, AttributeValue]]:
    if not value_and_type:
        return
    yield SpanAttributes.OUTPUT_VALUE, value_and_type.value
    # It's assumed to be TEXT by default, so we can skip to save one attribute.
    if value_and_type.type is not AliyunMimeTypeValues.TEXT:
        yield SpanAttributes.OUTPUT_MIME_TYPE, value_and_type.type.value


class _HasAttributes(Protocol):
    def get_attributes(self) -> Iterator[Tuple[str, AttributeValue]]: ...

    def get_extra_attributes(self) -> Iterator[Tuple[str, AttributeValue]]: ...


def _finish_tracing(
    with_span: _WithSpan,
    has_attributes: _HasAttributes,
    status: Optional[trace_api.Status] = None,
) -> None:
    try:
        attributes: Attributes = dict(has_attributes.get_attributes())
    except Exception:
        logger.exception("Failed to get attributes")
        attributes = None
    try:
        extra_attributes: Attributes = dict(has_attributes.get_extra_attributes())
    except Exception:
        logger.exception("Failed to get extra attributes")
        extra_attributes = None
    try:
        with_span.finish_tracing(
            status=status,
            attributes=attributes,
            extra_attributes=extra_attributes,
        )
    except Exception:
        logger.exception("Failed to finish tracing")


def _get_texts(
    model_input: Optional[Union[str, List[str], List[int], List[List[int]]]],
    model: Optional[str],
) -> Iterator[str]:
    if not model_input:
        return
    if isinstance(model_input, str):
        text = model_input
        yield text
        return
    if not isinstance(model_input, Sequence):
        return
    if any(not isinstance(item, str) for item in model_input):
        # FIXME: We can't decode tokens (List[int]) reliably because the model name is not reliable,
        # e.g. for text-embedding-ada-002 (cl100k_base), OpenAI returns "text-embedding-ada-002-v2",
        # and Azure returns "ada", which refers to a different model (r50k_base). We could use the
        # request model name instead, but that doesn't work for Azure because Azure uses the
        # deployment name (which differs from the model name).
        return
    for text in cast(List[str], model_input):
        yield text


def recursive_size(obj: Any, max_size: int = 10240) -> int:
    """递归计算对象大小，超过阈值时快速返回"""
    total_size = 0
    if isinstance(obj, dict):
        total_size += sys.getsizeof(obj)
        if total_size > max_size:
            return total_size
        for key, value in obj.items():
            total_size += recursive_size(key, max_size - total_size) + recursive_size(value, max_size - total_size)
            if total_size > max_size:
                return total_size
    elif isinstance(obj, list):
        total_size += sys.getsizeof(obj)
        if total_size > max_size:
            return total_size
        for item in obj:
            total_size += recursive_size(item, max_size - total_size)
            if total_size > max_size:
                return total_size
    else:
        total_size += sys.getsizeof(obj)
    return total_size


def _is_base64_image(item: Any) -> bool:
    """检查是否为base64编码的图片数据"""
    if not isinstance(item, dict):
        return False
    if not isinstance(item.get("image_url"), dict):
        return False
    if "data:image/" not in item.get("image_url", {}).get("url", ""):
        return False
    return True


def _filter_base64_images(obj: Any) -> Any:
    """递归过滤掉base64图片数据，保留其他信息"""
    # 使用内存大小检测 - 如果数据量不大，直接返回
    # 256x256 图片 base64 约 12K 字符长度，这里设置阈值为 10KB
    if recursive_size(obj) < 10240:  # 10KB
        return obj
    
    if isinstance(obj, list):
        filtered_list = []
        for item in obj:
            if _is_base64_image(item):
                # 保留图片信息但不包含base64数据
                filtered_item = {
                    "type": item.get("type", "image_url"),
                    "image_url": {
                        "url": "BASE64_IMAGE_DATA_FILTERED"
                    }
                }
                filtered_list.append(filtered_item)
            else:
                filtered_list.append(_filter_base64_images(item))
        return filtered_list
    elif isinstance(obj, dict):
        filtered_dict = {}
        for key, value in obj.items():
            if _is_base64_image(value):
                # 如果字典值本身就是base64图片
                filtered_dict[key] = {
                    "type": value.get("type", "image_url"),
                    "image_url": {
                        "url": "BASE64_IMAGE_DATA_FILTERED"
                    }
                }
            else:
                filtered_dict[key] = _filter_base64_images(value)
        return filtered_dict
    else:
        return obj