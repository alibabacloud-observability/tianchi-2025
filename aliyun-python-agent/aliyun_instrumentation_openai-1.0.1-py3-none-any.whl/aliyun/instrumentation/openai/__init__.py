from aliyun.sdk.extension.arms.logger import getLogger

from importlib import import_module
from typing import Any, Collection

from aliyun.instrumentation.openai.internal import (
    AsyncRequest,
    Request,
)
from aliyun.instrumentation.openai.package import _instruments
from aliyun.instrumentation.openai.version import __version__
from opentelemetry import trace as trace_api
from aliyun.opentelemetry.instrumentation.instrumentor import BaseInstrumentor  # type: ignore
from wrapt import wrap_function_wrapper

logger = getLogger(__name__)

_MODULE = "openai"


class AliyunOpenAIInstrumentor(BaseInstrumentor):  # type: ignore
    """
    An instrumentor for openai
    """

    __slots__ = (
        "_original_request",
        "_original_async_request",
    )

    def instrumentation_dependencies(self) -> Collection[str]:
        return _instruments

    def _instrument(self, **kwargs: Any) -> None:
        if not (tracer_provider := kwargs.get("tracer_provider")):
            tracer_provider = trace_api.get_tracer_provider()
        tracer = trace_api.get_tracer(__name__, __version__, tracer_provider)
        openai = import_module(_MODULE)
        self._original_request = openai.OpenAI.request
        self._original_async_request = openai.AsyncOpenAI.request
        wrap_function_wrapper(
            module=_MODULE,
            name="OpenAI.request",
            wrapper=Request(tracer=tracer, openai=openai),
        )
        wrap_function_wrapper(
            module=_MODULE,
            name="AsyncOpenAI.request",
            wrapper=AsyncRequest(tracer=tracer, openai=openai),
        )

    def _uninstrument(self, **kwargs: Any) -> None:
        openai = import_module(_MODULE)
        openai.OpenAI.request = self._original_request
        openai.AsyncOpenAI.request = self._original_async_request
