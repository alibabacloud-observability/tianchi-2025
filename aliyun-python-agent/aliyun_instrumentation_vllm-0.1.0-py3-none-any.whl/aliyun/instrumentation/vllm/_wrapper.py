from typing import Any, Callable, Dict, Tuple, Mapping
import os
from abc import ABC
from functools import partial
from typing import (TYPE_CHECKING, Callable, ClassVar, Deque, Dict, Iterable,
                    List, Mapping, NamedTuple, Optional)

from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state
from opentelemetry import trace
from opentelemetry.context.context import Context
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from opentelemetry.metrics import get_meter
from aliyun.semconv.trace import SpanAttributes, AliyunSpanKindValues, VSpanAttributes
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
import pickle

from aliyun.sdk.extension.arms.self_monitor.self_monitor_decorator import hook_advice

logger = getLogger(__name__)


class VLLMTracingInstrumentor:
    """Instrumentor for vLLM tracing methods."""

    def __init__(self, tracer):
        self.tracer = tracer

    @hook_advice(instrumentation_name="vllm", advice_method="vllm_trace")
    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Replace the instance's tracer with our own tracer."""
        # Check if instance has a tracer attribute
        if hasattr(instance, "tracer"):
            # Store the original tracer
            original_tracer = instance.tracer

            # Replace with our tracer
            instance.tracer = None

            logger.debug(f"Replaced vLLM tracer in {instance.__class__.__name__},args: {args} kwargs:{kwargs}")

            try:
                scheduler_outputs = args[0] if args else None
                finished_before = args[1] if len(args) > 1 else None
                self.do_tracing(scheduler_outputs, finished_before)
                # Call the original method with our tracer
                return wrapped(*args, **kwargs)
            except Exception as e:
                logger.exception({e})
            finally:
                # Restore the original tracer
                instance.tracer = original_tracer
        else:
            # If no tracer attribute, just call the original method
            logger.warning(f"No tracer attribute found in {instance.__class__.__name__}")
            return wrapped(*args, **kwargs)

    def extract_trace_context(
            self,
            headers: Optional[Mapping[str, str]]) -> Optional[Context]:
        headers = headers or {}
        return TraceContextTextMapPropagator().extract(headers)

    def do_tracing(
            self,
            scheduler_outputs: Any,
            finished_before: Optional[List[int]] = None
    ) -> None:
        """Implementation of the do_tracing method from vLLM LLMEngine.

        Args:
            tracer: The OpenTelemetry tracer to use
            scheduler_outputs: The outputs from the scheduler
            finished_before: Optional list of indices of sequence groups that were finished before
        """

        for idx, scheduled_seq_group in enumerate(
                scheduler_outputs.scheduled_seq_groups):
            # Skip double tracing when using async output proc
            if finished_before and idx in finished_before:
                continue

            seq_group = scheduled_seq_group.seq_group
            if seq_group.is_finished():
                self.create_trace_span(seq_group)

    def create_trace_span(self, seq_group: Any) -> None:
        """Implementation of the create_trace_span method from vLLM LLMEngine.

        Args:
            tracer: The OpenTelemetry tracer to use
            seq_group: The sequence group to create a trace span for
        """
        # Import necessary functions

        arrival_time_nano_seconds = int(seq_group.metrics.arrival_time * 1e9)
        trace_context = self.extract_trace_context(seq_group.trace_headers)
        with self.tracer.start_as_current_span(
                "llm_request",
                context=trace_context,
                start_time=arrival_time_nano_seconds) as seq_span:
            metrics = seq_group.metrics
            # Add null checks before performing subtraction
            ttft = metrics.first_token_time - metrics.arrival_time if metrics.first_token_time is not None else None
            e2e_time = metrics.finished_time - metrics.arrival_time if metrics.finished_time is not None else None

            # Set span attributes with exception handling
            if hasattr(seq_group, "model_config"):
                self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_RESPONSE_MODEL,
                                               seq_group.model_config.model)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_REQUEST_ID,
                                           seq_group.request_id)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_REQUEST_TEMPERATURE,
                                           seq_group.sampling_params.temperature)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_REQUEST_TOP_P,
                                           seq_group.sampling_params.top_p)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_REQUEST_MAX_TOKENS,
                                           seq_group.sampling_params.max_tokens)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_REQUEST_N,
                                           seq_group.sampling_params.n)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_USAGE_NUM_SEQUENCES,
                                           seq_group.num_seqs())

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS,
                                           len(seq_group.prompt_token_ids))

            self.set_span_attribute_safely(
                seq_span,
                VSpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS,
                sum([
                    seq.get_output_len()
                    for seq in seq_group.get_finished_seqs()
                ])
            )

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_LATENCY_TIME_IN_QUEUE,
                                           metrics.time_in_queue)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_LATENCY_TIME_TO_FIRST_TOKEN,
                                           ttft)

            self.set_span_attribute_safely(seq_span, VSpanAttributes.GEN_AI_LATENCY_E2E,
                                           e2e_time)

            # Set optional attributes with exception handling
            if metrics.scheduler_time is not None:
                self.set_span_attribute_safely(
                    seq_span,
                    VSpanAttributes.GEN_AI_LATENCY_TIME_IN_SCHEDULER,
                    metrics.scheduler_time
                )
            # 从torch.cuda.Event中拿的默认是 毫秒 所以需要统一单位
            if metrics.model_forward_time is not None:
                self.set_span_attribute_safely(
                    seq_span,
                    VSpanAttributes.GEN_AI_LATENCY_TIME_IN_MODEL_FORWARD,
                    metrics.model_forward_time / 1000.0
                )

            if metrics.model_execute_time is not None:
                self.set_span_attribute_safely(
                    seq_span,
                    VSpanAttributes.GEN_AI_LATENCY_TIME_IN_MODEL_EXECUTE,
                    metrics.model_execute_time
                )

    def set_span_attribute_safely(self, span, key, value):
        """
        Safely set a span attribute with error handling.

        Args:
            span: The span to set the attribute on
            key: The attribute key
            value: The attribute value
        """
        if value is None:
            return

        try:
            span.set_attribute(key, value)
        except Exception as e:
            logger.warning(f"Failed to set {key} attribute: {str(e)}")


class VLLMWrapper(ABC):
    """Wrapper for vLLM functions."""

    def __init__(self):
        self.meter = get_meter(
            __name__,
            schema_url="https://opentelemetry.io/schemas/1.11.0",
        )

        # Initialize counters for key metrics
        self.metrics_attributes = {"callType": "gen_ai", "rpcType": "2100"}

        # System metrics
        self.gpu_cache_usage_sys = self.meter.create_counter(
            name="gpu_cache_usage_sys",
            unit="count",
            description="GPU cache usage in the system"
        )
        self.gpu_cache_usage_sys_count = self.meter.create_counter(
            name="gpu_cache_usage_sys_count",
            unit="count",
            description="Count of GPU cache usage measurements"
        )
        self.cpu_cache_usage_sys = self.meter.create_counter(
            name="cpu_cache_usage_sys",
            unit="count",
            description="CPU cache usage in the system"
        )
        self.num_running_sys = self.meter.create_counter(
            name="num_running_sys",
            unit="count",
            description="Number of running sequences in the system"
        )
        self.num_waiting_sys = self.meter.create_counter(
            name="num_waiting_sys",
            unit="count",
            description="Number of waiting sequences in the system"
        )
        self.num_swapped_sys = self.meter.create_counter(
            name="num_swapped_sys",
            unit="count",
            description="Number of swapped sequences in the system"
        )

        # Iteration metrics
        self.num_prompt_tokens_iter = self.meter.create_counter(
            name="num_prompt_tokens_iter",
            unit="count",
            description="Number of prompt tokens in the current iteration"
        )
        self.num_generation_tokens_iter = self.meter.create_counter(
            name="num_generation_tokens_iter",
            unit="count",
            description="Number of generation tokens in the current iteration"
        )
        self.num_tokens_iter = self.meter.create_counter(
            name="num_tokens_iter",
            unit="count",
            description="Total number of tokens in the current iteration"
        )
        self.num_preemption_iter = self.meter.create_counter(
            name="num_preemption_iter",
            unit="count",
            description="Number of preemptions in the current iteration"
        )

        # Time metrics
        self.time_per_output_tokens = self.meter.create_counter(
            name="time_per_output_tokens",
            unit="ms",
            description="Time per output token in milliseconds"
        )

    def get_trace_headers(self):
        # Get current context
        current_span = trace.get_current_span()
        if not current_span:
            logger.debug("No current span found")
            return {}
        current_context = current_span.get_span_context()
        # Only inject if we have a valid context
        if current_context and hasattr(current_context, "trace_id") and hasattr(current_context, "span_id"):
            # Create trace headers
            trace_headers = {}
            # Create traceparent header
            trace_id_hex = format(current_context.trace_id, "032x")
            span_id_hex = format(current_context.span_id, "016x")
            flags = format(int(current_context.trace_flags) if hasattr(current_context, "trace_flags") else 1,
                           "02x")
            traceparent = f"00-{trace_id_hex}-{span_id_hex}-{flags}"
            trace_headers["traceparent"] = traceparent
            # Add tracestate if available
            if hasattr(current_context, "trace_state") and current_context.trace_state:
                trace_headers["tracestate"] = str(current_context.trace_state)

            logger.debug(f"Current trace headers : {trace_headers}")
            return trace_headers

    @staticmethod
    def extract_context_from_request(request):
        """
        Extract OpenTelemetry context from the request for cross-process propagation.

        Args:
            request: The request object to extract context from

        Returns:
            The extracted context or None if not found
        """
        try:
            if hasattr(request, "otel_context"):
                context_dict = request.otel_context

                # Import necessary modules
                from opentelemetry.trace.span import TraceFlags
                from opentelemetry.trace.span import SpanContext
                from opentelemetry.trace.span import TraceState

                # Create trace state if available
                trace_state = None
                if "trace_state" in context_dict and context_dict["trace_state"]:
                    trace_state = TraceState.from_string(context_dict["trace_state"])

                # Create span context
                span_context = SpanContext(
                    trace_id=context_dict["trace_id"],
                    span_id=context_dict["span_id"],
                    is_remote=True,
                    trace_flags=TraceFlags(context_dict["trace_flags"]),
                    trace_state=trace_state
                )

                logger.debug(f"Extracted OpenTelemetry context from request: {context_dict}")
                return span_context

            return None
        except Exception as e:
            logger.warning(f"Failed to extract OpenTelemetry context from request: {str(e)}")
            return None

    @staticmethod
    def wrap_target(original_target, arms_env):
        """Wrap the target function of a process."""
        return partial(VLLMWrapper.inner, original_target, arms_env)

    @staticmethod
    def inner(original_target, arms_env, *args, **kwargs):
        """Inner function to be called by the wrapped target."""
        try:
            # Set up environment variables for ARMS
            # TODO: add all arms related attributes here
            os.environ['ARMS_APP_NAME'] = arms_env.appName
            os.environ['ARMS_REGION_ID'] = arms_env.regionId
            os.environ['ARMS_LICENSE_KEY'] = arms_env.licenseKey
            os.environ['ARMS_WORKSPACE'] = arms_env.workspace
            if arms_env.hostTags:
                os.environ['ARMS_HOST_TAGS'] = arms_env.hostTags
            if global_arms_endpoints_state and global_arms_endpoints_state.network_strategy:
                os.environ['PROFILER_NETWORK_STRATEGY'] = global_arms_endpoints_state.network_strategy

            # Initialize OpenTelemetry
            from aliyun.opentelemetry.instrumentation.auto_instrumentation import sitecustomize
            sitecustomize.initialize()

            logger.debug(f"vLLM process initialized with PID: {os.getpid()}")
            return original_target(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in wrapped target: {str(e)}")
            raise

    @hook_advice(instrumentation_name="vllm", advice_method="vllm_metric")
    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[type, Any],
            kwargs: Mapping[str, Any],
    ) -> Any:
        method = wrapped.__qualname__
        if wrapped.__name__ == "__init__":
            response = wrapped(*args, **kwargs)
            try:
                trace_headers = self.get_trace_headers()
                logger.debug(f"current trace headers :{trace_headers}")
                instance.trace_headers = trace_headers
            except Exception as e:
                logger.exception("Failed to replace trace headers to current span info.")
            return response

        if method.endswith("start"):
            original_target = instance._target
            try:
                logger.debug(f"{ArmsEnv.instance().__dict__}")
                instance._target = self.wrap_target(instance._target, ArmsEnv.instance())
            except Exception as e:
                logger.exception("Failed to inject _target method to wrapped target.")
                instance._target = original_target
            return wrapped(*args, **kwargs)

        # Handle LoggingStatLogger.log
        if wrapped.__name__ == "log":
            stats = args[0]
            logger.debug(f"Stats({stats})")

            # Record GPU cache usage
            if hasattr(stats, "gpu_cache_usage_sys"):
                gpu_c = getattr(stats, "gpu_cache_usage_sys")
                if gpu_c >= 0:
                    self.gpu_cache_usage_sys_count.add(1, attributes=self.metrics_attributes)
            try:
                # Record specific metrics using counters
                self._record_specific_metrics(stats)
            except Exception as e:
                logger.exception("Failed to record metrics.")

        return wrapped(*args, **kwargs)

    def _record_specific_metrics(self, stats):
        """Record specific metrics from stats using counters."""
        try:
            # System metrics
            if hasattr(stats, "gpu_cache_usage_sys"):
                gpu_cache = getattr(stats, "gpu_cache_usage_sys")
                if gpu_cache >= 0:
                    self.gpu_cache_usage_sys.add(gpu_cache, attributes=self.metrics_attributes)

            if hasattr(stats, "cpu_cache_usage_sys"):
                cpu_cache = getattr(stats, "cpu_cache_usage_sys")
                if cpu_cache >= 0:
                    self.cpu_cache_usage_sys.add(cpu_cache, attributes=self.metrics_attributes)

            if hasattr(stats, "num_running_sys"):
                num_running = getattr(stats, "num_running_sys")
                if num_running >= 0:
                    self.num_running_sys.add(num_running, attributes=self.metrics_attributes)

            if hasattr(stats, "num_waiting_sys"):
                num_waiting = getattr(stats, "num_waiting_sys")
                if num_waiting >= 0:
                    self.num_waiting_sys.add(num_waiting, attributes=self.metrics_attributes)

            if hasattr(stats, "num_swapped_sys"):
                num_swapped = getattr(stats, "num_swapped_sys")
                if num_swapped >= 0:
                    self.num_swapped_sys.add(num_swapped, attributes=self.metrics_attributes)

            # Iteration metrics
            if hasattr(stats, "num_prompt_tokens_iter"):
                num_prompt_tokens = getattr(stats, "num_prompt_tokens_iter")
                if num_prompt_tokens >= 0:
                    self.num_prompt_tokens_iter.add(num_prompt_tokens, attributes=self.metrics_attributes)

            if hasattr(stats, "num_generation_tokens_iter"):
                num_gen_tokens = getattr(stats, "num_generation_tokens_iter")
                if num_gen_tokens >= 0:
                    self.num_generation_tokens_iter.add(num_gen_tokens, attributes=self.metrics_attributes)

            if hasattr(stats, "num_tokens_iter"):
                num_tokens = getattr(stats, "num_tokens_iter")
                if num_tokens >= 0:
                    self.num_tokens_iter.add(num_tokens, attributes=self.metrics_attributes)

            if hasattr(stats, "num_preemption_iter"):
                num_preemption = getattr(stats, "num_preemption_iter")
                if num_preemption >= 0:
                    self.num_preemption_iter.add(num_preemption, attributes=self.metrics_attributes)

            # Time metrics - handle lists
            if hasattr(stats, "time_per_output_tokens_iter"):
                time_per_output = getattr(stats, "time_per_output_tokens_iter")
                if isinstance(time_per_output, list) and time_per_output:
                    for time_value in time_per_output:
                        if time_value is not None and time_value >= 0:
                            # Convert to milliseconds
                            self.time_per_output_tokens.add(time_value * 1000, attributes=self.metrics_attributes)

        except Exception as e:
            logger.error(f"Failed to record specific metrics: {str(e)}")
