"""OpenTelemetry instrumentation for vLLM."""

import os
from typing import Any, Collection
from opentelemetry import trace as trace_api
from opentelemetry.trace import Tracer
from aliyun.opentelemetry.instrumentation.instrumentor import BaseInstrumentor
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.instrumentation.vllm.package import _instruments
from aliyun.instrumentation.vllm._wrapper import VLLMWrapper, VLLMTracingInstrumentor
from .completion import VLLMCompletionInstrumentor, TokenizerInstrumentor, PrefillInstrumentor, ChatInstrumentor

logger = getLogger(__name__)
_MODULE = "vllm.engine.metrics"

try:
    # from vllm.transformers_utils.tokenizer import AnyTokenizer, decode_tokens, encode_tokens
    HAS_VLLM = True
except ImportError:
    HAS_VLLM = False
    logger.exception("vLLM package is not installed. vLLM instrumentation will be disabled.")
    ChatCompletionRequest = ChatCompletionResponse = None


class AliyunVLLMInstrumentor(BaseInstrumentor):
    """An instrumentor for vLLM."""

    def instrumentation_dependencies(self) -> Collection[str]:
        return _instruments

    def _instrument(self, **kwargs: Any) -> None:
        """Instrument vLLM library.

        Args:
            **kwargs: Optional arguments for instrumentation.
                     Accepts tracer_provider.
        """
        if not HAS_VLLM:
            logger.warning("vLLM is not installed. Skipping instrumentation.")
            return

        if not (tracer_provider := kwargs.get("tracer_provider")):
            tracer_provider = trace_api.get_tracer_provider()

        # Get tracer
        tracer = tracer_provider.get_tracer(
            "aliyun.instrumentation.vllm",
            schema_url="https://opentelemetry.io/schemas/1.11.0",
        )

        from wrapt import wrap_function_wrapper

        # Original instrumentation
        wrap_function_wrapper(
            module=_MODULE,
            name="LoggingStatLogger.log",
            wrapper=VLLMWrapper(),
        )
        wrap_function_wrapper(
            module="multiprocessing.process",
            name="BaseProcess.start",
            wrapper=VLLMWrapper(),
        )
        wrap_function_wrapper(
            module="vllm.engine.multiprocessing.engine",
            name="RPCProcessRequest.__init__",
            wrapper=VLLMWrapper(),
        )
        wrap_function_wrapper(
            module="vllm.engine.llm_engine",
            name="LLMEngine.do_tracing",
            wrapper=VLLMTracingInstrumentor(tracer),
        )

        # OpenTelemetry instrumentation for completion methods
        completion_instrumentor = VLLMCompletionInstrumentor(tracer)
        wrap_function_wrapper(
            "vllm.entrypoints.openai.serving_completion",
            "OpenAIServingCompletion.create_completion",
            completion_instrumentor
        )
        wrap_function_wrapper(
            "vllm.entrypoints.openai.serving_completion",
            "OpenAIServingCompletion.completion_stream_generator",
            completion_instrumentor
        )
        # Wrap chat methods
        chat_instrumentor = ChatInstrumentor(tracer)
        wrap_function_wrapper(
            "vllm.entrypoints.openai.serving_chat",
            "OpenAIServingChat.create_chat_completion",
            chat_instrumentor
        )
        wrap_function_wrapper(
            "vllm.entrypoints.openai.serving_chat",
            "OpenAIServingChat.chat_completion_stream_generator",
            chat_instrumentor,
        )

    def _uninstrument(self, **kwargs: Any) -> None:
        """Remove vLLM instrumentation."""
        pass


# For backwards compatibility
__version__ = "0.1.0"
__all__ = ["AliyunVLLMInstrumentor"]
