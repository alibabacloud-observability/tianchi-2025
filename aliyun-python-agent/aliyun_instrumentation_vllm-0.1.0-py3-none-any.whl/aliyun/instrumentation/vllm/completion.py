from typing import Any, Dict, Optional, Union, AsyncGenerator, AsyncIterator, Tuple, Callable, Mapping, List
import json
from abc import ABC
import time

from opentelemetry import trace, metrics
from opentelemetry.trace import SpanKind, Tracer
from opentelemetry.trace.status import Status, StatusCode
from aliyun.semconv.trace import AliyunSpanKindValues, SpanAttributes, AliyunSpanSubKindValues, MessageAttributes
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.semconv.metrics import ArmsCommonServiceMetrics
from aliyun.sdk.extension.arms.common.utils.metrics_utils import get_llm_common_attributes
from opentelemetry.metrics import get_meter, Meter
from aliyun.instrumentation.vllm.version import __version__

try:
    from vllm.entrypoints.openai.protocol import (
        CompletionRequest, CompletionResponse, ErrorResponse,
        CompletionStreamResponse, RequestResponseMetadata, ChatCompletionRequest, ChatCompletionResponse
    )
    # from vllm.transformers_utils.tokenizer import AnyTokenizer, encode_tokens, decode_tokens
    from vllm.outputs import RequestOutput

    HAS_VLLM = True
except ImportError:
    HAS_VLLM = False
    logger = getLogger(__name__)
    logger.exception("vLLM package is not installed. vLLM instrumentation will be disabled.")
    CompletionRequest = CompletionResponse = ErrorResponse = None
    CompletionStreamResponse = RequestResponseMetadata = None
    AnyTokenizer = RequestOutput = None

logger = getLogger(__name__)
meter = get_meter(
    __name__,
    __version__,
    None,
    schema_url="https://opentelemetry.io/schemas/1.11.0",
)

# 最大内容长度限制（字符数）
MAX_CONTENT_LENGTH = 50000


def truncate_string(s: str, max_length: int = MAX_CONTENT_LENGTH) -> str:
    """截断过长的字符串，并添加指示符。

    Args:
        s: 要截断的字符串
        max_length: 最大长度限制

    Returns:
        截断后的字符串
    """
    if not isinstance(s, str):
        try:
            s = str(s)
        except Exception:
            return "[Non-string content]"

    if len(s) <= max_length:
        return s

    # 保留前后内容，中间用省略号表示
    half_length = (max_length - 3) // 2
    return s[:half_length] + "..." + s[-half_length:]


def record_token_usage(model_name: str, token_count: int, usage_type: str):
    """Record token usage metrics."""
    if model_name is None or (not isinstance(model_name, str)):
        return
    try:
        arms_metrics = ArmsCommonServiceMetrics(meter)
        attr = get_llm_common_attributes()
        attr["modelName"] = model_name
        attr["spanKind"] = AliyunSpanKindValues.LLM.value
        attr["usageType"] = usage_type
        arms_metrics.llm_usage_tokens.add(
            token_count,
            attributes=attr
        )
    except Exception as e:
        logger.exception(f"Failed to record token usage metrics: {str(e)}")


class TokenizerInstrumentor(ABC):
    """OpenTelemetry instrumentation for vLLM tokenizer methods."""

    def __init__(self, tracer: Tracer):
        self.tracer = tracer

    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Instrument the wrapped function."""
        if not HAS_VLLM:
            return wrapped(*args, **kwargs)

        method = wrapped.__qualname__

        if method.endswith("encode_tokens"):
            return self._instrument_encode(wrapped, instance, args, kwargs)
        elif method.endswith("decode_tokens"):
            return self._instrument_decode(wrapped, instance, args, kwargs)

    def _instrument_encode(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> List[int]:
        """Instrument the encode_tokens method."""
        tokenizer = args[0] if args else kwargs.get("tokenizer")
        text = args[1] if len(args) > 1 else kwargs.get("text")
        add_special_tokens = args[2] if len(args) > 2 else kwargs.get("add_special_tokens")

        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            SpanAttributes.GEN_AI_PROMPT_TEMPLATE: text,
            "add_special_tokens": str(add_special_tokens) if add_special_tokens is not None else "None",
        }

        logger.debug(f"vLLM encode_tokens request attributes: {json.dumps(attributes, indent=2)}")

        with self.tracer.start_as_current_span(
                "vllm.tokenizer.encode",
                attributes=attributes
        ) as span:
            try:
                token_ids = wrapped(*args, **kwargs)

                response_attributes = {
                    SpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS: len(token_ids),
                    "token_ids": str(token_ids),
                }

                logger.debug(f"vLLM encode_tokens response attributes: {json.dumps(response_attributes, indent=2)}")

                for key, value in response_attributes.items():
                    span.set_attribute(key, value)

                return token_ids

            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM encode_tokens exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise

    def _instrument_decode(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> str:
        """Instrument the decode_tokens method."""
        tokenizer = args[0] if args else kwargs.get("tokenizer")
        token_ids = args[1] if len(args) > 1 else kwargs.get("token_ids")
        skip_special_tokens = args[2] if len(args) > 2 else kwargs.get("skip_special_tokens", False)

        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            "token_ids": str(token_ids),
            "skip_special_tokens": str(skip_special_tokens),
            SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS: len(token_ids) if isinstance(token_ids,
                                                                                        (list, tuple)) else 1,
        }

        logger.debug(f"vLLM decode_tokens request attributes: {json.dumps(attributes, indent=2)}")

        with self.tracer.start_as_current_span(
                "vllm.tokenizer.decode",
                attributes=attributes
        ) as span:
            try:
                text = wrapped(*args, **kwargs)

                response_attributes = {
                    SpanAttributes.GEN_AI_COMPLETION: text,
                }

                logger.debug(f"vLLM decode_tokens response attributes: {json.dumps(response_attributes, indent=2)}")

                for key, value in response_attributes.items():
                    span.set_attribute(key, value)

                return text

            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM decode_tokens exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise


class VLLMCompletionInstrumentor(ABC):
    """OpenTelemetry instrumentation for vLLM completion methods."""

    def __init__(self, tracer: Tracer):
        self.tracer = tracer
        self._current_completion_span = None

    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Instrument the wrapped function."""
        if not HAS_VLLM:
            return wrapped(*args, **kwargs)

        method = wrapped.__qualname__

        if method.endswith("create_completion"):
            return self._instrument_completion(wrapped, instance, args, kwargs)
        elif method.endswith("completion_stream_generator"):
            return self._instrument_stream_completion(wrapped, instance, args, kwargs)

        return wrapped(*args, **kwargs)

    async def _instrument_completion(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Union[AsyncGenerator[str, None], CompletionResponse, ErrorResponse]:
        """Instrument the create_completion method."""
        if not HAS_VLLM:
            return await wrapped(*args, **kwargs)

        request = args[0] if args else kwargs.get("request")
        is_stream = request.stream if request.stream is not None else False
        # stream completion while record by _instrument_stream_completion
        if is_stream:
            return await wrapped(*args, **kwargs)

        if not isinstance(request, CompletionRequest):
            return await wrapped(*args, **kwargs)

        # Prepare attributes
        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            SpanAttributes.GEN_AI_REQUEST_MODEL_NAME: request.model,
            SpanAttributes.GEN_AI_REQUEST_TEMPERATURE: request.temperature if request.temperature is not None else 0.0,
            SpanAttributes.GEN_AI_REQUEST_TOP_P: request.top_p if request.top_p is not None else 1.0,
            SpanAttributes.GEN_AI_REQUEST_MAX_TOKENS: request.max_tokens if request.max_tokens is not None else 16,
            SpanAttributes.GEN_AI_PROMPT_TEMPLATE: truncate_string(str(request.prompt)),
            SpanAttributes.GEN_AI_REQUEST_IS_STREAM: request.stream if request.stream is not None else False,
            SpanAttributes.GEN_AI_USER_ID: request.user if request.user is not None else "",
            SpanAttributes.INPUT_VALUE: truncate_string(str(request.prompt)),
        }

        # Add prompt message attribute
        attributes[f"{SpanAttributes.GEN_AI_PROMPT}.0.{MessageAttributes.MESSAGE_CONTENT}"] = truncate_string(
            str(request.prompt))
        attributes[f"{SpanAttributes.GEN_AI_PROMPT}.0.{MessageAttributes.MESSAGE_ROLE}"] = "user"

        # Debug logging
        logger.debug(f"vLLM completion request attributes: {json.dumps(attributes, indent=2)}")

        with self.tracer.start_as_current_span(
                "vllm.completion",
                attributes=attributes
        ) as span:
            self._current_completion_span = span
            try:
                response = await wrapped(*args, **kwargs)
                try:
                    # Handle different response types
                    if isinstance(response, CompletionResponse):
                        response_attributes = {
                            SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS: response.usage.completion_tokens,
                            SpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS: response.usage.prompt_tokens,
                            SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS: response.usage.total_tokens,
                        }

                        if response.choices and len(response.choices) > 0:
                            # Use first choice as the main completion
                            completion_text = response.choices[0].text
                            response_attributes[SpanAttributes.GEN_AI_COMPLETION] = truncate_string(completion_text)
                            response_attributes[SpanAttributes.OUTPUT_VALUE] = truncate_string(completion_text)

                            # Record all choices
                            for i, choice in enumerate(response.choices):
                                response_attributes[
                                    f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.{MessageAttributes.MESSAGE_CONTENT}"] = truncate_string(
                                    choice.text)
                                role = "assistant"
                                if getattr(choice, "role"):
                                    role = choice.role
                                response_attributes[
                                    f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.{MessageAttributes.MESSAGE_ROLE}"] = role
                                if choice.finish_reason:
                                    response_attributes[
                                        f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.finish_reason"] = choice.finish_reason

                            # Keep the first choice's finish reason in the original attribute for backward compatibility
                            if response.choices[0].finish_reason:
                                response_attributes[SpanAttributes.GEN_AI_RESPONSE_FINISH_REASON] = response.choices[
                                    0].finish_reason

                        logger.debug(f"vLLM completion response attributes: {json.dumps(response_attributes, indent=2)}")

                        for key, value in response_attributes.items():
                            span.set_attribute(key, value)

                    elif isinstance(response, ErrorResponse):
                        error_msg = str(response)
                        logger.error(f"vLLM completion error: {error_msg}")
                        span.set_status(Status(StatusCode.ERROR, error_msg))
                        span.record_exception(Exception(error_msg))
                except Exception as e:
                    pass

                return response

            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM completion exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise
            finally:
                self._current_completion_span = None

    async def _instrument_stream_completion(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> AsyncGenerator[str, None]:
        """Instrument the completion_stream_generator method."""
        if not HAS_VLLM:
            async for item in wrapped(*args, **kwargs):
                yield item
            return

        request = args[0] if args else kwargs.get("request")
        request_id = args[2] if len(args) > 2 else kwargs.get("request_id")
        model_name = args[4] if len(args) > 4 else kwargs.get("model_name")
        num_prompts = args[5] if len(args) > 5 else kwargs.get("num_prompts")

        if not all([isinstance(request, CompletionRequest), request_id, model_name, num_prompts]):
            async for item in wrapped(*args, **kwargs):
                yield item
            return

        # Prepare attributes
        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            SpanAttributes.GEN_AI_REQUEST_MODEL_NAME: model_name,
            SpanAttributes.GEN_AI_REQUEST_TEMPERATURE: request.temperature if request.temperature is not None else 0.0,
            SpanAttributes.GEN_AI_REQUEST_TOP_P: request.top_p if request.top_p is not None else 1.0,
            SpanAttributes.GEN_AI_REQUEST_MAX_TOKENS: request.max_tokens if request.max_tokens is not None else 16,
            SpanAttributes.GEN_AI_PROMPT_TEMPLATE: truncate_string(str(request.prompt)),
            SpanAttributes.INPUT_VALUE: truncate_string(str(request.prompt)),
            SpanAttributes.GEN_AI_REQUEST_IS_STREAM: True,
            SpanAttributes.GEN_AI_USER_ID: request.user if request.user is not None else "",
            SpanAttributes.SESSION_ID: request_id,
            "num_prompts": num_prompts,
        }

        # Add prompt message attribute
        attributes[f"{SpanAttributes.GEN_AI_PROMPT}.0.{MessageAttributes.MESSAGE_CONTENT}"] = truncate_string(
            str(request.prompt))
        attributes[f"{SpanAttributes.GEN_AI_PROMPT}.0.{MessageAttributes.MESSAGE_ROLE}"] = "user"

        logger.debug(f"vLLM stream completion request attributes: {json.dumps(attributes, indent=2)}")

        with self.tracer.start_as_current_span(
                "vllm.completion.stream",
                attributes=attributes
        ) as span:
            self._current_completion_span = span
            try:
                total_tokens = 0
                total_completion_tokens = 0
                full_completion_text = []

                async for chunk in wrapped(*args, **kwargs):
                    logger.debug(f"Raw chunk received: {chunk}")

                    try:
                        if not isinstance(chunk, str):
                            logger.debug(f"Skipping non-string chunk: {type(chunk)}")
                            continue

                        if not chunk.startswith("data: "):
                            logger.debug(f"Skipping chunk without 'data: ' prefix: {chunk}")
                            continue

                        data_part = chunk.split("data: ", 1)[1].strip()
                        logger.debug(f"Extracted data part: {data_part}")

                        if data_part == "[DONE]":
                            final_completion = "".join(full_completion_text)
                            span.set_attribute(SpanAttributes.GEN_AI_PROMPT, str(request.prompt))
                            span.set_attribute(SpanAttributes.GEN_AI_COMPLETION, final_completion)
                            span.set_attribute(SpanAttributes.OUTPUT_VALUE, final_completion)
                            span.set_attribute(
                                f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_CONTENT}",
                                truncate_string(final_completion))
                            span.set_attribute(f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_ROLE}",
                                               "assistant")
                            logger.debug(f"Stream completion finished. Final completion text: {final_completion}")
                        else:
                            try:
                                chunk_data = json.loads(data_part)
                                logger.debug(f"Parsed chunk data: {json.dumps(chunk_data, indent=2)}")

                                if not isinstance(chunk_data, dict):
                                    logger.debug(f"Skipping non-dict chunk data: {type(chunk_data)}")
                                    continue

                                if "choices" in chunk_data and chunk_data["choices"]:
                                    choice = chunk_data["choices"][0]
                                    if isinstance(choice, dict):
                                        text = choice.get("text", "")
                                        if text:
                                            full_completion_text.append(text)
                                            logger.debug(f"Added text to completion: {text}")

                                if "usage" in chunk_data and chunk_data["usage"]:
                                    usage = chunk_data["usage"]
                                    if isinstance(usage, dict):
                                        total_tokens = usage.get("total_tokens", total_tokens)
                                        total_completion_tokens = usage.get("completion_tokens",
                                                                            total_completion_tokens)
                                        span.set_attribute(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS, total_tokens)
                                        span.set_attribute(SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS,
                                                           total_completion_tokens)

                                        # Record token usage metrics for streaming
                                        prompt_tokens = usage.get("prompt_tokens", 0)
                                        if prompt_tokens > 0:
                                            record_token_usage(model_name, prompt_tokens, "input")
                                        if total_completion_tokens > 0:
                                            record_token_usage(model_name, total_completion_tokens, "output")

                                        logger.debug(
                                            f"Updated token counts - total: {total_tokens}, completion: {total_completion_tokens}")

                            except json.JSONDecodeError as e:
                                logger.exception(f"JSON decode error for data part: {data_part}, error: {str(e)}")
                                continue

                    except Exception as e:
                        logger.error(f"Error processing chunk: {str(e)}, chunk: {chunk}")
                        continue

                    yield chunk

                final_completion = "".join(full_completion_text)
                span.set_attribute(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS, total_tokens)
                span.set_attribute(SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS, total_completion_tokens)
                span.set_attribute(SpanAttributes.GEN_AI_COMPLETION, final_completion)
                span.set_attribute(SpanAttributes.OUTPUT_VALUE, final_completion)
                span.set_attribute(f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_CONTENT}",
                                   truncate_string(final_completion))
                span.set_attribute(f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_ROLE}",
                                   "assistant")
                logger.debug(
                    f"Stream completion finished. Total tokens: {total_tokens}, Completion tokens: {total_completion_tokens}")
                logger.debug(f"Final completion text: {final_completion}")

            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM stream completion exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise
            finally:
                self._current_completion_span = None


class ChatInstrumentor(ABC):
    """OpenTelemetry instrumentation for vLLM chat methods."""

    def __init__(self, tracer: Tracer):
        self.tracer = tracer
        self._current_chat_span = None

    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Instrument the wrapped function."""
        if not HAS_VLLM:
            return wrapped(*args, **kwargs)

        method = wrapped.__qualname__

        if method.endswith("create_chat_completion"):
            return self._instrument_chat_completion(wrapped, instance, args, kwargs)
        elif method.endswith("chat_completion_stream_generator"):
            return self._instrument_chat_stream_completion(wrapped, instance, args, kwargs)

        return wrapped(*args, **kwargs)

    async def _instrument_chat_completion(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Union[AsyncGenerator[str, None], CompletionResponse, ErrorResponse]:
        """Instrument the create_chat_completion method."""
        if not HAS_VLLM:
            return await wrapped(*args, **kwargs)

        request = args[0] if args else kwargs.get("request")
        is_stream = request.stream if request.stream is not None else False
        # stream span while be record by _instrument_chat_stream_completion
        if is_stream:
            return await wrapped(*args, **kwargs)

        if not isinstance(request, ChatCompletionRequest):
            return await wrapped(*args, **kwargs)

        # Format messages for input value
        input_value = truncate_string(str(
            [{"role": msg.get('role', ''), "content": truncate_string(msg.get('content', ''))} for msg in
             request.messages]))
        # Prepare attributes
        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            SpanAttributes.GEN_AI_REQUEST_MODEL_NAME: request.model,
            SpanAttributes.GEN_AI_REQUEST_TEMPERATURE: request.temperature if request.temperature is not None else 0.0,
            SpanAttributes.GEN_AI_REQUEST_TOP_P: request.top_p if request.top_p is not None else 1.0,
            SpanAttributes.GEN_AI_REQUEST_MAX_TOKENS: request.max_tokens if request.max_tokens is not None else 16,
            SpanAttributes.GEN_AI_REQUEST_IS_STREAM: request.stream if request.stream is not None else False,
            SpanAttributes.GEN_AI_USER_ID: request.user if request.user is not None else "",
            SpanAttributes.INPUT_VALUE: input_value,
        }

        # Add formatted message attributes for each prompt message
        for i, msg in enumerate(request.messages):
            attributes[f"{SpanAttributes.GEN_AI_PROMPT}.{i}.{MessageAttributes.MESSAGE_CONTENT}"] = truncate_string(
                msg.get('content', ''))
            attributes[f"{SpanAttributes.GEN_AI_PROMPT}.{i}.{MessageAttributes.MESSAGE_ROLE}"] = msg.get('role', '')

        logger.debug(f"vLLM chat completion request attributes: {json.dumps(attributes, indent=2)}")

        with self.tracer.start_as_current_span(
                "vllm.chat.completion",
                attributes=attributes
        ) as span:
            self._current_chat_span = span
            try:
                response = await wrapped(*args, **kwargs)

                if isinstance(response, ChatCompletionResponse):
                    response_attributes = {
                        SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS: response.usage.completion_tokens,
                        SpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS: response.usage.prompt_tokens,
                        SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS: response.usage.total_tokens,
                    }

                    # Record token usage metrics
                    record_token_usage(request.model, response.usage.prompt_tokens, "input")
                    record_token_usage(request.model, response.usage.completion_tokens, "output")

                    if response.choices and len(response.choices) > 0:
                        # Use first choice as the main completion
                        output_content = response.choices[0].message.content
                        output_role = response.choices[0].message.role
                        response_attributes[SpanAttributes.GEN_AI_COMPLETION] = truncate_string(output_content)
                        response_attributes[SpanAttributes.OUTPUT_VALUE] = truncate_string(output_content)

                        # Record all choices
                        for i, choice in enumerate(response.choices):
                            response_attributes[
                                f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.{MessageAttributes.MESSAGE_CONTENT}"] = truncate_string(
                                choice.message.content)
                            response_attributes[
                                f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.{MessageAttributes.MESSAGE_ROLE}"] = choice.message.role
                            if choice.finish_reason:
                                response_attributes[
                                    f"{SpanAttributes.GEN_AI_COMPLETION}.{i}.finish_reason"] = choice.finish_reason

                        # Keep the first choice's finish reason in the original attribute for backward compatibility
                        if response.choices[0].finish_reason:
                            response_attributes[SpanAttributes.GEN_AI_RESPONSE_FINISH_REASON] = response.choices[
                                0].finish_reason

                    logger.debug(
                        f"vLLM chat completion response attributes: {json.dumps(response_attributes, indent=2)}")

                    for key, value in response_attributes.items():
                        span.set_attribute(key, value)

                elif isinstance(response, ErrorResponse):
                    error_msg = str(response)
                    logger.error(f"vLLM chat completion error: {error_msg}")
                    span.set_status(Status(StatusCode.ERROR, error_msg))
                    span.record_exception(Exception(error_msg))

                return response

            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM chat completion exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise
            finally:
                self._current_chat_span = None

    async def _instrument_chat_stream_completion(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> AsyncGenerator[str, None]:
        """Instrument the chat_completion_stream_generator method."""
        if not HAS_VLLM:
            async for item in wrapped(*args, **kwargs):
                yield item
            return

        request = args[0] if args else kwargs.get("request")
        request_id = args[2] if len(args) > 2 else kwargs.get("request_id")
        model_name = args[4] if len(args) > 4 else kwargs.get("model_name")
        num_messages = len(request.messages) if request and hasattr(request, "messages") else 0

        if not all([isinstance(request, ChatCompletionRequest), request_id, model_name]):
            async for item in wrapped(*args, **kwargs):
                yield item
            return

        # Format messages for input value
        input_value = truncate_string(str(
            [{"role": msg.get('role', ''), "content": truncate_string(msg.get('content', ''))} for msg in
             request.messages]))
        # Prepare attributes
        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            SpanAttributes.GEN_AI_REQUEST_MODEL_NAME: model_name,
            SpanAttributes.GEN_AI_REQUEST_TEMPERATURE: request.temperature if request.temperature is not None else 0.0,
            SpanAttributes.GEN_AI_REQUEST_TOP_P: request.top_p if request.top_p is not None else 1.0,
            SpanAttributes.GEN_AI_REQUEST_MAX_TOKENS: request.max_tokens if request.max_tokens is not None else 16,
            SpanAttributes.GEN_AI_REQUEST_IS_STREAM: True,
            SpanAttributes.GEN_AI_USER_ID: request.user if request.user is not None else "",
            SpanAttributes.SESSION_ID: request_id,
            "num_messages": num_messages,
            SpanAttributes.INPUT_VALUE: input_value,
        }

        # Add formatted message attributes for each prompt message
        for i, msg in enumerate(request.messages):
            attributes[f"{SpanAttributes.GEN_AI_PROMPT}.{i}.{MessageAttributes.MESSAGE_CONTENT}"] = truncate_string(
                msg.get('content', ''))
            attributes[f"{SpanAttributes.GEN_AI_PROMPT}.{i}.{MessageAttributes.MESSAGE_ROLE}"] = msg.get('role', '')

        logger.debug(f"vLLM chat stream completion request attributes: {json.dumps(attributes, indent=2)}")

        with self.tracer.start_as_current_span(
                "vllm.chat.completion.stream",
                attributes=attributes
        ) as span:
            self._current_chat_span = span
            try:
                total_tokens = 0
                total_completion_tokens = 0
                full_completion_text = []

                async for chunk in wrapped(*args, **kwargs):
                    logger.debug(f"Raw chat chunk received: {chunk}")

                    try:
                        if not isinstance(chunk, str):
                            logger.debug(f"Skipping non-string chunk: {type(chunk)}")
                            continue

                        if not chunk.startswith("data: "):
                            logger.debug(f"Skipping chunk without 'data: ' prefix: {chunk}")
                            continue

                        data_part = chunk.split("data: ", 1)[1].strip()
                        logger.debug(f"Extracted data part: {data_part}")

                        if data_part == "[DONE]":
                            final_completion = "".join(full_completion_text)
                            span.set_attribute(SpanAttributes.GEN_AI_COMPLETION, truncate_string(final_completion))
                            span.set_attribute(SpanAttributes.OUTPUT_VALUE, truncate_string(final_completion))
                            span.set_attribute(
                                f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_CONTENT}",
                                truncate_string(final_completion))
                            span.set_attribute(f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_ROLE}",
                                               "assistant")
                            logger.debug(f"Stream chat completion finished. Final completion text: {final_completion}")
                        else:
                            try:
                                chunk_data = json.loads(data_part)
                                logger.debug(f"Parsed chunk data: {json.dumps(chunk_data, indent=2)}")

                                if not isinstance(chunk_data, dict):
                                    logger.debug(f"Skipping non-dict chunk data: {type(chunk_data)}")
                                    continue

                                if "choices" in chunk_data and chunk_data["choices"]:
                                    choice = chunk_data["choices"][0]
                                    if isinstance(choice, dict) and "delta" in choice:
                                        delta = choice["delta"]
                                        if isinstance(delta, dict) and "content" in delta:
                                            text = delta["content"]
                                            if text:
                                                full_completion_text.append(text)
                                                logger.debug(f"Added text to chat completion: {text}")

                                if "usage" in chunk_data and chunk_data["usage"]:
                                    usage = chunk_data["usage"]
                                    if isinstance(usage, dict):
                                        total_tokens = usage.get("total_tokens", total_tokens)
                                        total_completion_tokens = usage.get("completion_tokens",
                                                                            total_completion_tokens)
                                        span.set_attribute(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS, total_tokens)
                                        span.set_attribute(SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS,
                                                           total_completion_tokens)

                                        # Record token usage metrics for streaming
                                        prompt_tokens = usage.get("prompt_tokens", 0)
                                        if prompt_tokens > 0:
                                            record_token_usage(model_name, prompt_tokens, "input")
                                        if total_completion_tokens > 0:
                                            record_token_usage(model_name, total_completion_tokens, "output")

                                        logger.debug(
                                            f"Updated token counts - total: {total_tokens}, completion: {total_completion_tokens}")

                            except json.JSONDecodeError as e:
                                logger.debug(f"JSON decode error for data part: {data_part}, error: {str(e)}")
                                continue

                    except Exception as e:
                        logger.error(f"Error processing chat chunk: {str(e)}, chunk: {chunk}")
                        continue

                    yield chunk

                final_completion = "".join(full_completion_text)
                span.set_attribute(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS, total_tokens)
                span.set_attribute(SpanAttributes.GEN_AI_USAGE_COMPLETION_TOKENS, total_completion_tokens)
                span.set_attribute(SpanAttributes.GEN_AI_COMPLETION, truncate_string(final_completion))
                span.set_attribute(SpanAttributes.OUTPUT_VALUE, truncate_string(final_completion))
                span.set_attribute(f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_CONTENT}",
                                   truncate_string(final_completion))
                span.set_attribute(f"{SpanAttributes.GEN_AI_COMPLETION}.0.{MessageAttributes.MESSAGE_ROLE}",
                                   "assistant")
                logger.debug(
                    f"Stream chat completion finished. Total tokens: {total_tokens}, Completion tokens: {total_completion_tokens}")
                logger.debug(f"Final chat completion text: {final_completion}")

            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM chat stream completion exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise
            finally:
                self._current_chat_span = None


class PrefillInstrumentor(ABC):
    """OpenTelemetry instrumentation for vLLM prefill operations."""

    def __init__(self, tracer: Tracer):
        self.tracer = tracer
        self.completion_instrumentor = None

    def set_completion_instrumentor(self, completion_instrumentor: VLLMCompletionInstrumentor):
        """Set the completion instrumentor to access the current completion span."""
        self.completion_instrumentor = completion_instrumentor

    def __call__(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Instrument the wrapped function."""
        if not HAS_VLLM:
            return wrapped(*args, **kwargs)

        method = wrapped.__qualname__

        if method.endswith("forward"):
            return self._instrument_prefill_forward(wrapped, instance, args, kwargs)
        elif method.endswith("_schedule_prefills"):
            return self._instrument_prefill_schedule(wrapped, instance, args, kwargs)

        return wrapped(*args, **kwargs)

    def _instrument_prefill_forward(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Instrument the prefill forward pass."""
        attn_metadata = kwargs.get("attn_metadata", None)
        if attn_metadata is None and len(args) >= 7:
            attn_metadata = args[6]

        if attn_metadata is None or not hasattr(attn_metadata,
                                                "prefill_metadata") or attn_metadata.prefill_metadata is None:
            return wrapped(*args, **kwargs)

        prefill_meta = attn_metadata.prefill_metadata
        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            SpanAttributes.GEN_AI_USAGE_PROMPT_TOKENS: prefill_meta.num_prefill_tokens,
            "num_prefills": prefill_meta.num_prefills,
            "max_prefill_seq_len": getattr(prefill_meta, "max_prefill_seq_len", 0),
        }

        logger.debug(f"vLLM prefill forward attributes: {json.dumps(attributes, indent=2)}")

        parent_context = None
        if self.completion_instrumentor and self.completion_instrumentor._current_completion_span:
            parent_context = trace.get_current_span(
                self.completion_instrumentor._current_completion_span.get_span_context())

        with self.tracer.start_as_current_span(
                "vllm.prefill.forward",
                attributes=attributes,
                parent=parent_context
        ) as span:
            try:
                start_time = time.time()
                output = wrapped(*args, **kwargs)
                duration = time.time() - start_time

                response_attributes = {
                    "prefill_forward_time_ms": duration * 1000,
                }

                logger.debug(f"vLLM prefill forward response: {json.dumps(response_attributes, indent=2)}")

                for key, value in response_attributes.items():
                    span.set_attribute(key, value)

                return output
            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM prefill forward exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise

    def _instrument_prefill_schedule(
            self,
            wrapped: Callable[..., Any],
            instance: Any,
            args: Tuple[Any, ...],
            kwargs: Mapping[str, Any],
    ) -> Any:
        """Instrument the prefill scheduling."""
        enable_chunking = kwargs.get("enable_chunking", False)
        attributes = {
            SpanAttributes.GEN_AI_SPAN_KIND: AliyunSpanKindValues.LLM.value,
            "enable_chunking": enable_chunking,
        }

        logger.debug(f"vLLM prefill schedule attributes: {json.dumps(attributes, indent=2)}")

        parent_context = None
        if self.completion_instrumentor and self.completion_instrumentor._current_completion_span:
            parent_context = trace.get_current_span(
                self.completion_instrumentor._current_completion_span.get_span_context())

        with self.tracer.start_as_current_span(
                "vllm.prefill.schedule",
                attributes=attributes,
                context=parent_context
        ) as span:
            try:
                start_time = time.time()
                output = wrapped(*args, **kwargs)
                duration = time.time() - start_time

                if hasattr(output, "seq_groups"):
                    response_attributes = {
                        "num_scheduled_seq_groups": len(output.seq_groups),
                        "scheduling_time_ms": duration * 1000,
                    }

                    logger.debug(f"vLLM prefill schedule response: {json.dumps(response_attributes, indent=2)}")

                    for key, value in response_attributes.items():
                        span.set_attribute(key, value)

                return output
            except Exception as e:
                error_msg = str(e)
                logger.error(f"vLLM prefill schedule exception: {error_msg}")
                span.set_status(Status(StatusCode.ERROR, error_msg))
                span.record_exception(e)
                raise
