from typing import Collection
import wrapt

from vllm.entrypoints.openai.serving_completion import OpenAIServingCompletion
from .completion import instrument_completion

def _patch_completion():
    """Patch the create_completion method with OpenTelemetry instrumentation."""
    wrapt.wrap_function_wrapper(
        "vllm.entrypoints.openai.serving_completion",
        "OpenAIServingCompletion.create_completion",
        instrument_completion
    )

def patch() -> None:
    """Patch all monitored vLLM functions."""
    _patch_completion() 