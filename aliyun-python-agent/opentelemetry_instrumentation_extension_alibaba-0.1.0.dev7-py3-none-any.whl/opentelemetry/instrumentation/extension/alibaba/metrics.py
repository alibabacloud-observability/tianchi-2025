import gc
import logging
import os
import platform
import time

from opentelemetry.instrumentation.extension.alibaba import _use_aliyun_pkg

if _use_aliyun_pkg:
    from aliyun.opentelemetry.instrumentation.instrumentor import BaseInstrumentor
    from opentelemetry.metrics import get_meter
else:
    from opentelemetry.instrumentation.instrumentor import BaseInstrumentor
    from opentelemetry.metrics import get_meter


from opentelemetry.instrumentation.extension.alibaba.package import _instruments
from opentelemetry.instrumentation.extension.alibaba.version import __version__

from opentelemetry.instrumentation.extension.alibaba.util import rename_metric_name

_logger = logging.getLogger(__name__)
_gen_attrs = [{"generation": 0}, {"generation": 1}, {"generation": 2}]


class MetricsInstrumentor(BaseInstrumentor):
    def __init__(self):
        super().__init__()
        self._meter = None
        self._gc_callback_registered = False

    def _instrument(self, **kwargs):
        provider = kwargs.get("meter_provider")
        self._meter = get_meter(__name__, __version__, provider)
        self._create_gc_metrics()

    def _uninstrument(self, **__):
        if self._gc_callback_registered:
            gc.callbacks.remove(self._gc_callback)

    def instrumentation_dependencies(self):
        return _instruments

    def _create_gc_metrics(self):
        if platform.python_implementation() != "CPython" or not hasattr(gc, "callbacks"):
            _logger.warning("gc.callbacks is not supported")
            return

        self._gc_total_time = self._meter.create_histogram(rename_metric_name("process.runtime.gc_total_time"),
                                                           "ms",
                                                           "Total time of GC")
        self._gc_start_time = -1

        def _callback(phase, info):
            if os.getenv('ENABLE_GC_TOTAL_TIME_CALLBACK', True):
                if phase == "start":
                    self._gc_start_time = time.time_ns()
                    pass
                elif self._gc_start_time > 0:
                    duration_in_ms = round((time.time_ns() - self._gc_start_time) / 10 ** 6)
                    self._gc_total_time.record(duration_in_ms, _gen_attrs[info["generation"]])
                    self._gc_start_time = -1

        self._gc_callback = _callback
        gc.callbacks.append(self._gc_callback)
        self._gc_callback_registered = True
