_disabled = False


def disable_renaming():
    global _disabled
    _disabled = True


def rename_metric_name(name: str):
    if _disabled:
        return name
    return 'arms_python_' + name.replace(".", "_")

