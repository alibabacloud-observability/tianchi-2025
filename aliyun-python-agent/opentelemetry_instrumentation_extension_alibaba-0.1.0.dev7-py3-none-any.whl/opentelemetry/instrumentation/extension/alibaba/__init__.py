_use_aliyun_pkg = False

try:
    from aliyun.opentelemetry.instrumentation.instrumentor import BaseInstrumentor
    _use_aliyun_pkg = True
except ImportError:
    pass


from opentelemetry.instrumentation.extension.alibaba.metrics import MetricsInstrumentor
from opentelemetry.instrumentation.extension.alibaba.system_metrics import SystemMetricsInstrumentor

__all__ = [
    "MetricsInstrumentor",
    "SystemMetricsInstrumentor",
]

