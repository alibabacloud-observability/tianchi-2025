from aliyun.sdk.extension.arms.semconv import attributes as ArmsAttributes
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.opentelemetry.semconv.trace import SpanAttributes
from aliyun.sdk.extension.arms.convergence import converge, TargetType
from urllib.parse import urlparse

ARMS_ENDPOINT = "endpoint"
ARMS_DEST_ID = "destId"
ARMS_COMPONENT_NAME = "component.name"
ARMS_RPC = "rpc"
ARMS_RPC_TYPE = "rpcType"
ARMS_CALLKIND = "callKind"
ARMS_CALLTYPE = "callType"
ARMS_PPID = "ppid"
ARMS_PRPC = "prpc"
ARMS_SERVICETYPE = "serviceType"
ARMS_STATUS = "status"
ARMS_EXCEP_NAME = "excepName"
ARMS_EXCEP_INFO = "excepInfo"
ARMS_EXCEP_TYPE = "excepType"
ARMS_HTTP_METHOD = "http.method"
ARMS_OUT_ID = "out.ids"
ARMS_NET_PROTOCOL_NAME = "net.protocol.name"
IPV4 = "ipv4"
APP = "app"


def collect_arms_request_attributes(environ, rpc, base_request_getter):
    base_result = base_request_getter(environ)
    host = base_result.get(ArmsAttributes.HOST)
    host = converge(TargetType.url, host)
    if host is None or host == "":
        host = base_result.get(SpanAttributes.HTTP_HOST)
    base_result[ARMS_DEST_ID] = host
    path = base_result.get(SpanAttributes.URL_PATH)
    path = converge(TargetType.url, path)
    # prpc = converge(TargetType.prpc, prpc)
    if path is None or path == "":
        url = base_result.get(SpanAttributes.HTTP_URL)
        if url is not None and url != "":
            parsed_url = urlparse(url)
            path = parsed_url.path
    conv_path = converge(TargetType.url, path)
    if conv_path:
        base_result[ARMS_ENDPOINT] = conv_path
    base_result[ARMS_COMPONENT_NAME] = "django"
    if rpc:
        base_result[ARMS_RPC] = rpc
    base_result[ARMS_CALLKIND] = "http"
    base_result[ARMS_CALLTYPE] = "http"
    base_result[ARMS_RPC_TYPE] = 0
    if host:
        base_result[ARMS_OUT_ID] = host
    base_result[ARMS_NET_PROTOCOL_NAME] = "HTTP"
    if ArmsEnv.instance().ip:
        base_result[IPV4] = ArmsEnv.instance().ip
    base_result[APP] = ArmsEnv.instance().appName

    return base_result


def convert_status_code(status_code):
    global status
    if status_code == 200:
        status = "200"
    elif 200 < status_code < 300:
        status = "2xx"
    elif 300 <= status_code < 400:
        status = "3xx"
    elif 400 <= status_code < 500:
        status = "4xx"
    elif 100 <= status_code < 200:
        status = "1xx"
    else:
        status = "5xx"
    return status


def collect_excep_attributes(excep, metrics_attr):
    excep_attr = {
        "excep.ids": excep.get_exception_id(),
    }
    metrics_attr[ARMS_EXCEP_TYPE] = excep.get_exception_id()
    metrics_attr[ARMS_EXCEP_INFO] = "c4"
    metrics_attr[ARMS_EXCEP_NAME] = excep.get_exception_name()
    return excep_attr


metrics_attrs_key = {"rpcType", "serviceType", "pid", "service", "rpc", "host", "prpc", "ppid", "destId", "endpoint",
                     "excepType", "excepInfo", "excepName", "sqlId", "serverIp", "quantile", "status", "opType",
                     "tableName", "request.size", "response.size", "result_bytes", "result_size", "delay_milliseconds",
                     "messaging.consume.delay_ms", "hit_count", "_ext_err_source", "callKind", "callType"}


def cut_metrics_attributes(attributes):
    metrics_attributes = {}
    for key in metrics_attrs_key:
        if key in attributes:
            metrics_attributes[key] = attributes[key]
    return metrics_attributes
