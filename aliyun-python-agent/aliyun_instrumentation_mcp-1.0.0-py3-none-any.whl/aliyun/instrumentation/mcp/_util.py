from typing import Any
import json
import importlib.metadata
from os import environ

OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT = "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"
OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT_MAX_LENGTH = (
    "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT_MAX_LENGTH"
)

_has_mcp_types = False
try:
    from mcp.types import (
        BlobResourceContents,
        TextResourceContents,
    )

    _has_mcp_types = True
except ImportError:
    _has_mcp_types = False

MIN_SUPPORTED_VERSION = (1, 3, 0)
MAX_SUPPORTED_VERSION = (1, 12, 4)
MCP_PACKAGE_NAME = "mcp"
DEFAULT_MAX_ATTRIBUTE_LENGTH = 1024 * 1024

MAX_ATTRIBUTE_LENGTH = None


def _parse_max_attribute_length() -> int:
    length_str = environ.get(OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT_MAX_LENGTH)
    if not length_str:
        return DEFAULT_MAX_ATTRIBUTE_LENGTH
    try:
        length = int(length_str)
        if length > 0:
            return length
    except ValueError:
        pass
    return DEFAULT_MAX_ATTRIBUTE_LENGTH


def _get_max_attribute_length() -> int:
    global MAX_ATTRIBUTE_LENGTH
    if MAX_ATTRIBUTE_LENGTH is not None:
        return MAX_ATTRIBUTE_LENGTH
    MAX_ATTRIBUTE_LENGTH = _parse_max_attribute_length()
    return MAX_ATTRIBUTE_LENGTH


def _is_ws_installed():
    try:
        import websockets

        return True
    except ImportError:
        return False


def _get_mcp_version():
    version = importlib.metadata.version(MCP_PACKAGE_NAME)
    version_parts = version.split(".")
    major = int(version_parts[0])
    minor = int(version_parts[1]) if len(version_parts) > 1 else 0
    patch = int(version_parts[2]) if len(version_parts) > 2 else 0
    return major, minor, patch


def _is_version_supported():
    try:
        current_version = _get_mcp_version()
    except Exception as _:
        return False

    return MIN_SUPPORTED_VERSION <= current_version and current_version <= MAX_SUPPORTED_VERSION


def _is_capture_content_enabled() -> bool:
    capture_content = environ.get(OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT, "true")
    return _is_true_value(capture_content)


def _safe_dump_attributes(obj: Any) -> str:
    return _safe_json_dumps(obj, _get_max_attribute_length())


def _safe_json_dumps(obj: Any, max_length: int = -1) -> str:
    try:
        chunks = []
        current_chunks_length = 0
        encoder = json.JSONEncoder()
        for chunk in encoder.iterencode(obj):
            chunks.append(chunk)
            current_chunks_length += len(chunk)
            if max_length > 0 and current_chunks_length > max_length:
                break
        result = "".join(chunks)
        return result[:max_length] if max_length > 0 else result
    except Exception:
        return ""


def _get_content_size(content) -> int:
    if not hasattr(content, "type"):
        return 0
    if content.type == "text" and hasattr(content, "text"):
        return len(content.text)
    if content.type == "image" and hasattr(content, "data"):
        return len(content.data)
    if content.type == "audio" and hasattr(content, "data"):
        return len(content.data)
    return 0


def _get_resource_result_size(resource_result) -> int | None:
    if not _has_mcp_types or not hasattr(resource_result, "contents"):
        return None
    size = 0
    for content in resource_result.contents:
        if isinstance(content, TextResourceContents) and hasattr(content, "text"):
            size += len(content.text)
        elif isinstance(content, BlobResourceContents) and hasattr(content, "blob"):
            size += len(content.blob)
    return size


def _get_prompt_result_size(prompt_result) -> int | None:
    if not _has_mcp_types or not hasattr(prompt_result, "messages"):
        return None
    size = 0
    for message in prompt_result.messages:
        if hasattr(message, "content"):
            size += _get_content_size(message.content)
    return size


def _get_call_tool_result_size(call_tool_result) -> int | None:
    if not _has_mcp_types or not hasattr(call_tool_result, "content"):
        return None
    return sum([_get_content_size(content) for content in call_tool_result.content])


def _get_complete_result_size(complete_result) -> int | None:
    if _has_mcp_types and hasattr(complete_result, "completion") and hasattr(complete_result.completion, "values"):
        return sum([len(value) for value in complete_result.completion.values])
    return None


def _is_true_value(value) -> bool:
    return value.lower() in {"1", "y", "yes", "true"}
