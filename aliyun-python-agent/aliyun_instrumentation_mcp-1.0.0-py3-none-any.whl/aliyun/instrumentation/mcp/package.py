_instruments = ("mcp >= 1.3.0",)
_supports_metrics = True
