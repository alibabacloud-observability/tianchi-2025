from dataclasses import dataclass

from opentelemetry.metrics import Histogram


@dataclass
class MCPMetrics:
    operation_duration: Histogram


# request attributes
MCP_METHOD_NAME = "mcp.method.name"
MCP_PARAMETERS = "mcp.parameters"
MCP_TOOL_NAME = "mcp.tool.name"
MCP_RESOURCE_URI = "mcp.resource.uri"
MCP_PROMPT_NAME = "mcp.prompt.name"
MCP_OUTPUT_SIZE = "mcp.output.size"
MCP_CLIENT_VERSION = "mcp.client.version"

OUTPUT_VALUE = "output.value"

RPC_REQUEST_ID = "rpc.jsonrpc.request_id"
RPC_ERROR_CODE = "rpc.jsonrpc.error_code"
ERROR_TYPE = "error.type"


_method_names_with_target = {
    "prompts/get": (MCP_PROMPT_NAME, "name"),
    "resources/read": (MCP_RESOURCE_URI, "uri"),
    "tools/call": (MCP_TOOL_NAME, "name"),
    "resources/subscribe": (MCP_RESOURCE_URI, "uri"),
    "resources/unsubscribe": (MCP_RESOURCE_URI, "uri"),
}

_metric_attribute_names = set(
    [
        MCP_METHOD_NAME,
        MCP_TOOL_NAME,
    ]
)
