_instruments = ("llama-index >= 0.10.0",)
_supports_metrics = False
