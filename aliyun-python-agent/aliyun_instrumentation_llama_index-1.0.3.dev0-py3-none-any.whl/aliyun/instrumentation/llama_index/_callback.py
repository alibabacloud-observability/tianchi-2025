from aliyun.instrumentation.llama_index.internal._callback import \
    AliyunTraceCallbackHandler as _AliyunTraceCallbackHandler
from opentelemetry import trace
from opentelemetry import metrics


class AliyunCallbackHandler(_AliyunTraceCallbackHandler):

    def __init__(self, tracer: trace.Tracer, meter: metrics.Meter) -> None:
        super().__init__(tracer=tracer, meter=meter)
