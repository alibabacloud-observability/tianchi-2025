

RETRIEVER_CLASS_NAME = "retriever.classname"