import sys
import ast
from typing import Any, Dict, List

from aliyun.sdk.extension.arms.logger import getLogger

logger = getLogger(__name__)


def recursive_size(obj: Any, max_size: int = 10240) -> int:
    """递归计算对象大小，超过阈值时快速返回"""
    total_size = 0
    if isinstance(obj, dict):
        total_size += sys.getsizeof(obj)
        if total_size > max_size:
            return total_size
        for key, value in obj.items():
            total_size += recursive_size(key, max_size - total_size) + recursive_size(value, max_size - total_size)
            if total_size > max_size:
                return total_size
    elif isinstance(obj, list):
        total_size += sys.getsizeof(obj)
        if total_size > max_size:
            return total_size
        for item in obj:
            total_size += recursive_size(item, max_size - total_size)
            if total_size > max_size:
                return total_size
    else:
        total_size += sys.getsizeof(obj)
    return total_size


def _is_base64_image(item: Any) -> bool:
    """检查是否为base64编码的图片数据"""
    if not isinstance(item, dict):
        return False
    if not isinstance(item.get("image_url"), dict):
        return False
    if "data:image/" not in item.get("image_url", {}).get("url", ""):
        return False
    return True


def _filter_base64_images(obj: Any) -> Any:
    """递归过滤掉base64图片数据，保留其他信息"""
    # 使用内存大小检测 - 如果数据量不大，直接返回
    # 256x256 图片 base64 约 12K 字符长度，这里设置阈值为 10KB
    if recursive_size(obj) < 10240:  # 10KB
        return obj
    
    if isinstance(obj, list):
        filtered_list = []
        for item in obj:
            if isinstance(item, str) and "data:image/" in item:
                # 处理字符串中包含base64图片数据的情况
                # 例如: "Human: [{'type': 'text', 'text': '简述这个图片'}, {'type': 'image_url', 'image_url': {'url': 'data:image/jpeg;base64,...'}}]"
                start_idx = item.find('[')
                end_idx = item.rfind(']')

                if start_idx == -1 or end_idx == -1 or start_idx >= end_idx:
                    filtered_list.append(item)
                    continue

                try:
                    filtered_obj = item[start_idx:end_idx + 1]
                    # 解析列表
                    parsed_list = ast.literal_eval(filtered_obj)
                    if isinstance(parsed_list, list):
                        # 递归处理解析后的列表
                        filtered_parsed_list = _filter_base64_images(parsed_list)
                        # 替换原字符串中的列表
                        filtered_item = item[:start_idx] + str(filtered_parsed_list) + item[end_idx + 1:]
                        filtered_list.append(filtered_item)
                    else:
                        filtered_list.append(item)
                except Exception:
                    # 如果解析失败，保持原样
                    filtered_list.append(item)
            elif _is_base64_image(item):
                # 保留图片信息但不包含base64数据
                filtered_item = {
                    "type": item.get("type", "image_url"),
                    "image_url": {
                        "url": "BASE64_IMAGE_DATA_FILTERED"
                    }
                }
                filtered_list.append(filtered_item)
            else:
                filtered_list.append(_filter_base64_images(item))
        return filtered_list
    elif isinstance(obj, dict):
        filtered_dict = {}
        for key, value in obj.items():
            if _is_base64_image(value):
                # 如果字典值本身就是base64图片
                filtered_dict[key] = {
                    "type": value.get("type", "image_url"),
                    "image_url": {
                        "url": "BASE64_IMAGE_DATA_FILTERED"
                    }
                }
            else:
                filtered_dict[key] = _filter_base64_images(value)
        return filtered_dict
    else:
        return obj


def _parse_llm_input(prompts: List[str]) -> List[Dict[str, Any]]:
    """
    将LLM的prompts解析成标准的消息格式
    
    支持的格式：
    1. 纯文本: "一句话简单介绍三国演义" -> Human角色
    2. 带角色前缀: "Human: 问题内容" 
    3. 多角色对话: "System: xxx\nHuman: yyy"
    
    返回格式：
    [
        {
            "role": "Human",
            "parts": [
                {
                    "type": "text",
                    "content": "问题内容"
                }
            ]
        }
    ]
    """
    import re
    
    if not prompts:
        return []
    
    all_messages = []
    
    # 定义角色前缀的正则表达式模式
    # 前面要么为空要么为\n，角色名必须大写，后面紧跟冒号和空格
    role_pattern = r'^(?:System|Human|AI|Tool|Function|Assistant): '
    
    for prompt in prompts:
        if not prompt:
            continue
            
        # 使用正则表达式分割，保留分隔符
        parts = re.split(f'({role_pattern})', prompt, flags=re.MULTILINE)
        
        if len(parts) == 1:
            # 没有找到角色前缀，整个内容作为Human消息
            content = prompt.strip()
            if content:
                message = {
                    "role": "Human",
                    "parts": [
                        {
                            "type": "text",
                            "content": content
                        }
                    ]
                }
                all_messages.append(message)
        else:
            # 找到了角色前缀，角色和紧跟的内容配对
            i = 0
            while i < len(parts):
                part = parts[i]
                # 检查是否是角色匹配
                if role_match := re.fullmatch(role_pattern, part) and i + 1 < len(parts):
                    # 找到角色，查找紧跟的内容
                    role = _normalize_role(part)
                    
                    # 将下一个非空且非身份信息作为该角色的内容
                    next_part = parts[i+1]
                    if next_part.strip() and not re.fullmatch(role_pattern, next_part):
                        message = {
                            "role": role,
                            "parts": [
                                {
                                    "type": "text",
                                    "content": next_part
                                }
                            ]
                        }
                        all_messages.append(message)

                i += 1
    
    return all_messages

def _parse_llm_output(generations: List[Any]) -> List[Dict[str, Any]]:
    """
    将LLM的generations解析成标准的消息格式
    
    输入: 标准的list[Generation | ChatGeneration | GenerationChunk | ChatGenerationChunk] 
         tongyi 返回的数据格式：List[Dict]
    https://python.langchain.com/api_reference/core/outputs/langchain_core.outputs.llm_result.LLMResult.html
    输出格式:
    [
        {
            "role": "Assistant",
            "parts": [
                {
                    "type": "text",  # 或 "tool_call"
                    "content": "文本内容"  # 对于text类型
                    # 或者对于tool_call类型:
                    # "id": "call_xxx",
                    # "name": "function_name", 
                    # "arguments": {...}
                }
            ],
            "finish_reason": "stop"  # 或 "tool_calls" 等
        }
    ]
    """
    if not generations:
        return []
    
    results = []
    
    for generation in generations:
        
        if isinstance(generation, dict):
                # ChatTongyi 返回并不是标准的ChatGeneration
                if len(text := generation.get('text', '')) > 0:
                    generation_info = generation.get('generation_info', {})
                    finish_reason = 'stop'
                    if generation_info and isinstance(generation_info, dict):
                        finish_reason = generation_info.get('finish_reason', 'stop')
                    
                    message = {
                        "role": "Assistant",
                        "parts": [{
                            "type": "text",
                            "content": text
                        }],
                        "finish_reason": finish_reason
                    }

                else:
                    # 没有text，使用message信息
                    message_info = generation.get('message', {})
                    kwargs = message_info.get('kwargs', {}) if message_info else {}
                    
                    if tool_calls := kwargs.get('tool_calls'):
                        # 处理tool_calls情况
                        parts = []
                        for tool_call in tool_calls:
                            part = {
                                "type": tool_call.get('type', 'tool_call'),
                                "id": tool_call.get('id', 'UNKNOWN'),
                                "name": tool_call.get('name', 'UNKNOWN'),
                                "arguments": tool_call.get('args', {})
                            }
                            parts.append(part)
                        
                        message = {
                            "role": "Assistant",
                            "parts": parts,
                            "finish_reason": "tool_calls"
                        }

                    else:
                        # 既没有text也没有tool_calls，返回默认消息
                        message = {
                            "role": "Assistant",
                            "parts": [],
                            "finish_reason": "stop"
                        }

        elif not hasattr(generation, 'message'):
            # Generation 类型,直接使用text
            message = {
                "role": "Assistant",
                "parts": [{
                    "type": "text",
                    "content": generation.text
                }],
                "finish_reason": 'stop'
            }

        else:
            # ChatGeneration 类型,使用 AIMessage 信息
            # https://python.langchain.com/api_reference/core/messages/langchain_core.messages.ai.AIMessage.html

            gen_message = generation.message

            if len(tool_calls := gen_message.tool_calls) > 0:
                parts = []
                for tool_call in tool_calls:
                    part = {
                        "type": 'tool_call',
                        "id": tool_call.get('id', 'UNKNOWN'),
                        "name": tool_call.get('name', 'UNKNOWN'),
                        "arguments": tool_call.get('args', {})
                    }
                    parts.append(part)
                message = {
                    "role": "Assistant",
                    "parts": parts,
                    "finish_reason": "tool_calls"
                }
            else:
                message = {
                    "role": "Assistant",
                    "parts": [{
                        "type": "text",
                        "content": gen_message.content
                    }],
                    "finish_reason": "stop"
                }

        results.append(message)
    
    return results

def _normalize_role(role: str) -> str:
    """标准化角色名称"""
    role_name = ['System', 'Human', 'AI', 'Tool', 'Function', 'Assistant']
    for name in role_name:
        if name in role:
            return name
    return role
    