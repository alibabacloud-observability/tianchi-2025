_instruments = ("dashscope >= 1.0.0",)
_supports_metrics = False
