import os


ARMS_CLUSTERID = "ARMS_CLUSTER_ID"
ARMS_CLUSTERNAME = "ARMS_CLUSTER_NAME"
ARMS_NAMESPACE = "ARMS_NAMESPACE"
ARMS_WORKLOADNAME = "ARMS_WORKLOAD_NAME"
ARMS_WORKLOADKIND = "ARMS_WORKLOAD_KIND"

AGENTINFO_MAPPING = {
    ARMS_CLUSTERID: "clusterId",
    ARMS_CLUSTERNAME: "clusterName",
    ARMS_NAMESPACE: "namespace",
    ARMS_WORKLOADNAME: "workloadName",
    ARMS_WORKLOADKIND: "workloadKind"
}

class TagUtils:
    from aliyun.sdk.extension.arms.logger import getLogger
    logger = getLogger(__name__)

    DEFAULT_TAG_LAST_DIR = "tags"
    DEFAULT_TAG_FILENAME = "arms-agent-tags"
    UNDERLINE = '_'

    @classmethod
    def get_host_tags_from_file(cls) -> str:
        tags_file_path = cls.get_custom_tags_from_tag_file()
        if not tags_file_path:
            return ""

        file_path = tags_file_path
        if not os.path.exists(file_path):
            return ""

        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
                return content if content else ""
        except Exception as e:
            cls.logger.warning(f"[TagUtils]Get tags from json file error: {e}")
            return ""

    @classmethod
    def get_custom_tags_from_tag_file(cls) -> str:
        return "/home/admin/.opt/pyagent/tags/arms-agent-tags"

    @classmethod
    def normalize_tag_key(cls, tag_key: str) -> str:
        if not tag_key:
            return tag_key

        if tag_key.startswith("arms.") or tag_key.startswith("profiler.tags."):
            # 去除前缀
            tag_key = tag_key.replace("arms.", "", 1).replace("profiler.tags.", "", 1)

        # 初始化处理后的字符列表
        chars = []

        # 处理第一个字符
        first_char = tag_key[0] if tag_key else ''
        if cls.is_english_letter_or_underline(first_char):
            chars.append(first_char)
        else:
            chars.append(cls.UNDERLINE)

        # 处理后续字符
        for c in tag_key[1:]:
            if cls.is_english_letter_or_digit_or_underline(c):
                chars.append(c)
            else:
                chars.append(cls.UNDERLINE)

        # 合并连续下划线
        normalized = []
        prev_char = None
        for c in chars:
            if c == cls.UNDERLINE and prev_char == cls.UNDERLINE:
                continue
            normalized.append(c)
            prev_char = c

        return ''.join(normalized)

    @staticmethod
    def is_english_letter_or_underline(c: str) -> bool:
        return (c.isascii() and c.isalpha()) or (c == TagUtils.UNDERLINE)

    @staticmethod
    def is_english_letter_or_digit_or_underline(c: str) -> bool:
        return TagUtils.is_english_letter_or_underline(c) or c.isdigit()
