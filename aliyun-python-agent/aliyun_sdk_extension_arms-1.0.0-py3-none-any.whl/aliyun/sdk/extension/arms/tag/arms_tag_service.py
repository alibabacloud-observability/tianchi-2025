from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.config.constant import HOST_TAGS, MAX_TAG_SIZE
from aliyun.sdk.extension.arms.tag import get_global_config
from aliyun.sdk.extension.arms.tag.arms_tag_utils import TagUtils, ARMS_CLUSTERID, ARMS_CLUSTERNAME, ARMS_NAMESPACE, \
    ARMS_WORKLOADNAME, ARMS_WORKLOADKIND, AGENTINFO_MAPPING
from aliyun.opentelemetry.instrumentation import version
import os


class ArmsTagService:
    def get_custom_host_tags(self):
        custom_host_tags = ""
        try:
            host_tags_from_k8s = self.get_host_tags_from_k8s()
            host_tag_from_env = ArmsEnv.instance().hostTags
            if host_tag_from_env:
                custom_host_tags = f'{custom_host_tags}{host_tag_from_env}&'
            if host_tags_from_k8s:
                custom_host_tags = f'{custom_host_tags}{host_tags_from_k8s}&'
            custom_host_tags = f'{custom_host_tags}agentVersion:{version.__agent_version__}'
            return custom_host_tags
        except Exception:
            return custom_host_tags

    def get_host_tags_from_k8s(self):
        env = ArmsEnv.instance().agentEnv
        if env == "ACSK8S":
            k8s_tag = TagUtils.get_host_tags_from_file()
            if k8s_tag:
                return k8s_tag
        return ""

    def save_env_tag_safe(self, env_key):
        if env_key is None:
            return
        env = os.getenv(env_key, None)
        if env is not None:
            mapped_key = AGENTINFO_MAPPING.get(env_key, None)
            if mapped_key is not None:
                self.host_tags[mapped_key] = env

    def init_tags(self):
        host_tags_str = self.get_custom_host_tags()
        self.process_tags_to_map(host_tags_str, self.host_tags)
        self.save_env_tag_safe(ARMS_CLUSTERID)
        self.save_env_tag_safe(ARMS_CLUSTERNAME)
        self.save_env_tag_safe(ARMS_NAMESPACE)
        self.save_env_tag_safe(ARMS_WORKLOADNAME)
        self.save_env_tag_safe(ARMS_WORKLOADKIND)
        self.norm_host_tags_string = self.generate_tags_str_by_map(self.host_tags)
        self.process_tags_to_map(self.app_tags_string, self.app_tags)
        self.norm_app_tags_string = self.generate_tags_str_by_map(self.app_tags)

    def process_tags_to_map(self, tags, target_map):
        try:
            if tags is None or len(tags) == 0:
                return
            tag_array = tags.split("&")
            tag_length = min(len(tag_array), MAX_TAG_SIZE)
            for i in range(0, tag_length):
                tag_key_value = tag_array[i].split(":")
                if len(tag_key_value) == 2:
                    if tag_key_value[1] and len(tag_key_value[1]) > 0:
                        normalized_tag_key = TagUtils.normalize_tag_key(tag_key_value[0])
                        target_map[normalized_tag_key] = tag_key_value[1]
        except Exception:
            pass

    def generate_tags_str_by_map(self, tag_map):
        try:
            s = ""
            for k, v in tag_map.items():
                s = f'{s}{k}:{v}&'
            return s[:-1]
        except Exception:
            pass

    def __init__(self):
        self.host_tags = {}
        self.app_tags = {}
        self.norm_host_tags_string = ""
        self.norm_app_tags_string = ""
        self.app_tags_string = ""
        self.init_tags()


global_arms_tag_service = ArmsTagService()
