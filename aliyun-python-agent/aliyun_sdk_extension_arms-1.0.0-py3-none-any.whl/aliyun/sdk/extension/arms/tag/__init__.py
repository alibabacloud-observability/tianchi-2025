from aliyun.sdk.extension.arms.config.config import get_config_properties

config = get_config_properties()

def get_global_config():
    return config