import os
import time

from aliyun.sdk.extension.arms.tag.version import __version__
from aliyun.opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.metrics import get_meter, MeterProvider
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.proto.agent_info_provider import AgentInfoProvider
from aliyun.sdk.extension.arms.semconv.metrics import ArmsCommonServiceMetrics
from aliyun.sdk.extension.arms.utils import  get_local_ip

from threading import Thread

from aliyun.sdk.extension.arms.logger import getLogger

_log = getLogger(__name__)
class TagGenerator(Thread):


    def __init__(self):
        self._inited = False

    def is_inited(self):
        return self._inited

    def set_meter_provider(self, meter_provider):
        self._meter_provider = meter_provider
        self._meter = get_meter(
            __name__,
            __version__,
            meter_provider,
            schema_url="https://opentelemetry.io/schemas/1.11.0",
        )
        self._attrs = {
            "app": ArmsEnv.instance().appName,
            "host": get_local_ip(),
            "hostname": ArmsEnv.instance().hostname,
            "clusterId": ArmsEnv.instance().clusterId,
            "clusterName": ArmsEnv.instance().clusterName,
            "namespace": ArmsEnv.instance().namespace,
            "resourceid": ArmsEnv.instance().appId,
            "language": "python",
            "rpcType": "0",
            "resourcetype": "APPLICATION",
        }
        self._inited = True

    # todo periodically report metric
    def generate_tag(self):
        ArmsEnv.instance().getAppId()
        ArmsCommonServiceMetrics(self._meter).arms_tag_host_entity.set(
            1, self._attrs
        )

    # todo run in co-routine
    def run(self):
        while True:
            self.generate_tag()
            time.sleep(3)

    @classmethod
    def instance(cls):
        if not hasattr(TagGenerator, "_instance"):
            TagGenerator._instance = TagGenerator()
        return TagGenerator._instance