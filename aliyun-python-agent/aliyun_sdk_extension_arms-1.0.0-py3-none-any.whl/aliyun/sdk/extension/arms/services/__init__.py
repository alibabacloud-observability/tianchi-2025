import threading
import time

from aliyun.sdk.extension.arms.exporters import metadata_exporter
class agent_info_manager:
    def __init__(self, heartbeat_interval, queue):
        self.heartbeat_interval = heartbeat_interval
        self.queue = queue
        self.running = True

        self.timer = threading.Timer(self.heartbeat_interval, self.send_heartbeat)
        self.timer.start()

    def send_heartbeat(self):
        if not self.running:
            return

        heartbeat_metadata = {
            'timestamp': time.time(),
            'status': 'alive'
        }



        self.queue.put(heartbeat_metadata)

        self.timer = threading.Timer(self.heartbeat_interval, self.send_heartbeat)
        self.timer.start()

    def stop(self):
        self.running = False
        self.timer.cancel()