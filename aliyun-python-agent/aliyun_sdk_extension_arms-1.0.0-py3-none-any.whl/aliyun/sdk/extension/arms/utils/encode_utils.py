#  使用 ECMA-182标准 计算 crc64的值
import crcmod

do_crc64 = crcmod.mkCrcFun(0x142F0E1EBA9EA3693, initCrc=0, xorOut=0xffffffffffffffff, rev=True)
def crc_encode1(data: str):
    c64 = do_crc64(data.encode('utf-8'))

    return str(c64)

def crc_encode(data: str):
    if not isinstance(data, bytes):
        data = data.encode('utf-8')
    c64 = do_crc64(data)
    return str(c64)
