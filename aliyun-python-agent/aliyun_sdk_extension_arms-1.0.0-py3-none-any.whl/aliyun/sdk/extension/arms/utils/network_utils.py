from urllib.error import HTTPError
from urllib.request import urlopen

from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)


def is_url_reachable(url_str):
    if not url_str:
        _logger.warning("URL is empty.")
        return False
    if not url_str.startswith(("http://", "https://")):
        url_str = f"http://{url_str}"
    try:
        return _is_url_reachable(url_str)
    except Exception as e:
        _logger.warning(f"Try to connect address {url_str} fail!, reason {str(e)}")
        return False


def _is_url_reachable(url):
    _logger.info(f"Try to connect to url {url}")
    try:
        req = urlopen(url, timeout=1)
        if req.getcode() < 500:
            _logger.info(f"Connect to address {url} success!")
            return True
    except HTTPError as e:
        if e.code < 500:
            _logger.info(f"Connect to address {url} success!")
            return True
    except Exception as e:
        _logger.warning(f"Unexpected error connecting to {url}: {str(e)}")
        return False
    return False
