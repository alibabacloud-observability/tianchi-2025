import logging

from aliyun.sdk.extension.arms.metadata import MetadataExporter
from aliyun.sdk.extension.arms.metadata.base_exporter import BaseExporter
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from typing import Any
import requests
from aliyun.sdk.extension.arms.metadata.util.auth import sign

logger = logging.getLogger(__name__)


class Credentials(object):
    def __init__(self, access_key_id, access_key_secret, security_token=None):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.security_token = security_token

    def get_access_key_id(self):
        return self.access_key_id

    def get_access_key_secret(self):
        return self.access_key_secret

    def get_security_token(self):
        return self.security_token


class SLSExporter(BaseExporter):

    def __init__(self, credential: Credentials = None):
        self.credential = credential
        self.endpoint = ArmsEnv.instance().getSlsEndpoint()
        self.headers = {
            'Content-Type': 'application/x-protobuf',
            'x-log-apiversion': '0.6.0',
            'User-Agent': 'sls-python-sdk-v-0.6.0',
            'Host': ArmsEnv.instance().slsHost,
        }

    def set_credential(self, credential: Credentials):
        if credential is not None:
            self.credential = credential

    def export(self, data: str):
        logger.debug(f"------------endpoints: {self.endpoint}  data:{data} header: {self.headers}")
        if self.credential is None:
            return
        headers = self.headers.copy()
        headers['x-log-bodyrawsize'] = str(len(data))
        headers["x-acs-security-token"] = self.credential.get_security_token()
        headers = sign(method="POST",
                       uri=ArmsEnv.instance().slsUri,
                       access_key_id=self.credential.get_access_key_id(),
                       access_key_secret=self.credential.get_access_key_secret(),
                       params={},
                       headers=headers,
                       body=data
                       )
        response = requests.post(self.endpoint, data=data, headers=headers)
        logger.debug(f"response info:{response.text}")