# # from .util.ring_buffer import RingBuffer
# from aliyun.sdk.extension.arms.metadata.util.ring_buffer import RingBuffer
# from aliyun.sdk.extension.arms.metadata.module.send_data import SendData
# from concurrent.futures import ThreadPoolExecutor
# from aliyun.sdk.extension.arms.proto.agent_info_pb2 import AgentInfo
# from aliyun.sdk.extension.arms.proto.arms_metadata_pb2 import ArmsSqlMetaData, ArmsSqlMetaDataBatch, \
#     ArmsStringMetaDataBatch, ArmsStringMetaData
# from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
# from aliyun.sdk.extension.arms.metadata import util as MetadataUtils
# import time
# import logging
# import requests
# from aliyun.sdk.extension.arms.common.obs import SingletonMeta
# import threading
#
# logger = logging.getLogger(__name__)
#
#
# # logging.basicConfig(level=logging.INFO)
# # from .util.ring_buffer import RingBuffer
# from aliyun.sdk.extension.arms.metadata.util.ring_buffer import RingBuffer
# from aliyun.sdk.extension.arms.metadata.module.send_data import SendData
# from concurrent.futures import ThreadPoolExecutor
# from aliyun.sdk.extension.arms.proto.agent_info_pb2 import AgentInfo
# from aliyun.sdk.extension.arms.proto.arms_metadata_pb2 import ArmsSqlMetaData, ArmsSqlMetaDataBatch, \
#     ArmsStringMetaDataBatch, ArmsStringMetaData
# from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
# from aliyun.sdk.extension.arms.metadata import util as MetadataUtils
# import time
# import logging
# import requests
# from aliyun.sdk.extension.arms.common.obs import SingletonMeta
# import threading
#
# logger = logging.getLogger(__name__)
#
#
# # logging.basicConfig(level=logging.INFO)
#
#
# # 生产者函数，将数据放入 RingBuffer
# def producer(i):
#     count = i * 100
#     while True:
#         agent_info = AgentInfo()
#         agent_info.hostname = 'test.host'
#         agent_info.ip = '127.0.0.1'
#         agent_info.agentVersion = '0.0.1'
#         agent_info.agentId = 'agent' + str(count)
#         agent_info_ring_buffer.put_with_lock(agent_info.SerializeToString())
#         logger.debug(f"Produced{str(i)}: {agent_info.SerializeToString()}")
#         arms_sql_meta_data = ArmsSqlMetaData()
#         arms_sql_meta_data.sqlId = 'sql' + str(count)
#         arms_sql_meta_data.sql = 'select * from log limit 1'
#         sql_meta_ring_buffer.put(arms_sql_meta_data.SerializeToString())
#         logger.debug(f"Produced{str(i)}: {arms_sql_meta_data.SerializeToString()}")
#         arms_string_meta_data = ArmsStringMetaData()
#         arms_string_meta_data.stringId = 'str' + str(count)
#         string_meta_ring_buffer.put(arms_string_meta_data.SerializeToString())
#         logger.debug(f"Produced{str(i)}: {arms_string_meta_data.SerializeToString()}")
#         count += 1
#         time.sleep(2)
#
#
# class MetadataFetcher:
#
#     def __init__(self, headers):
#         self.is_running = False
#         # 创建 RingBuffer 实例
#         RING_BUFFER_SIZE = ArmsEnv.instance().ringBufferSize
#         self.agent_info_ring_buffer = RingBuffer(RING_BUFFER_SIZE)
#         self.sql_meta_ring_buffer = RingBuffer(RING_BUFFER_SIZE)
#         self.string_meta_ring_buffer = RingBuffer(RING_BUFFER_SIZE)
#
#         self.licenseKey = ArmsEnv.instance().licenseKey
#         self.agentId = ArmsEnv.instance().agentId
#         self.appId = ArmsEnv.instance().appId
#         self.appName = ArmsEnv.instance().appName
#         self.headers = headers
#
#         self.endpoint = f"http://{ArmsEnv.instance().getMetaEndpoint()}"
#         self.SEND_MAX_SIZE = ArmsEnv.instance().sendMaxSize
#         self.SEND_TIME_INTERVAL = ArmsEnv.instance().sendTimeInterval
#         self.send_sql_meta_data = SendData(time.time())
#         self.send_string_meta_data = SendData(time.time())
#         logger.warning(f"init over ....")
#
#     def start(self):
#         if not self.is_running:
#             logger.warning(f"Arms.MetadataFetcher.start() ....")
#             self.is_running = True
#         else:
#             logger.debug("metadata fetcher aready runing")
#
#     def metadata_fetcher(self) -> None:
#         executor = ThreadPoolExecutor(max_workers=30)
#         for i in range(2):
#             executor.submit(self.agent_consumer, f"AgentConsumer{i}")
#             logger.warning(f" executor.submit agent_consumer  ....")
#         for i in range(10):
#             executor.submit(self.sql_meta_consumer, f"SqlMetaConsumer{i}")
#             logger.warning(f" executor.submit sql_meta_consumer  ....")
#
#         for i in range(10):
#             executor.submit(self.string_meta_consumer, f"StringMetaConsumer{i}")
#             logger.warning(f" executor.submit string_meta_consumer  ....")
#         logger.warning(f" executor.submit metadata_fetcher over  ....")
#         return None
#
#     def add_agent_info_item(self, agent_info: AgentInfo) -> None:
#         self.agent_info_ring_buffer.put(agent_info.SerializeToString())
#
#     def add_sql_meta_data_item(self, sql_meta_data: ArmsSqlMetaData) -> None:
#         self.sql_meta_ring_buffer.put(sql_meta_data.SerializeToString())
#
#     def add_string_meta_data_item(self, string_meta_data: ArmsStringMetaData) -> None:
#         self.string_meta_ring_buffer.put(string_meta_data.SerializeToString())
#
#     # 消费者函数，从 RingBuffer 中获取数据
#     def agent_consumer(self, name="agent_consumer"):
#         while True:
#             agent_item = self.agent_info_ring_buffer.get_with_lock()
#             agent_info = AgentInfo()
#             agent_info.ParseFromString(agent_item)
#             send_agent_info_to_gw(name, 1, agent_info)
#
#     def sql_meta_consumer(self, name="sql_meta_consumer"):
#         sql_meta_batch = ArmsSqlMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#         size = 0
#         while True:
#             sql_meta_item = self.sql_meta_ring_buffer.get()
#             if sql_meta_item:
#                 sql_meta_data = ArmsSqlMetaData()
#                 sql_meta_data.ParseFromString(sql_meta_item)
#                 logger.debug(f"Consumer {name} consumed sql_meta_data: {sql_meta_data}, size: {size}")
#                 if size < self.SEND_MAX_SIZE:
#                     sql_meta_batch.armsSqlMetaData.append(sql_meta_data)
#                     size = size + 1
#                 if size >= self.SEND_MAX_SIZE:
#                     send_sql_meta_to_gw(name, size, sql_meta_batch)
#                     size = 0
#                     sql_meta_batch = ArmsSqlMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#             now = time.time()
#             send_time = self.send_sql_meta_data.get_send_time()
#             if now - send_time >= self.SEND_TIME_INTERVAL and sql_meta_batch and sql_meta_batch.armsSqlMetaData:
#                 self.send_sql_meta_to_gw(name, size, sql_meta_batch)
#                 size = 0
#                 sql_meta_batch = ArmsSqlMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#
#     def string_meta_consumer(self, name="string_meta_consumer"):
#         string_meta_batch = ArmsStringMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#         size = 0
#         while True:
#             string_meta_item = self.string_meta_ring_buffer.get()
#             if string_meta_item:
#                 string_meta_data = ArmsStringMetaData()
#                 string_meta_data.ParseFromString(string_meta_item)
#                 logger.debug(f"Consumer {name} consumed string_meta_data: {string_meta_data}, size: {size}")
#                 if size < self.SEND_MAX_SIZE:
#                     string_meta_batch.armsStringMetaData.append(string_meta_data)
#                     size = size + 1
#                 if size >= self.SEND_MAX_SIZE:
#                     self.send_string_meta_to_gw(name, size, string_meta_batch)
#                     size = 0
#                     string_meta_batch = ArmsStringMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#             now = time.time()
#             send_time = self.send_string_meta_data.get_send_time()
#             if now - send_time >= self.SEND_TIME_INTERVAL and string_meta_batch and string_meta_batch.armsStringMetaData:
#                 self.send_string_meta_to_gw(name, size, string_meta_batch)
#                 size = 0
#                 string_meta_batch = ArmsStringMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#
#     def export(self, data: str):
#         print(f"------------endpoints: {self.endpoint}  data:{data} header: {self.headers}")
#         response = requests.post(self.endpoint, data=data, headers=self.headers)
#         logger.warning(f"response info:{response.text}")
#
#     def send_agent_info_to_gw(self, name, size, agent_info):
#         logger.warning(f"endpoint :{self.endpoint}")
#         headers = {'X-ARMS-ContentType': 'AgentInfo'}
#         send_time = time.time()
#         logger.warning(
#             f"agent_info:{agent_info}  pb: {agent_info.SerializeToString()}, agent_send_time:{send_time}, name:{name}, size:{size}, url: {self.endpoint}")
#         response = requests.post(self.endpoint, data=agent_info.SerializeToString(), headers=headers)
#         # logger.warning(f"response.status_code:{response.status_code}")
#         logger.warning(f"response info:{response.text}")
#
#     def send_sql_meta_to_gw(self, name, size, sql_meta_batch):
#         headers = {'X-ARMS-ContentType': 'SqlMetaDataBatch'}
#         send_time = time.time()
#         self.send_sql_meta_data.set_send_time(send_time)
#         logger.debug(
#             f"sql_meta_batch:{sql_meta_batch}, sql_send_time:{send_time}, name:{name}, size:{size}, url: {self.endpoint}")
#         response = requests.post(self.endpoint, data=sql_meta_batch.SerializeToString(), headers=headers)
#
#     def send_string_meta_to_gw(self, name, size, string_meta_batch):
#         headers = {'X-ARMS-ContentType': 'StringMetaDataBatch'}
#         send_time = time.time()
#         self.send_string_meta_data.set_send_time(send_time)
#         logger.debug(
#             f"string_meta_batch:{string_meta_batch}, string_send_time:{send_time}, name:{name}, size:{size}, url: {self.endpoint}")
#         response = requests.post(self.endpoint, data=string_meta_batch.SerializeToString(), headers=headers)
#
#
# # def atest() -> None:
# #     # 创建一个线程池
# #     with ThreadPoolExecutor(max_workers=30) as executor:
# #         # 启动生产者任务
# #         for i in range(3):
# #             executor.submit(producer, i)
# #         for i in range(2):
# #             executor.submit(agent_consumer, f"AgentConsumer{i}")
# #         for i in range(2):
# #             executor.submit(sql_meta_consumer, f"SqlMetaConsumer{i}")
# #         for i in range(2):
# #             executor.submit(string_meta_consumer, f"StringMetaConsumer{i}")
#
#
# def mock_agent_info():
#     agent_info = AgentInfo()
#     agent_info.hostname = 'test.host'
#     agent_info.ip = '127.0.0.1'
#     agent_info.agentVersion = '0.0.1'
#     agent_info.agentId = agentId
#     agent_info.vmVersion = "1.0.0"
#     agent_info.applicationName = appName
#     agent_info.appName = appName
#     agent_info.serviceType = 0
#     agent_info.licenseKey = licenseKey
#     agent_info.language = "python"
#     timestemp = int(round(time.time() * 1000))
#     agent_info.startTimestamp = timestemp
#     agent_info.timestamp = timestemp
#     agent_info.uuId = f"{ArmsEnv.instance().uuid}"
#     agent_info.agentEnv = ArmsEnv.instance().agentEnv
#     agent_info.ports = "80"
#     agent_info.memTotalSize = "4096"
#     agent_info.pid = 1
#     agent_info.processorNum = "1"
#     agent_info.agentTags["agent_type"] = "python_agent"
#
#     MetadataFetcher().send_agent_info_to_gw("test", 1, agent_info)
#
# # if __name__ == '__main__':
# #     # test()
# #     mock_agent_info()
#
#
# # 生产者函数，将数据放入 RingBuffer
# def producer(i):
#     count = i * 100
#     while True:
#         agent_info = AgentInfo()
#         agent_info.hostname = 'test.host'
#         agent_info.ip = '127.0.0.1'
#         agent_info.agentVersion = '0.0.1'
#         agent_info.agentId = 'agent' + str(count)
#         agent_info_ring_buffer.put_with_lock(agent_info.SerializeToString())
#         logger.debug(f"Produced{str(i)}: {agent_info.SerializeToString()}")
#         arms_sql_meta_data = ArmsSqlMetaData()
#         arms_sql_meta_data.sqlId = 'sql' + str(count)
#         arms_sql_meta_data.sql = 'select * from log limit 1'
#         sql_meta_ring_buffer.put(arms_sql_meta_data.SerializeToString())
#         logger.debug(f"Produced{str(i)}: {arms_sql_meta_data.SerializeToString()}")
#         arms_string_meta_data = ArmsStringMetaData()
#         arms_string_meta_data.stringId = 'str' + str(count)
#         string_meta_ring_buffer.put(arms_string_meta_data.SerializeToString())
#         logger.debug(f"Produced{str(i)}: {arms_string_meta_data.SerializeToString()}")
#         count += 1
#         time.sleep(2)
#
#
# class MetadataFetcher:
#
#     def __init__(self, headers):
#         self.is_running = False
#         # 创建 RingBuffer 实例
#         RING_BUFFER_SIZE = ArmsEnv.instance().ringBufferSize
#         self.agent_info_ring_buffer = RingBuffer(RING_BUFFER_SIZE)
#         self.sql_meta_ring_buffer = RingBuffer(RING_BUFFER_SIZE)
#         self.string_meta_ring_buffer = RingBuffer(RING_BUFFER_SIZE)
#
#         self.licenseKey = ArmsEnv.instance().licenseKey
#         self.agentId = ArmsEnv.instance().agentId
#         self.appId = ArmsEnv.instance().appId
#         self.appName = ArmsEnv.instance().appName
#         self.headers = headers
#
#         self.endpoint = f"http://{ArmsEnv.instance().getMetaEndpoint()}"
#         self.SEND_MAX_SIZE = ArmsEnv.instance().sendMaxSize
#         self.SEND_TIME_INTERVAL = ArmsEnv.instance().sendTimeInterval
#         self.send_sql_meta_data = SendData(time.time())
#         self.send_string_meta_data = SendData(time.time())
#         logger.warning(f"init over ....")
#
#     def start(self):
#         if not self.is_running:
#             logger.warning(f"Arms.MetadataFetcher.start() ....")
#             self.is_running = True
#         else:
#             logger.debug("metadata fetcher aready runing")
#
#     def metadata_fetcher(self) -> None:
#         executor = ThreadPoolExecutor(max_workers=30)
#         for i in range(2):
#             executor.submit(self.agent_consumer, f"AgentConsumer{i}")
#             logger.warning(f" executor.submit agent_consumer  ....")
#         for i in range(10):
#             executor.submit(self.sql_meta_consumer, f"SqlMetaConsumer{i}")
#             logger.warning(f" executor.submit sql_meta_consumer  ....")
#
#         for i in range(10):
#             executor.submit(self.string_meta_consumer, f"StringMetaConsumer{i}")
#             logger.warning(f" executor.submit string_meta_consumer  ....")
#         logger.warning(f" executor.submit metadata_fetcher over  ....")
#         return None
#
#     def add_agent_info_item(self, agent_info: AgentInfo) -> None:
#         self.agent_info_ring_buffer.put(agent_info.SerializeToString())
#
#     def add_sql_meta_data_item(self, sql_meta_data: ArmsSqlMetaData) -> None:
#         self.sql_meta_ring_buffer.put(sql_meta_data.SerializeToString())
#
#     def add_string_meta_data_item(self, string_meta_data: ArmsStringMetaData) -> None:
#         self.string_meta_ring_buffer.put(string_meta_data.SerializeToString())
#
#     # 消费者函数，从 RingBuffer 中获取数据
#     def agent_consumer(self, name="agent_consumer"):
#         while True:
#             agent_item = self.agent_info_ring_buffer.get_with_lock()
#             agent_info = AgentInfo()
#             agent_info.ParseFromString(agent_item)
#             send_agent_info_to_gw(name, 1, agent_info)
#
#     def sql_meta_consumer(self, name="sql_meta_consumer"):
#         sql_meta_batch = ArmsSqlMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#         size = 0
#         while True:
#             sql_meta_item = self.sql_meta_ring_buffer.get()
#             if sql_meta_item:
#                 sql_meta_data = ArmsSqlMetaData()
#                 sql_meta_data.ParseFromString(sql_meta_item)
#                 logger.debug(f"Consumer {name} consumed sql_meta_data: {sql_meta_data}, size: {size}")
#                 if size < self.SEND_MAX_SIZE:
#                     sql_meta_batch.armsSqlMetaData.append(sql_meta_data)
#                     size = size + 1
#                 if size >= self.SEND_MAX_SIZE:
#                     send_sql_meta_to_gw(name, size, sql_meta_batch)
#                     size = 0
#                     sql_meta_batch = ArmsSqlMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#             now = time.time()
#             send_time = self.send_sql_meta_data.get_send_time()
#             if now - send_time >= self.SEND_TIME_INTERVAL and sql_meta_batch and sql_meta_batch.armsSqlMetaData:
#                 self.send_sql_meta_to_gw(name, size, sql_meta_batch)
#                 size = 0
#                 sql_meta_batch = ArmsSqlMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#
#     def string_meta_consumer(self, name="string_meta_consumer"):
#         string_meta_batch = ArmsStringMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#         size = 0
#         while True:
#             string_meta_item = self.string_meta_ring_buffer.get()
#             if string_meta_item:
#                 string_meta_data = ArmsStringMetaData()
#                 string_meta_data.ParseFromString(string_meta_item)
#                 logger.debug(f"Consumer {name} consumed string_meta_data: {string_meta_data}, size: {size}")
#                 if size < self.SEND_MAX_SIZE:
#                     string_meta_batch.armsStringMetaData.append(string_meta_data)
#                     size = size + 1
#                 if size >= self.SEND_MAX_SIZE:
#                     self.send_string_meta_to_gw(name, size, string_meta_batch)
#                     size = 0
#                     string_meta_batch = ArmsStringMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#             now = time.time()
#             send_time = self.send_string_meta_data.get_send_time()
#             if now - send_time >= self.SEND_TIME_INTERVAL and string_meta_batch and string_meta_batch.armsStringMetaData:
#                 self.send_string_meta_to_gw(name, size, string_meta_batch)
#                 size = 0
#                 string_meta_batch = ArmsStringMetaDataBatch(licenseKey=self.licenseKey, agentId=self.agentId)
#
#     def export(self, data: str):
#         print(f"------------endpoints: {self.endpoint}  data:{data} header: {self.headers}")
#         response = requests.post(self.endpoint, data=data, headers=self.headers)
#         logger.warning(f"response info:{response.text}")
#
#     def send_agent_info_to_gw(self, name, size, agent_info):
#         logger.warning(f"endpoint :{self.endpoint}")
#         headers = {'X-ARMS-ContentType': 'AgentInfo'}
#         send_time = time.time()
#         logger.warning(
#             f"agent_info:{agent_info}  pb: {agent_info.SerializeToString()}, agent_send_time:{send_time}, name:{name}, size:{size}, url: {self.endpoint}")
#         response = requests.post(self.endpoint, data=agent_info.SerializeToString(), headers=headers)
#         # logger.warning(f"response.status_code:{response.status_code}")
#         logger.warning(f"response info:{response.text}")
#
#     def send_sql_meta_to_gw(self, name, size, sql_meta_batch):
#         headers = {'X-ARMS-ContentType': 'SqlMetaDataBatch'}
#         send_time = time.time()
#         self.send_sql_meta_data.set_send_time(send_time)
#         logger.debug(
#             f"sql_meta_batch:{sql_meta_batch}, sql_send_time:{send_time}, name:{name}, size:{size}, url: {self.endpoint}")
#         response = requests.post(self.endpoint, data=sql_meta_batch.SerializeToString(), headers=headers)
#
#     def send_string_meta_to_gw(self, name, size, string_meta_batch):
#         headers = {'X-ARMS-ContentType': 'StringMetaDataBatch'}
#         send_time = time.time()
#         self.send_string_meta_data.set_send_time(send_time)
#         logger.debug(
#             f"string_meta_batch:{string_meta_batch}, string_send_time:{send_time}, name:{name}, size:{size}, url: {self.endpoint}")
#         response = requests.post(self.endpoint, data=string_meta_batch.SerializeToString(), headers=headers)
#
#
# # def atest() -> None:
# #     # 创建一个线程池
# #     with ThreadPoolExecutor(max_workers=30) as executor:
# #         # 启动生产者任务
# #         for i in range(3):
# #             executor.submit(producer, i)
# #         for i in range(2):
# #             executor.submit(agent_consumer, f"AgentConsumer{i}")
# #         for i in range(2):
# #             executor.submit(sql_meta_consumer, f"SqlMetaConsumer{i}")
# #         for i in range(2):
# #             executor.submit(string_meta_consumer, f"StringMetaConsumer{i}")
#
#
# def mock_agent_info():
#     agent_info = AgentInfo()
#     agent_info.hostname = 'test.host'
#     agent_info.ip = '127.0.0.1'
#     agent_info.agentVersion = '0.0.1'
#     agent_info.agentId = agentId
#     agent_info.vmVersion = "1.0.0"
#     agent_info.applicationName = appName
#     agent_info.appName = appName
#     agent_info.serviceType = 0
#     agent_info.licenseKey = licenseKey
#     agent_info.language = "python"
#     timestemp = int(round(time.time() * 1000))
#     agent_info.startTimestamp = timestemp
#     agent_info.timestamp = timestemp
#     agent_info.uuId = f"{ArmsEnv.instance().uuid}"
#     agent_info.agentEnv = ArmsEnv.instance().agentEnv
#     agent_info.ports = "80"
#     agent_info.memTotalSize = "4096"
#     agent_info.pid = 1
#     agent_info.processorNum = "1"
#     agent_info.agentTags["agent_type"] = "python_agent"
#
#     MetadataFetcher().send_agent_info_to_gw("test", 1, agent_info)
#
# # if __name__ == '__main__':
# #     # test()
# #     mock_agent_info()
