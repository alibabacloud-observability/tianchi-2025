from abc import abstractmethod


class BaseExporter:


    @abstractmethod
    def export(self, data: str) -> None:
        """
        Export the given data.
        """
        pass