from aliyun.sdk.extension.arms.metadata.base_exporter import BaseExporter
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
import threading
import collections
from aliyun.sdk.extension.arms.metadata.module.flush_metadata import _FlushMetadata
from aliyun.sdk.extension.arms.metadata.module.metadata import Metadata
from aliyun.sdk.extension.arms.metadata.module.metadata_batch import MetadataBatch
import typing
# from aliyun.sdk.extension.arms.logger import getLogger
# from logging import getLogger
from time import time_ns

# logger = getLogger(__name__)


class MetadataBatcher:

    def __init__(self, exporter: BaseExporter, metadata_batch: MetadataBatch):
        from aliyun.sdk.extension.arms.logger import getLogger
        self._logger =  getLogger(__name__)
        self._exporter = exporter
        self.schedule_delay = ArmsEnv.instance().maxExporterTimeoutSec
        self.max_export_batch_size = ArmsEnv.instance().maxExporterBatchSize
        self.condition = threading.Condition(threading.Lock())
        self.max_queue_size = ArmsEnv.instance().maxQueueSize
        self._flush_metadata = None  # type: typing.Optional[_FlushMetadata]
        self.metadata_batch = metadata_batch  # type: typing.Optional[MetadataBatch]
        self.queue = collections.deque(
            [], self.max_queue_size
        )  # type: typing.Deque[Metadata]
        self.worker_thread = threading.Thread(
            name="MetadataBatcher", target=self.worker, daemon=True
        )
        self.is_first = True
        self.done = False
        self.worker_thread.start()

    def add_metadata(self, metadata: Metadata) -> None:
        if self.done:
            self._logger.warning("Already shutdown, dropping span.")
            return

        self.queue.appendleft(metadata)
        if self.is_first:
            with self.condition:
                self.condition.notify()
            self.is_first = False

        if len(self.queue) >= self.max_export_batch_size:
            with self.condition:
                self.condition.notify()

    def worker(self):
        timeout = self.schedule_delay
        flush_metadata = None  # type: typing.Optional[_FlushMetadata]
        while not self.done:
            with self.condition:
                if self.done:
                    # done flag may have changed, avoid waiting
                    break
                flush_metadata = self._get_and_unset_flush_metadata()
                if (
                        len(self.queue) < self.max_export_batch_size
                        and flush_metadata is None
                ):
                    self.condition.wait(timeout)
                    flush_metadata = self._get_and_unset_flush_metadata()
                    if not self.queue:
                        # spurious notification, let's wait again, reset timeout
                        timeout = self.schedule_delay
                        self._notify_flush_request_finished(flush_metadata)
                        flush_metadata = None
                        continue
                    if self.done:
                        # missing metadata will be sent when calling flush
                        break

            # subtract the duration of this export call to the next timeout
            start = time_ns()
            self._export(flush_metadata)
            end = time_ns()
            duration = (end - start) / 1e9
            timeout = self.schedule_delay - duration

            self._notify_flush_request_finished(flush_metadata)
            flush_metadata = None

        # there might have been a new flush metadata while export was running
        # and before the done flag switched to true
        with self.condition:
            shutdown_flush_metadata = self._get_and_unset_flush_metadata()

        # be sure that all metadatas are sent
        self._drain_queue()
        self._notify_flush_request_finished(flush_metadata)
        self._notify_flush_request_finished(shutdown_flush_metadata)

    def _drain_queue(self):
        """Export all elements until queue is empty.

        Can only be called from the worker thread context because it invokes
        `export` that is not thread safe.
        """
        while self.queue:
            self._export_batch()

    def _export_batch(self) -> int:
        """Exports at most max_export_batch_size metadata and returns the number of
        exported metadata.
        """
        idx = 0
        # currently only a single thread acts as consumer, so queue.pop() will
        # not raise an exception
        while idx < self.max_export_batch_size and self.queue:
            metadata = self.queue.pop()
            self.metadata_batch.add_metadata(metadata)
            idx += 1
        try:
            # Ignore type b/c the Optional[None]+slicing is too "clever"
            # for mypy
            self._exporter.export(self.metadata_batch.serialize_to_string())  # type: ignore
            self.metadata_batch.clear()
        except Exception:  # pylint: disable=broad-exception-caught
            self._logger.exception("Exception while exporting metadata batch.")

        return idx

    def _get_and_unset_flush_metadata(
            self,
    ) -> typing.Optional[_FlushMetadata]:
        """Returns the current flush metadata and makes it invisible to the
        worker thread for subsequent calls.
        """
        flush_metadata = self._flush_metadata
        self._flush_metadata = None
        if flush_metadata is not None:
            flush_metadata.num_metadatas = len(self.queue)
        return flush_metadata

    @staticmethod
    def _notify_flush_request_finished(
            flush_metadata: typing.Optional[_FlushMetadata],
    ):
        """Notifies the flush initiator(s) waiting on the given request/event
        that the flush operation was finished.
        """
        if flush_metadata is not None:
            flush_metadata.event.set()

    def _export(self, flush_metadata: typing.Optional[_FlushMetadata]):

        if not flush_metadata:
            self._export_batch()
            return

        num_batch = flush_metadata.num_metadatas
        while self.queue:
            num_exported = self._export_batch()
            num_batch -= num_exported

            if num_batch <= 0:
                break
