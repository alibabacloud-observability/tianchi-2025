import os
from aliyun.sdk.extension.arms.metadata.metadata_batcher import MetadataBatcher
from aliyun.sdk.extension.arms.metadata.metadata_exporter import MetadataExporter
from aliyun.sdk.extension.arms.metadata.sls_exporter import SLSExporter, Credentials
from aliyun.sdk.extension.arms.metadata.module.metadata import Metadata, StringMetadata, AgentInfoMetadata, \
    CredentialMetadata
from aliyun.sdk.extension.arms.metadata.module.metadata_batch import AgentInfoMetadataBatch, SqlMetadataBatch, \
    StringMetadataBatch, CredentialMetadataBatch, SLSLogBatch
import json

__all__ = ["add_agent_info", "add_string_metadata", "add_sql_metadata", "Metadata", "StringMetadata",
           "AgentInfoMetadata", "util", "add_credential_metadata", "add_sls_log"]

_agent_info_batcher = None
_sts_credential_batcher = None
_sql_metadata_batcher = None
_string_metadata_batcher = None
_sls_log_batcher = None
sls_exporter = SLSExporter()


def _sts_credential_handler(response):
    try:
        resp = json.loads(response.text)
        if "data" in resp:
            data = json.loads(resp["data"])
            ak = None
            sk = None
            token = None
            if "ak" in data:
                ak = data["ak"]
            if "sk" in data:
                sk = data["sk"]
            if "token" in data:
                token = data["token"]
            sls_exporter.set_credential(
                credential=Credentials(access_key_id=ak, access_key_secret=sk, security_token=token))
    except BaseException as exc:
        print(exc)


def init_metadata():
    global _agent_info_batcher, _agent_info_batcher, _string_metadata_batcher, _sts_credential_batcher, _sls_log_batcher

    _agent_info_batcher = MetadataBatcher(
        MetadataExporter(headers={'X-ARMS-ContentType': 'AgentInfo'}),
        metadata_batch=AgentInfoMetadataBatch())
    _sts_credential_batcher = MetadataBatcher(
        MetadataExporter(headers={'X-ARMS-ContentType': 'GetSTSCredential'}, handler=_sts_credential_handler),
        metadata_batch=CredentialMetadataBatch())
    _sql_metadata_batcher = MetadataBatcher(
        MetadataExporter(headers={'X-ARMS-ContentType': 'SqlMetaDataBatch'}),
        metadata_batch=SqlMetadataBatch())
    _string_metadata_batcher = MetadataBatcher(MetadataExporter(headers={'X-ARMS-ContentType': 'StringMetaDataBatch'}),
                                               metadata_batch=StringMetadataBatch())

    _sls_log_batcher = MetadataBatcher(sls_exporter,
                                       metadata_batch=SLSLogBatch())


def add_sls_log(metadata: Metadata):
    if _sls_log_batcher is None:
        return
    _sls_log_batcher.add_metadata(metadata)


def add_string_metadata(metadata: Metadata):
    if _string_metadata_batcher is None:
        return
    _string_metadata_batcher.add_metadata(metadata)


def add_agent_info(metadata: Metadata):
    if _agent_info_batcher is None:
        return

    _agent_info_batcher.add_metadata(metadata)


def add_sql_metadata(metadata: Metadata):
    if _sql_metadata_batcher is None:
        return
    _sql_metadata_batcher.add_metadata(metadata)


def add_credential_metadata(metadata: Metadata):
    if _sts_credential_batcher is None:
        return
    _sts_credential_batcher.add_metadata(metadata)
