import chardet
import codecs
import hashlib
import os
import json
import threading
import time
import requests
import socket
from logging import getLogger
from typing import Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor

from aliyun.sdk.extension.arms.config.constant import APSARA_APM_METASERVER_ADDRESS

_logger = getLogger(__name__)

# K8S environment variable constants
K8S_CLUSTER_ID_ENV_KEY = "KUBERNETES_CLUSTER_ID"
K8S_POD_NAME_ENV_KEY = "KUBERNETES_POD_NAME"
K8S_POD_NAMESPACE_ENV_KEY = "KUBERNETES_POD_NAMESPACE"
K8S_POD_UID_ENV_KEY = "KUBERNETES_POD_UID"
K8S_POD_IP_ENV_KEY = "KUBERNETES_POD_IP"
K8S_POD_SERVICE_ACCOUNT_ENV_KEY = "KUBERNETES_POD_SERVICE_ACCOUNT"
K8S_NODE_NAME_ENV_KEY = "KUBERNETES_NODE_NAME"
K8S_HOST_IP_ENV_KEY = "KUBERNETES_HOST_IP"

# ARMS agent pod info path constants
ARMS_AGENT_PODINFO_PATH_VARIABLE = "ARMS_AGENT_PODINFO_PATH"
ARMS_K8S_DOWNWARD_VOLUME_MOUNT_PATH = "/etc/arms/podinfo"
K8S_DOWNWARD_VOLUME_MOUNT_PATH = "/etc/podinfo"
K8S_POD_LABELS_MOUNT_PATH = "/labels"
K8S_POD_ANNOTATIONS_MOUNT_PATH = "/annotations"

# Host metadata constants
META_SERVER_ADDRESS = "100.100.100.200"
CONNECTION_TIMEOUT = 1
READ_TIMEOUT = 1
HOST_NAME_PATH = "/meta-data/hostname"
VPC_ID_PATH = "/meta-data/vpc-id"
INSTANCE_IDENTITY_PATH = "/dynamic/instance-identity/document"

# Global variables for host metadata
_host_metadata_fetch_count = 0

def utf8_to_gbk(data):
    # 检测字节序列的编码
    encoding = chardet.detect(data)['encoding']

    # 确保字节序列是UTF-8编码的
    if encoding != 'utf-8':
        return None, ValueError('Input data is not utf-8 encoded')

    try:
        # 将字节序列解码为unicode字符串，然后重新编码为GBK
        # 注意：GBK可能与CP936(在Windows系统中GBK的别名)有微妙的区别，但通常是相似的
        # 如果在Windows系统上运行，可以考虑使用"gbk"替换"GB18030"
        encoded_data = data.decode('utf-8').encode('GB18030')
    except UnicodeError as e:
        # 如果转换过程中出现错误，返回错误信息
        return None, e

    return encoded_data, None


def generate_md5_hash(text):
    # 这里假设前面已经定义了 utf8_to_gbk 函数
    gbk_text, err = utf8_to_gbk(text.encode('utf-8'))
    if err:
        return ""

    # 计算GBK编码文本的MD5散列值
    m = hashlib.md5()
    m.update(gbk_text)
    return m.hexdigest()


def generate_md5_hash(text):
    try:
        # 假定 text 已正确转码为GBK
        gbk_text = text.encode('gbk')
    except UnicodeEncodeError:
        return ""

    # 计算GBK编码文本的MD5散列值
    m = hashlib.md5()
    m.update(gbk_text)
    return m.hexdigest()


def decode_user_id(uid):
    try:
        # 解析base-36编码的字符串为整数
        num = int(uid, 36)
    except ValueError as e:
        # 如果无法解析，返回错误
        return "", e

    # 将整数格式化为base-10的字符串并返回
    return str(num), None


def base36encode(number, alphabet='0123456789abcdefghijklmnopqrstuvwxyz'):
    """Converts an integer to a base36 string."""
    if not isinstance(number, int):
        raise TypeError('number must be an integer')

    base36 = ''
    sign = ''

    if number < 0:
        sign = '-'
        number = -number

    if 0 <= number < len(alphabet):
        return sign + alphabet[number]

    while number != 0:
        number, i = divmod(number, len(alphabet))
        base36 = alphabet[i] + base36

    return sign + base36


def get_user_id(license_key):
    if license_key:
        at_index = license_key.find('@')
        if at_index != -1:
            encoded_user_id = license_key[:at_index]
            user_id, err = decode_user_id(encoded_user_id)
            if err is None:
                return user_id
    return ""


def generate_app_id(user_id, app_name):
    if not user_id or not app_name:
        return ""

    # 将用户ID从字符串转换为整数
    try:
        user_id_36 = int(user_id)
        print(user_id_36)
    except ValueError:
        return ""

    # 生成MD5散列值
    md5_hash = generate_md5_hash(app_name + "token")
    length = 15
    if len(md5_hash) < length:
        length = len(md5_hash)

    # 获取MD5散列值的前15个字符，如果它们的长度足够的话
    md5_hash = md5_hash[:length]

    # 将用户ID转换为base-36并于MD5散列值连接
    result = base36encode(user_id_36) + "@" + md5_hash
    return result


def get_kv_pairs(file_path):
    """
    Read key-value pairs from a file.
    Equivalent to the Java getKVPairs method.

    Args:
        file_path (str): Path to the file containing key-value pairs

    Returns:
        dict: Dictionary of key-value pairs, or None if file doesn't exist or can't be read
    """
    if not os.path.exists(file_path):
        return None

    try:
        kv_pairs = {}
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.strip()
                if line and '=' in line:
                    key, value = line.split('=', 1)
                    kv_pairs[key.strip()] = value.strip()
        return kv_pairs
    except Exception as e:
        return None


class K8SMetaData:
    """
    K8S metadata class equivalent to the Java K8SMetaData class.
    """

    def __init__(self, cluster_id, pod_name, pod_namespace, pod_uid, pod_ip,
                 pod_service_account, node_name, host_ip, pod_labels, pod_annotations):
        self.cluster_id = cluster_id
        self.pod_name = pod_name
        self.pod_namespace = pod_namespace
        self.pod_uid = pod_uid
        self.pod_ip = pod_ip
        self.pod_service_account = pod_service_account
        self.node_name = node_name
        self.host_ip = host_ip
        self.pod_labels = pod_labels or {}
        self.pod_annotations = pod_annotations or {}

    def to_json(self):
        """Convert K8S metadata to JSON string."""
        return json.dumps({
            'clusterId': self.cluster_id,
            'podName': self.pod_name,
            'podNamespace': self.pod_namespace,
            'podUID': self.pod_uid,
            'podIp': self.pod_ip,
            'podServiceAccount': self.pod_service_account,
            'nodeName': self.node_name,
            'hostIp': self.host_ip,
            'podLabels': self.pod_labels,
            'podAnnotations': self.pod_annotations
        })


def gen_k8s_metadata():
    try:
        # Read environment variables
        cluster_id = os.getenv(K8S_CLUSTER_ID_ENV_KEY)
        pod_name = os.getenv(K8S_POD_NAME_ENV_KEY)
        pod_namespace = os.getenv(K8S_POD_NAMESPACE_ENV_KEY)
        pod_uid = os.getenv(K8S_POD_UID_ENV_KEY)
        pod_ip = os.getenv(K8S_POD_IP_ENV_KEY)
        pod_service_account = os.getenv(K8S_POD_SERVICE_ACCOUNT_ENV_KEY)
        node_name = os.getenv(K8S_NODE_NAME_ENV_KEY)
        host_ip = os.getenv(K8S_HOST_IP_ENV_KEY)

        # Read pod info path
        pod_info_path = os.getenv(ARMS_AGENT_PODINFO_PATH_VARIABLE, ARMS_K8S_DOWNWARD_VOLUME_MOUNT_PATH)

        # Check if pod path exists, if not use default path
        if not os.path.exists(pod_info_path):
            pod_info_path = K8S_DOWNWARD_VOLUME_MOUNT_PATH

        # Read pod labels and annotations
        pod_labels = get_kv_pairs(pod_info_path + K8S_POD_LABELS_MOUNT_PATH)
        pod_annotations = get_kv_pairs(pod_info_path + K8S_POD_ANNOTATIONS_MOUNT_PATH)

        # Create K8S metadata if we have valid data
        k8s_metadata = K8SMetaData(
            cluster_id=cluster_id,
            pod_name=pod_name,
            pod_namespace=pod_namespace,
            pod_uid=pod_uid,
            pod_ip=pod_ip,
            pod_service_account=pod_service_account,
            node_name=node_name,
            host_ip=host_ip,
            pod_labels=pod_labels,
            pod_annotations=pod_annotations
        )

        return k8s_metadata
    except Exception as e:
        return None


class HostMetaData:
    """
    Host metadata class equivalent to the Java HostMetaData class.
    """

    def __init__(self):
        self.host_name = ""
        self.instance_id = ""
        self.instance_type = ""
        self.mac = ""
        self.serial_number = ""
        self.account = ""
        self.image_id = ""
        self.region_id = ""
        self.zone_id = ""
        self.private_ip = ""
        self.vpc_id = ""

    def set_host_name(self, host_name):
        self.host_name = host_name

    def get_host_name(self):
        return self.host_name

    def set_instance_id(self, instance_id):
        self.instance_id = instance_id

    def get_instance_id(self):
        return self.instance_id

    def set_instance_type(self, instance_type):
        self.instance_type = instance_type

    def get_instance_type(self):
        return self.instance_type

    def set_mac(self, mac):
        self.mac = mac

    def get_mac(self):
        return self.mac

    def set_serial_number(self, serial_number):
        self.serial_number = serial_number

    def get_serial_number(self):
        return self.serial_number

    def set_account(self, account):
        self.account = account

    def get_account(self):
        return self.account

    def set_image_id(self, image_id):
        self.image_id = image_id

    def get_image_id(self):
        return self.image_id

    def set_region_id(self, region_id):
        self.region_id = region_id

    def get_region_id(self):
        return self.region_id

    def set_zone_id(self, zone_id):
        self.zone_id = zone_id

    def get_zone_id(self):
        return self.zone_id

    def set_private_ip(self, private_ip):
        self.private_ip = private_ip

    def get_private_ip(self):
        return self.private_ip

    def set_vpc_id(self, vpc_id):
        self.vpc_id = vpc_id

    def get_vpc_id(self):
        return self.vpc_id

    def to_json(self):
        """Convert host metadata to JSON string."""
        return json.dumps({
            'hostName': self.host_name,
            'instanceId': self.instance_id,
            'instanceType': self.instance_type,
            'mac': self.mac,
            'serialNumber': self.serial_number,
            'account': self.account,
            'imageId': self.image_id,
            'regionId': self.region_id,
            'zoneId': self.zone_id,
            'privateIp': self.private_ip,
            'vpcId': self.vpc_id
        })

    def __str__(self):
        return f"HostMetaData(host_name='{self.host_name}', instance_id='{self.instance_id}', region_id='{self.region_id}', zone_id='{self.zone_id}')"


def get_local_inet_address():
    """
    Get local IP address.
    Equivalent to ArmsNetworkUtils.getLocalInetAddress().

    Returns:
        str: Local IP address
    """
    try:
        # Create a socket to get local IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except Exception:
        return "127.0.0.1"


def http_get(url):
    """
    Make HTTP GET request.
    Equivalent to HttpUtils.get().

    Args:
        url (str): URL to request
        connection_timeout (int): Connection timeout in seconds
        read_timeout (int): Read timeout in seconds

    Returns:
        str: Response content or empty string if failed
    """
    try:
        response = requests.get(url, timeout=1)
        if response.status_code == 200:
            return response.text.strip()
        else:
            return ""
    except Exception as e:
        return ""


def get_host_metadata_from_ecs(meta_server_address):
    """
    Get host metadata from ECS metadata server.
    Equivalent to getHostMetadataFromEcs().

    Args:
        meta_server_address (str): Metadata server address

    Returns:
        HostMetaData: Host metadata object or None if failed
    """
    main_url_prefix = f"http://{meta_server_address}/latest"

    # Get hostname
    hostname = http_get(main_url_prefix + HOST_NAME_PATH)
    if not hostname:
        return None

    host_meta_data = HostMetaData()
    host_meta_data.set_host_name(hostname)

    # Get VPC ID if not set
    if not host_meta_data.get_vpc_id():
        vpc_id = http_get(main_url_prefix + VPC_ID_PATH)
        host_meta_data.set_vpc_id(vpc_id)

    # Get instance identity
    instance_identity = http_get(main_url_prefix + INSTANCE_IDENTITY_PATH)
    if instance_identity:
        try:
            instance_obj = json.loads(instance_identity)
            host_meta_data.set_instance_id(instance_obj.get("instance-id", ""))
            host_meta_data.set_instance_type(instance_obj.get("instance-type", ""))
            host_meta_data.set_mac(instance_obj.get("mac", ""))
            host_meta_data.set_serial_number(instance_obj.get("serial-number", ""))
            host_meta_data.set_account(instance_obj.get("owner-account-id", ""))
            host_meta_data.set_image_id(instance_obj.get("image-id", ""))
            host_meta_data.set_region_id(instance_obj.get("region-id", ""))
            host_meta_data.set_zone_id(instance_obj.get("zone-id", ""))
            host_meta_data.set_private_ip(instance_obj.get("private-ipv4", ""))
        except json.JSONDecodeError as e:
            return host_meta_data

    return host_meta_data


def get_host_metadata_from_acs():
    """
    Get host metadata from ACS annotations.
    Equivalent to getHostMetadataFromAcs().

    Returns:
        HostMetaData: Host metadata object
    """
    pod_info_path = os.getenv(ARMS_AGENT_PODINFO_PATH_VARIABLE, ARMS_K8S_DOWNWARD_VOLUME_MOUNT_PATH)

    if not os.path.exists(pod_info_path):
        pod_info_path = K8S_DOWNWARD_VOLUME_MOUNT_PATH

    pod_annotations = get_kv_pairs(pod_info_path + K8S_POD_ANNOTATIONS_MOUNT_PATH)

    host_meta_data = HostMetaData()

    if pod_annotations:
        host_meta_data.set_instance_id(pod_annotations.get("alibabacloud.com/instance-id", ""))
        host_meta_data.set_account(pod_annotations.get("alibabacloud.com/user-id", ""))
        host_meta_data.set_region_id(pod_annotations.get("topology.kubernetes.io/region", ""))
        host_meta_data.set_zone_id(pod_annotations.get("topology.kubernetes.io/zone", ""))
        host_meta_data.set_private_ip(pod_annotations.get("k8s.aliyun.com/pod-ip-addrs", ""))
        host_meta_data.set_vpc_id(pod_annotations.get("network.alibabacloud.com/vpc-id", ""))

    # Get hostname
    try:
        hostname = socket.gethostname()
        host_meta_data.set_host_name(hostname)
    except Exception:
        pass

    return host_meta_data


def get_host_metadata():
    try:
        meta_server_address = os.getenv(APSARA_APM_METASERVER_ADDRESS, "100.100.100.200")
        global _host_metadata_fetch_count

        if _host_metadata_fetch_count >= 5:
            # 防止无node节点(ask)情况下持续请求meta-server
            return HostMetaData()

        host_meta_data = get_host_metadata_from_ecs(meta_server_address)
        if host_meta_data is None:
            host_meta_data = get_host_metadata_from_acs()

        if host_meta_data is None:
            _host_metadata_fetch_count += 1
            return HostMetaData()

        return host_meta_data
    except Exception as e:
        return None