import base64
import hashlib
import hmac
import locale
from datetime import datetime
from typing import Dict, Tuple


def get_date():
    try:
        locale.setlocale(locale.LC_TIME, "C")
    except Exception as ex:
        pass
    return datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')


def sign(method: str, uri: str, access_key_id: str,
         access_key_secret: str, params: Dict[str, str],
         headers: Dict[str, str], body: bytes):
    content_length = 0
    content_md5, message = '', ''
    headers["x-log-apiversion"] = "0.6.0"
    headers["x-log-signaturemethod"] = "hmac-sha1"
    if body is not None and len(body) > 0:
        content_length = str(len(body))
        content_md5 = hashlib.md5(body).hexdigest().upper()
        headers['Content-MD5'] = content_md5
    date = get_date()
    headers['Date'] = date
    headers['Content-Length'] = content_length
    content_type = headers.get('Content-Type', '')

    message += method + "\n" + content_md5 + \
               "\n" + content_type + "\n" + date + "\n"

    # header
    filter_by_prefix = lambda t: t[0].startswith('x-log-') or t[0].startswith('x-acs-')
    slsHeaders = list(filter(filter_by_prefix, headers.items()))
    sort_by_key = lambda k: k[0]
    for [k, v] in sorted(slsHeaders, key=sort_by_key):
        message += k + ':' + v + "\n"
    # uri and params
    message += uri
    message += '?' if len(params) > 0 else ''
    sep = ''
    for [k, v] in sorted(params.items(), key=sort_by_key):
        message += sep + k + '=' + v
        sep = '&'
    # signature and authorization
    hashed = hmac.new(access_key_secret.encode('utf8'),
                      message.encode('utf8'), hashlib.sha1).digest()
    signature = base64.encodebytes(hashed).decode('utf8').rstrip()
    auth = f'LOG {access_key_id}:{signature}'
    headers['authorization'] = auth
    return headers
