from collections import deque
import threading


class RingBuffer:
    def __init__(self, max_size):
        self.max_size = max_size
        self.buffer = deque(maxlen=max_size)
        self.lock = threading.Lock()
        self.not_empty = threading.Condition(self.lock)

    def put(self, item):
        with self.lock:
            self.buffer.append(item)

    def get(self):
        with self.lock:
            if not self.buffer:
                return None
            return self.buffer.popleft()

    def put_with_lock(self, item):
        with self.lock:
            self.buffer.append(item)
            self.not_empty.notify()

    def get_with_lock(self):
        with self.lock:
            while not self.buffer:
                self.not_empty.wait()
            return self.buffer.popleft()
