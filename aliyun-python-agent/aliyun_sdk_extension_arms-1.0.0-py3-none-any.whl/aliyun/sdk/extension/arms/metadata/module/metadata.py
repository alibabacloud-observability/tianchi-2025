from abc import ABC, abstractmethod
from aliyun.sdk.extension.arms.proto.agent_info_pb2 import AgentInfo
from aliyun.sdk.extension.arms.proto.arms_credential_pb2 import ArmsSTSCredential
from aliyun.sdk.extension.arms.proto.arms_metadata_pb2 import (ArmsSqlMetaData, ArmsStringMetaData)
from aliyun.sdk.extension.arms.proto.arms_log_pb2 import Log


class Metadata(ABC):

    def serialize_to_string(self) -> str:
        return self._serialize_to_string()

    @abstractmethod
    def _serialize_to_string(self)->str:
        pass

    @abstractmethod
    def get_proto(self):
        pass

class CredentialMetadata(Metadata):

    def __init__(self, credential: ArmsSTSCredential):
        self.credential = credential

    def _serialize_to_string(self) -> str:
        return self.credential.SerializeToString()

    def get_proto(self):
        return self.credential


class AgentInfoMetadata(Metadata):

    def __init__(self, agent_info: AgentInfo):
        self.agent_info = agent_info

    def _serialize_to_string(self) -> str:
       return self.agent_info.SerializeToString()
    def get_proto(self):
        return self.agent_info


class SqlMetadata(Metadata):

    def __init__(self, sql_metadata: ArmsSqlMetaData):
        self.sql_metadata = sql_metadata

    def _serialize_to_string(self) -> str:
        return  self.sql_metadata.SerializeToString()

    def get_proto(self):
        return self.sql_metadata

class StringMetadata(Metadata):

    def __init__(self, string_metadata: ArmsStringMetaData):
        self.string_metadata = string_metadata

    def _serialize_to_string(self) -> str:
        return self.string_metadata.SerializeToString()

    def get_proto(self):
        return self.string_metadata

class SLSLogData(Metadata):

    def __init__(self, log: Log):
        self.log = log

    def _serialize_to_string(self) -> str:
        return self.log.SerializeToString()

    def get_proto(self):
        return self.log