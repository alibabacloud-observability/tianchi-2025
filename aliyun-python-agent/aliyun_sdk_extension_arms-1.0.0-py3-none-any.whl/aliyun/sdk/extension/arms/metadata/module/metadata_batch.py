from abc import ABC, abstractmethod

from aliyun.sdk.extension.arms.metadata.module.metadata import Metadata
from aliyun.sdk.extension.arms.proto.agent_info_pb2 import AgentInfo
from aliyun.sdk.extension.arms.proto.arms_credential_pb2 import ArmsSTSCredential
from aliyun.sdk.extension.arms.proto.arms_metadata_pb2 import (ArmsSqlMetaDataBatch, ArmsStringMetaDataBatch)
from aliyun.sdk.extension.arms.proto.arms_log_pb2 import LogGroup
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from typing import Optional


class MetadataBatch(ABC):

    def serialize_to_string(self) -> str:
        return self._serialize_to_string()

    def add_metadata(self, metadata: Metadata):
        self._add_metadata(metadata)

    def clear(self):
        self._clear()

    @abstractmethod
    def _add_metadata(self, metadata: Metadata):
        pass

    @abstractmethod
    def _serialize_to_string(self) -> str:
        pass

    @abstractmethod
    def _clear(self):
        pass


class CredentialMetadataBatch(MetadataBatch):

    def __init__(self):
        self.credential = None

    def _add_metadata(self, metadata: Metadata):
        self.credential = metadata

    def _serialize_to_string(self) -> str:
        return self.credential.serialize_to_string()

    def _clear(self):
        self.credential = None


class AgentInfoMetadataBatch(MetadataBatch):

    def __init__(self):
        self.agent_info = None  # type:

    def _add_metadata(self, metadata: Metadata):
        self.agent_info = metadata

    def _serialize_to_string(self) -> str:
        return self.agent_info.serialize_to_string()

    def _clear(self):
        self.agent_info = None


class SqlMetadataBatch(MetadataBatch):

    def __init__(self, sql_metadata_batch: Optional[ArmsSqlMetaDataBatch] = None):
        if sql_metadata_batch is None:
            self.sql_metadata_batch = ArmsSqlMetaDataBatch(licenseKey=ArmsEnv.instance().licenseKey,
                                                           agentId=ArmsEnv.instance().agentId)
        else:
            self.sql_metadata_batch = sql_metadata_batch

    def _add_metadata(self, metadata: Metadata):
        self.sql_metadata_batch.armsSqlMetaData.append(metadata.get_proto())

    def _serialize_to_string(self) -> str:
        return self.sql_metadata_batch.SerializeToString()

    def _clear(self):
        try:
            self.sql_metadata_batch.ClearField("armsSqlMetaData")
        except Exception as e:
            self.sql_metadata_batch = ArmsSqlMetaDataBatch(licenseKey=ArmsEnv.instance().licenseKey,
                                                           agentId=ArmsEnv.instance().agentId)


class StringMetadataBatch(MetadataBatch):

    def __init__(self, string_metadata_batch: Optional[ArmsStringMetaDataBatch] = None):
        if string_metadata_batch is None:
            self.string_metadata_batch = ArmsStringMetaDataBatch(licenseKey=ArmsEnv.instance().licenseKey,
                                                                 agentId=ArmsEnv.instance().agentId,
                                                                 acsCmsWorkspace=ArmsEnv.instance().workspace,
                                                                 acsArmsServiceId=ArmsEnv.instance().service_id)
        else:
            self.string_metadata_batch = string_metadata_batch

    def _add_metadata(self, metadata: Metadata):
        self.string_metadata_batch.armsStringMetaData.append(metadata.get_proto())

    def _serialize_to_string(self) -> str:
        return self.string_metadata_batch.SerializeToString()

    def _clear(self):
        try:
            self.string_metadata_batch.ClearField("armsStringMetaData")
        except Exception as e:
            self.string_metadata_batch = ArmsStringMetaDataBatch(licenseKey=ArmsEnv.instance().licenseKey,
                                                                 agentId=ArmsEnv.instance().agentId)


class SLSLogBatch(MetadataBatch):

    def __init__(self, sls_log_batch: Optional[LogGroup] = None):
        if sls_log_batch is None:
            self.sls_log_batch = LogGroup()
        else:
            self.sls_log_batch = sls_log_batch

    def _add_metadata(self, metadata: Metadata):
        self.sls_log_batch.Logs.append(metadata.get_proto())

    def _serialize_to_string(self) -> str:
        return self.sls_log_batch.SerializeToString()

    def _clear(self):
        try:
            self.sls_log_batch.ClearField("Logs")
        except Exception as exc:
            self.sls_log_batch = LogGroup()
