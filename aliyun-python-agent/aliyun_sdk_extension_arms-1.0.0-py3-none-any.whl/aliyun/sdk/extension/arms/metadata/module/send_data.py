import threading


class SendData:
    def __init__(self, send_time):
        self.send_time = send_time
        self.lock = threading.Lock()

    def set_send_time(self, send_time):
        with self.lock:
            self.send_time = send_time

    def get_send_time(self):
        with self.lock:
            return self.send_time
