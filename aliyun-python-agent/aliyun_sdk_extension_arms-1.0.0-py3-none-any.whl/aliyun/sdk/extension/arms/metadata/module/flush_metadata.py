
import threading

class _FlushMetadata:
    """Represents a request for the MetadataBatcher to flush metadatas."""

    __slots__ = ["event", "num_metadatas"]

    def __init__(self):
        self.event = threading.Event()
        self.num_metadatas = 0