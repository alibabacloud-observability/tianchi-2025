import os
import time
import sys
import traceback

from aliyun.sdk.extension.arms.common.obs import SingletonMeta
from aliyun.sdk.extension.arms.utils.encode_utils import crc_encode
from aliyun.sdk.extension.arms.proto.arms_metadata_pb2 import ArmsStringMetaDataBatch, ArmsStringMetaData
from aliyun.sdk.extension.arms.metadata import add_string_metadata, StringMetadata
from aliyun.sdk.extension.arms.metadata.excep.processor import processors


class ArmsRecordExceptionResult():

    def __init__(self, exception_id: str, exception_name: str):
        self.exception_id = exception_id
        self.exception_name = exception_name

    def get_exception_id(self):
        return self.exception_id

    def get_exception_name(self):
        return self.exception_name


class ArmsExceptionRecorder:

    def record_exception(self, e: BaseException) -> ArmsRecordExceptionResult:
        excep_name = type(e).__name__
        if e is None:
            return ArmsRecordExceptionResult(exception_id="UNSET", exception_name=excep_name)
        # msg = traceback.format_exception(et, ev, tb)
        msg = traceback.format_exception(
            type(e), value=e, tb=e.__traceback__
        )
        digest, exception_detail = self.extract_digest(msg, excep_name)
        except_id = crc_encode(digest)
        exception_id_str = f"{except_id}"
        self.send_excep_metadata(exception_id_str, excep_name)
        self.send_excep_metadata(f"{exception_id_str}_s", exception_detail)
        return ArmsRecordExceptionResult(exception_id=exception_id_str, exception_name=excep_name)

    def send_excep_metadata(self, exception_id: str, exception_detail: str):
        metadata = ArmsStringMetaData(
            stringId=exception_id,
            # 强制截断，避免过长
            stringValue=exception_detail[:4096]
        )
        add_string_metadata(StringMetadata(metadata))

    def extract_digest(self, msg: list, excep_type: str):
        sb = []
        detail = []
        for item in msg:
            m =  processors.process(item)
            detail.append(m)
            if ".py" in m:
                sb.append(m)


        return "".join(sb) + " excepType=" + excep_type, "".join(detail)


_exception_recorder = ArmsExceptionRecorder()


def record_exception(e: BaseException) -> ArmsRecordExceptionResult:
    return _exception_recorder.record_exception(e)
