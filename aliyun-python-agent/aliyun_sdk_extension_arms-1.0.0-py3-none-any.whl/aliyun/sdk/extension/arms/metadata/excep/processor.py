from abc import ABC, abstractmethod
from tracemalloc import BaseFilter
from typing import List



class BaseProcessor(ABC):
    _instance = None
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = object.__new__(cls)

        return cls._instance
    @abstractmethod
    def is_match(self, src: str) -> bool:
        pass

    def process(self, src: str) -> str:
        if not self.is_match(src):
            return src
        return self._process(src)

    @abstractmethod
    def _process(self, src: str) -> str:
        pass


class MachineAddressProcessor(BaseProcessor):

    _ADDRESS_PREFIX = "object at 0x"
    _REPLACE = "object at [addr]"


    def filter_address_info(self, input_string):
        result = []
        check_len = len(self._ADDRESS_PREFIX)
        src_len = len(input_string)
        if check_len > src_len:
            return input_string
        i = 0
        while i < src_len:
            if input_string[i:i + check_len] == self._ADDRESS_PREFIX:  # 检查0x开头
                # find start
                j = i + check_len
                while j < src_len and (input_string[j].isalnum() or input_string[j] in 'abcdefABCDEF'):
                    j += 1
                # replace [addr]
                result.append(self._REPLACE)
                # move to end position
                i = j
            else:
                result.append(input_string[i])
                i += 1

        return ''.join(result)

    def is_match(self, src: str) -> bool:
        if src is None or len(src) == 0 :
            return False
        cond =  self._ADDRESS_PREFIX in src
        return cond

    def _process(self, src: str) -> str:
        return self.filter_address_info(src)

_default_processors = [MachineAddressProcessor(),]

class ProcessorManager:
    def __init__(self):
        self._processors = []
        self._processors.extend(_default_processors)

    def process(self, src: str) -> str:
        target = src
        for processor in self._processors:
            target = processor.process(target)
        return target

    def add_processor(self, processor: BaseProcessor):
        if processor is None:
            return
        self._processors.append(processor)

    def remove_processor(self, processor: BaseProcessor):
        if processor is None:
            return
        self._processors.remove(processor)



processors = ProcessorManager()