import os

import jsonpath
# from aliyun.sdk.extension.arms.config import acm

arms_enable = True

config_properties = None

class ConfigProperties:
    def get_property(self, property_name):
        pass

    def get_property_or_default(self, property_name, default=None):
        p = self.get_property(property_name)
        if p is None:
            return default
        return p


class AcmConfigProperties(ConfigProperties):


    def __init__(self,client):
        self.client = client

    def get_property(self, property_name):
        if self.client is  None:
            return None
        try:
            config = self.client.get_config()
            if config is None:
                return None
            return jsonpath.jsonpath(config, "$." + property_name)[0]
        except Exception:
            return None


class StaticConfigProperties(ConfigProperties):
    def get_property(self, property_name):
        norm_property_name = property_name.replace(".", "_").upper()
        return os.environ.get(norm_property_name)


class ArmsConfigProperties(ConfigProperties):
    __acm_config = None
    __static_config = None

    def __init__(self, _acm_config, _static_config):
        self.__acm_config = _acm_config
        self.__static_config = _static_config

    def get_property(self, property_name):
        p = self.__acm_config.get_property(property_name)
        if p is None:
            p = self.__static_config.get_property(property_name)
        return p


def get_config_properties(client=None):
    global config_properties
    config_properties = ArmsConfigProperties(AcmConfigProperties(client), StaticConfigProperties())
    return config_properties
