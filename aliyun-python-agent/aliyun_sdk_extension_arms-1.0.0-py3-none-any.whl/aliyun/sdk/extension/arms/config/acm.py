import json
import threading
from threading import Lock
import os

from aliyun.sdk.extension.arms import nacos
import requests

from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state, \
    NETWORK_STRATEGY_INTERNAL, NETWORK_STRATEGY_PUBLIC
from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)

default_endpoint_internal_suffix_addr = "internal.edas.aliyun.com"
default_arms_namespace_id = "c845a7b4-23a1-4f28-a380-5ab30d8a280f"
finance_arms_namespace_id = "7602b2de-7eb8-4728-a13e-3f25954aee40"
gov_arms_namespace_id = "d8b73b92-9427-46e9-945c-6df6dca2af60"

acm_endpoint_name = {
    "cn-qingdao": "addr-qd-internal.edas.aliyun.com",
    "cn-beijing": "addr-bj-internal.edas.aliyun.com",
    "cn-hangzhou": "addr-hz-internal.edas.aliyun.com",
    "cn-shanghai": "addr-sh-internal.edas.aliyun.com",
    "cn-shenzhen": "addr-sz-internal.edas.aliyun.com",
    "cn-zhangjiakou": "addr-cn-zhangjiakou-internal.edas.aliyun.com",
    "cn-hongkong": "addr-hk-internal.edas.aliyuncs.com",
    "ap-southeast-1": "addr-singapore-internal.edas.aliyun.com",
    "cn-shanghai-finance-1": "addr-cn-shanghai-finance-1-internal.edas.aliyun.com",
    "cn-north-2-gov-1": "addr-cn-north-2-gov-1-internal.edas.aliyun.com",
    "cn-public": "acm.aliyun.com",
    "eu-central-1": "addr-eu-central-1-internal.edas.aliyun.com",
    "ap-southeast-2": "addr-ap-southeast-2-internal.edas.aliyun.com",
    "us-west-1": "addr-us-west-1-internal.edas.aliyun.com",
    "us-east-1": "addr-us-east-1-internal.edas.aliyun.com",
}


def get_internal_endpoint_and_namespace_id(region_id):
    if region_id == "cn-hangzhou":
        return "addr-hz-" + default_endpoint_internal_suffix_addr, default_arms_namespace_id
    elif region_id == "cn-beijing":
        return "addr-bj-" + default_endpoint_internal_suffix_addr, default_arms_namespace_id
    elif region_id == "cn-shanghai":
        return "addr-sh-" + default_endpoint_internal_suffix_addr, default_arms_namespace_id
    elif region_id == "cn-shenzhen":
        return "addr-sz-" + default_endpoint_internal_suffix_addr, default_arms_namespace_id
    elif region_id == "cn-qingdao":
        return "addr-qd-" + default_endpoint_internal_suffix_addr, default_arms_namespace_id
    elif region_id == "cn-hongkong":
        return "addr-hk-" + default_endpoint_internal_suffix_addr, default_arms_namespace_id
    elif region_id == "ap-southeast-1":
        return "addr-singapore-" + default_endpoint_internal_suffix_addr, default_arms_namespace_id
    elif region_id == "cn-hangzhou-finance":
        return "addr-hz-internal.jbp.console.aliyun.com", finance_arms_namespace_id
    elif region_id == "cn-shanghai-finance-1":
        return "addr-cn-shanghai-finance-1-" + default_endpoint_internal_suffix_addr, finance_arms_namespace_id
    elif region_id == "cn-shenzhen-finance-1":
        return "addr-sz-internal.jbp.console.aliyun.com", finance_arms_namespace_id
    elif region_id == "cn-north-2-gov-1":
        return "addr-cn-north-2-gov-1-" + default_endpoint_internal_suffix_addr, gov_arms_namespace_id
    if region_id in acm_endpoint_name:
        return acm_endpoint_name[region_id], default_arms_namespace_id
    return "", ""


def get_public_endpoint_and_namespace_id():
    return "acm.aliyun.com", default_arms_namespace_id


def get_server_list(addr):
    try:
        url = addr + "/diamond-server/diamond"
        response = requests.request("GET", url, timeout=1)
        response = response.text.replace('\n', ',')
        if response[len(response) - 1] == ',':
            response = response[:len(response) - 1]
        return response
    except Exception:
        return None


def is_connectable_with_url(url):
    try:
        response = requests.request("GET", url, timeout=1)
        if response.status_code == 200:
            return True
    except Exception:
        return False


class AmrsACMConfig:
    __slots__ = ['config_json', 'client', 'region_id', 'app_id', 'callback_funcs', 'is_init']

    def __init__(self):
        self.client = None
        self.region_id = "cn-hangzhou"
        self.app_id = ""
        self.callback_funcs = []
        self.config_json = None
        self.is_init = False

    def init_acm_client(self, region_id, app_id):
        try:
            self.region_id = region_id
            self.app_id = app_id.replace('@', '-')
            addr, ns = "", ""
            if global_arms_endpoints_state.network_strategy == NETWORK_STRATEGY_INTERNAL:
                addr, ns = get_internal_endpoint_and_namespace_id(region_id)
            elif global_arms_endpoints_state.network_strategy == NETWORK_STRATEGY_PUBLIC:
                addr, ns = get_public_endpoint_and_namespace_id()
            else:
                addr, ns = get_internal_endpoint_and_namespace_id(self.region_id)
                private = is_connectable_with_url("http://" + addr + ":8080/diamond-server/diamond")
                if addr == "" or not private:
                    addr, ns = get_public_endpoint_and_namespace_id()
            _logger.info(f"nacos addr: {addr}")
            server_list = get_server_list("http://" + addr + ":8080")
            if server_list is None:
                _logger.error("Failed to get server list, dynamic config will not be supported")
                return
            self.client = nacos.NacosClient(server_addresses=server_list, namespace=ns)
            self.client.set_options(callback_thread_num=1)
            self.monitor_agent_config()
            self.is_init = True
        except Exception as e:
            _logger.error("Failed to init acm client", e)

    def monitor_agent_config(self):
        if self.client is None:
            return
        data_id = "arms.trace." + self.app_id
        content = self.client.get_config(data_id, self.region_id, 1)
        _logger.info(f"[monitor_agent_config] get config: {content}")
        try:
            self.config_json = json.loads(content)
            self.exec_callback()
        except Exception as e:
            _logger.error(f"[monitor_agent_config] Exception:{e}")
        finally:
            pass
        if self._is_enable():
            self.client.add_config_watcher(data_id, self.region_id, self.callback_func)

    def get_config(self):
        # global config_json
        return self.config_json

    def _is_enable(self):
        flag = os.getenv("ENABLE_ACM", "true")
        if flag == "false":
            _logger.info("close acm client monitor")
            return False

        return True

    def callback_func(self, data):
        try:
            self.config_json = json.loads(data["raw_content"])
            self.exec_callback()
        except Exception as e:
            _logger.error(f"[callback_func] Exception: {e}")
        finally:
            pass

    def exec_callback(self):
        for callback in self.callback_funcs:
            callback()

    def register_callback(self, func):
        self.callback_funcs.append(func)
