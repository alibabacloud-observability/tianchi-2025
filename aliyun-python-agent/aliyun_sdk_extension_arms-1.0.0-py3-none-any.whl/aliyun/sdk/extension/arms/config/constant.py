ARMS_AGENT_ENABLE_KEY = "profiler.enable"
PROFILER_SAMPLING_ENABLE_KEY = "profiler.sampling.enable"
PROFILER_SAMPLING_RATE_KEY = "profiler.sampling.rate"

PROFILER_SELF_MONITOR_KEY = "profiler.selfMonitor.enable"

HOST_TAGS = "arms.host.tags"
PROFILER_APP_TAGS = "profiler.tags.appTags"
PROFILER_NETWORK_STRATEGY = "profiler.network.strategy"
PROFILER_COLLECTOR_ENDPOINT = "profiler.collector.oneEndpoint"
CMS_WORKSPACE = "x-cms-workspace"
SLS_PROJECT = "x-arms-project"
MAX_TAG_SIZE = 200

PROFILER_FASTAPI_KEY = "profiler.fastapi.enable"
PROFILER_FLASK_KEY = "profiler.flask.enable"
PROFILER_DJANGO_KEY = "profiler.django.enable"
PROFILER_REQUESTS_KEY = "profiler.requests.enable"
PROFILER_AIO_HTTP_CLIENT_KEY = "profiler.aiohttpclient.enable"
PROFILER_DIFY_KEY = "profiler.dify.enable"
PROFILER_DASHSCOPE_KEY = "profiler.dashscope.enable"
PROFILER_LANGCHAIN_KEY = "profiler.langchain.enable"
PROFILER_OPENAI_KEY = "profiler.openai.enable"
PROFILER_LLAMA_INDEX_KEY = "profiler.llamaindex.enable"


CMS_WORKSPACE_KEY_IN_SPAN = "acs.cms.workspace"
ARMS_SERVICE_ID_KEY_IN_SPAN = "acs.arms.service.id"
CMS_WORKSPACE_KEY_IN_METRIC = "acs_cms_workspace"
ARMS_SERVICE_ID_KEY_IN_METRIC = "acs_arms_service_id"
ARMS_P_SERVICE_ID_KEY_IN_METRIC = "acs_arms_p_service_id"

PROFILER_GENAI_SPLITAPP_KEY = "profiler.genai.splitApp.enable"

APSARA_APM_METASERVER_ADDRESS = "APSARA_APM_METASERVER_ADDRESS"

# 应用的类型
# 1. 微服务应用(microservice)
# 2. 大语言模型应用(app)，包括langchain，dashscope，openai等
# 3. 大语言模型服务(model)，包括vllm，sglang等
APSARA_APM_APP_TYPE = "APSARA_APM_APP_TYPE"

APSARA_APM_INSTRUMENTATION_CHILD_PROCESS = "APSARA_APM_INSTRUMENTATION_CHILD_PROCESS"

COMPONENT_LIST = {
    "fastApi": PROFILER_FASTAPI_KEY,
    "flask": PROFILER_FLASK_KEY,
    "django": PROFILER_DJANGO_KEY,
    "requests": PROFILER_REQUESTS_KEY,
    "aiohttpclient": PROFILER_AIO_HTTP_CLIENT_KEY,
    "dify": PROFILER_DIFY_KEY,
    "langchain": PROFILER_LANGCHAIN_KEY,
    "openai": PROFILER_OPENAI_KEY,
    "dashscope": PROFILER_DASHSCOPE_KEY,
    "llamaIndex": PROFILER_LLAMA_INDEX_KEY,
}
# agent
