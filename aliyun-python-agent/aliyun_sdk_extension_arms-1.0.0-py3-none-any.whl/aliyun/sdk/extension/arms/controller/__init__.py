from aliyun.sdk.extension.arms.controller.env import Environment, InstrumentorEnum, ComponentEnum

COMPONENT_CONTROLLER_LIST = {
    Environment.ENABLE_FASTAPI: {"name": InstrumentorEnum.FAST_API.value, "default": True},
    Environment.ENABLE_REQUESTS: {"name": InstrumentorEnum.REQUESTS.value, "default": True},
    Environment.ENABLE_FLASK: {"name": InstrumentorEnum.FLASK.value, "default": True},
    Environment.ENABLE_ASGI: {"name": InstrumentorEnum.ASGI.value, "default": True},
    Environment.ENABLE_WSGI: {"name": InstrumentorEnum.WSGI.value, "default": True},
    Environment.ENABLE_DJANGO: {"name": InstrumentorEnum.DJANGO.value, "default": True},
    Environment.ENABLE_DIFY: {"name": InstrumentorEnum.DIFY.value, "default": True},
    Environment.ENABLE_REDIS: {"name": InstrumentorEnum.REDIS.value, "default": True},
    Environment.ENABLE_HTTPX: {"name": InstrumentorEnum.HTTPX.value, "default": True},
    Environment.ENABLE_SQLALCHEMY: {"name": InstrumentorEnum.SQLALCHEMY.value, "default": True},
    Environment.ENABLE_AIOHTTPCLIENT: {"name": InstrumentorEnum.AIOHTTP_CLIENT.value, "default": True},
    Environment.ENABLE_AGENTINFO: {"name": ComponentEnum.AGENT_INFO.value, "default": True},
    Environment.ENABLE_METRICEXPORTER: {"name": ComponentEnum.METRIC_EXPORTER.value, "default": True},
    Environment.ENABLE_TRACEEXPORTER: {"name": ComponentEnum.TRACE_EXPORTER.value, "default": True},
    Environment.ENABLE_RUNTIME: {"name": ComponentEnum.RUNTIME.value, "default": True},
    Environment.ENABLE_DASHSCOPE: {"name": InstrumentorEnum.DASHSCOPE.value, "default": True},
    Environment.ENABLE_LLAMA_INDEX: {"name": InstrumentorEnum.LLAMA_INDEX.value, "default": True},
    Environment.ENABLE_OPENAI: {"name": InstrumentorEnum.OPENAI.value, "default": True},
    Environment.ENABLE_LANGCHAIN: {"name": InstrumentorEnum.LANGCHING.value, "default": True},
}
