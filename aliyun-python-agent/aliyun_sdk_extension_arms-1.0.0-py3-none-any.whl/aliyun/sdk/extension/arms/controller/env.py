from enum import Enum


class InstrumentorEnum(Enum):
    FAST_API = "fastApi"

    FLASK = "flask"

    DJANGO = "django"

    AIOHTTP_CLIENT = "aiohttp_client"

    REQUESTS = "requests"

    HTTPX = "httpx"

    SQLALCHEMY = "sqlalchemy"

    REDIS = "redis"

    DIFY = "dify"

    DASHSCOPE = "dashscope"

    OPENAI = "openai"

    LLAMA_INDEX = "llama_index"

    LANGCHING = "langchain"

    ASGI = "asgi"

    WSGI = "wsgi"

    MCP = "mcp"

    SGLANG = "sglang"


class ComponentEnum(Enum):

    AGENT_INFO = "agentInfo"

    TRACE_EXPORTER = "traceExporter"

    METRIC_EXPORTER = "metricExporter"

    RUNTIME = "runtime"


class Environment:
    ENABLE_FASTAPI = "ENABLE_FASTAPI"
    ENABLE_REQUESTS = "ENABLE_REQUESTS"
    ENABLE_FLASK = "ENABLE_FLASK"
    ENABLE_ASGI = "ENABLE_ASGI"
    ENABLE_WSGI = "ENABLE_WSGI"
    ENABLE_DJANGO = "ENABLE_DJANGO"
    ENABLE_DIFY = "ENABLE_DIFY"
    ENABLE_REDIS = "ENABLE_REDIS"
    ENABLE_HTTPX = "ENABLE_HTTPX"
    ENABLE_SQLALCHEMY = "ENABLE_SQLALCHEMY"
    ENABLE_AIOHTTPCLIENT = "ENABLE_AIOHTTPCLIENT"
    ENABLE_AGENTINFO = "ENABLE_AGENTINFO"
    ENABLE_METRICEXPORTER = "ENABLE_METRICEXPORTER"
    ENABLE_TRACEEXPORTER = "ENABLE_TRACEEXPORTER"
    ENABLE_RUNTIME = "ENABLE_RUNTIME"
    ENABLE_DASHSCOPE = "ENABLE_DASHSCOPE"
    ENABLE_LLAMA_INDEX = "ENABLE_LLAMA_INDEX"
    ENABLE_OPENAI = "ENABLE_OPENAI"
    ENABLE_LANGCHAIN = "ENABLE_LANGCHAIN"
    ENABLE_MCP = "ENABLE_MCP"
