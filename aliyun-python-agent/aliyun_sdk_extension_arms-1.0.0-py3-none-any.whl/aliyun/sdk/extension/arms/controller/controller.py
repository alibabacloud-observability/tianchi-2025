import os
from abc import ABC, abstractmethod
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.controller.env import InstrumentorEnum, ComponentEnum
from enum import Enum

_logger = getLogger(__name__)


class BaseController(ABC):

    def __init__(self):
        self._enable = True

    def is_open(self) -> bool:
        """
        check is open this instrumentation
        """
        return self._enable

    def open(self):
        """
        open instrument
        """
        self._enable = True

    def close(self):
        """
        close instrument
        """
        self._enable = False

    @abstractmethod
    def start(self):
        """
        start controller
        """
        pass


class SampleController(BaseController):
    """
    sample controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass


class EnvironInstrumentorEnum(Enum):
    Dashscope = "Dashscope",
    OpenAI = "OpenAI",
    LlamaIndex = "LlamaIndex",
    Langchain = "Langchain"
    Runtime = "Runtime"
    MCP = "MCP"


class EnvironController(BaseController):

    def __init__(self, environ_instrumentor: EnvironInstrumentorEnum):
        super().__init__()
        self._enable_instrumentor = ""
        if environ_instrumentor == EnvironInstrumentorEnum.Dashscope:
            self._enable_instrumentor = "ENABLE_DASHSCOPE_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.OpenAI:
            self._enable_instrumentor = "ENABLE_OPENAI_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.LlamaIndex:
            self._enable_instrumentor = "ENABLE_LLAMA_INDEX_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Langchain:
            self._enable_instrumentor = "ENABLE_LANGCHAIN_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Runtime:
            self._enable_instrumentor = "ENABLE_GC_TOTAL_TIME_CALLBACK"
        elif environ_instrumentor == EnvironInstrumentorEnum.MCP:
            self._enable_instrumentor = "ENABLE_MCP_INSTRUMENTOR"

    def start(self):
        pass

    def close(self):
        os.environ[self._enable_instrumentor] = "false"
        _logger.warning(f"[close] close: {self._enable_instrumentor}")

    def open(self):
        os.environ[self._enable_instrumentor] = "true"
        _logger.warning(f"[open] open: {self._enable_instrumentor}")


class FastApiController(BaseController):
    """
    fastapi instrumentor controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass


class AioHttpClientController(BaseController):
    """
    aiohttp client instrumentor controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass


class RequestsClientController(BaseController):
    """
    requests client instrumentor controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass


fastApiController = FastApiController()
requestsController = RequestsClientController()
aiohttpClientController = AioHttpClientController()
djangoController = SampleController()
httpxController = SampleController()
flaskController = SampleController()
difyController = SampleController()
redisController = SampleController()
sqlalchemyController = SampleController()
sglangController = SampleController()

agentInfoController = SampleController()
traceExporterController = SampleController()
metricExporterController = SampleController()

dashscopeController = EnvironController(EnvironInstrumentorEnum.Dashscope)
openApiController = EnvironController(EnvironInstrumentorEnum.OpenAI)
llamaIndexController = EnvironController(EnvironInstrumentorEnum.LlamaIndex)
langchainController = EnvironController(EnvironInstrumentorEnum.Langchain)
runtimeController = EnvironController(EnvironInstrumentorEnum.Runtime)
mcpController = EnvironController(EnvironInstrumentorEnum.MCP)


class ControllerManager:

    def __init__(self):
        self._controllers = {
            InstrumentorEnum.FAST_API.value: fastApiController,
            InstrumentorEnum.REQUESTS.value: requestsController,
            InstrumentorEnum.HTTPX.value: httpxController,
            InstrumentorEnum.DJANGO.value: djangoController,
            InstrumentorEnum.FLASK.value: flaskController,
            InstrumentorEnum.DIFY.value: difyController,
            InstrumentorEnum.REDIS.value: redisController,
            InstrumentorEnum.SQLALCHEMY.value: sqlalchemyController,
            InstrumentorEnum.AIOHTTP_CLIENT: aiohttpClientController,
            InstrumentorEnum.SGLANG.value: sglangController,
            # InstrumentorEnum.REDIS.value: redisController,
            # InstrumentorEnum.SQLALCHEMY.value: sqlalchemyController,
            InstrumentorEnum.AIOHTTP_CLIENT.value: aiohttpClientController,
            InstrumentorEnum.REDIS.value: redisController,
            InstrumentorEnum.SQLALCHEMY.value: sqlalchemyController,
            InstrumentorEnum.AIOHTTP_CLIENT: aiohttpClientController,
            InstrumentorEnum.DASHSCOPE.value: dashscopeController,
            InstrumentorEnum.OPENAI.value: openApiController,
            InstrumentorEnum.LLAMA_INDEX.value: llamaIndexController,
            InstrumentorEnum.LANGCHING.value: langchainController,
            InstrumentorEnum.MCP.value: mcpController,
            ComponentEnum.AGENT_INFO.value: agentInfoController,
            ComponentEnum.TRACE_EXPORTER.value: traceExporterController,
            ComponentEnum.METRIC_EXPORTER.value: metricExporterController,
            ComponentEnum.RUNTIME.value: runtimeController,
        }

    def start(self):
        """
        start all controller
        """
        for name in self._controllers:
            controller = self._get_controller_by_name(name)
            if controller is not None:
                controller.start()

    def open(self, name):
        if name in self._controllers:
            controller = self._controllers[name]
            controller.open()
            _logger.warning(f"===>open {name}")

    def close(self, name):

        if name in self._controllers:
            controller = self._controllers[name]
            controller.close()
            _logger.warning(f"===> close {name}")

    def open_all(self):
        """
        open all
        """
        for name in self._controllers:
            controller = self._get_controller_by_name(name)
            if controller is not None:
                controller.open()

    def _get_controller_by_name(self, name: str):
        controller = self._controllers[name]
        return controller

    def close_all(self):
        """
        close all
        """
        for name in self._controllers:
            controller = self._get_controller_by_name(name)
            if controller is not None:
                controller.close()


controllerManager = ControllerManager()
