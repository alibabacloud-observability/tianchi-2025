class ArmsEndpoints:
    def __init__(self, endpoint, split_char_sequence, health_check_path):
        endpoint = endpoint.replace("-internal", "")
        endpoint = endpoint.replace("-intranet", "")
        endpoint = endpoint.replace("-share", "")

        self.public_endpoint = endpoint
        idx = endpoint.find(split_char_sequence)
        if idx <= 0 or idx > len(endpoint):
            self.internal_endpoint = endpoint
            self.intranet_endpoint = endpoint
            self.share_endpoint = endpoint
        else:
            prefix = endpoint[:idx]
            suffix = endpoint[idx:]
            self.internal_endpoint = prefix + "-internal" + suffix
            self.intranet_endpoint = prefix + "-intranet" + suffix
            self.share_endpoint = prefix + "-share" + suffix
        self.health_check_path = health_check_path
        self.public_reachable = False
        self.internal_reachable = False
        self.intranet_reachable = False
        self.share_reachable = False



