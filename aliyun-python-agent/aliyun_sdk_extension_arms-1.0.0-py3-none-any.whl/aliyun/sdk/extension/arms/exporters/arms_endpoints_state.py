import os
import sched
import threading
import time

from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.common.endpoints import GetTraceEndpointByRegion, GetMetricsEndpointByRegion, \
    GetTraceMetaEndpointByRegion
from aliyun.sdk.extension.arms.common.utils.arms_utils import is_default_cms_workspace
from aliyun.sdk.extension.arms.exporters.arms_endpoints import ArmsEndpoints
from aliyun.sdk.extension.arms.common.utils.arms_utils import get_md5_string_for_xtrace_project
from aliyun.sdk.extension.arms.utils import network_utils

REGION_ID_LENGTH_THRESHOLD = 18

PROFILER_COLLECTOR_ONEENDPOINT_KEY = "PROFILER_COLLECTOR_ONEENDPOINT"
PROFILER_NETWORK_STRATEGY_KEY = "PROFILER_NETWORK_STRATEGY"

NETWORK_STRATEGY_INTERNAL = "internal"
NETWORK_STRATEGY_PUBLIC = "public"
NETWORK_STRATEGY_AUTO = "auto"


class ArmsEndpointState:
    def __init__(self):
        self.trace_endpoints = ArmsEndpoints(ArmsEnv.instance().getTraceEndpoint(), ".aliyuncs", "/api/checkHealth")
        self.metric_endpoints = ArmsEndpoints(ArmsEnv.instance().getMetricsEndpoint(), ".arms", "/health/readiness")
        self.meta_endpoints = ArmsEndpoints(ArmsEnv.instance().getMetaEndpoint(), ".aliyuncs", "/api/checkHealth")
        self.one_endpoints = None
        self.one_endpoint = ""
        self.use_one_endpoints = False
        self.sls_project = ""
        self.force_one_endpoint = os.getenv(PROFILER_COLLECTOR_ONEENDPOINT_KEY, "")
        self.network_strategy = os.getenv(PROFILER_NETWORK_STRATEGY_KEY, "auto")
        # 兼容老逻辑
        if bool(os.getenv("ARMS_IS_PUBLIC", False)):
            self.network_strategy = NETWORK_STRATEGY_PUBLIC
        self.init_one_endpoint()
        self.start_health_check_task()

    def init_one_endpoint(self):
        cms_workspace = ArmsEnv.instance().workspace
        user_id = ArmsEnv.instance().user_id
        region_id = ArmsEnv.instance().regionId
        is_default_workspace = is_default_cms_workspace(user_id, region_id, cms_workspace)
        is_finance_or_long_name_region = ("finance" in region_id or len(region_id) > REGION_ID_LENGTH_THRESHOLD)
        project = ""
        if is_default_workspace:
            if is_finance_or_long_name_region:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id + ArmsEnv.instance().regionId)
            else:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id) + "-" + ArmsEnv.instance().regionId
        else:
            if is_finance_or_long_name_region:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id + cms_workspace + ArmsEnv.instance().regionId)
            else:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id + cms_workspace) + "-" + ArmsEnv.instance().regionId
        self.one_endpoints = ArmsEndpoints(project + "." + region_id + "." + "log.aliyuncs.com", ".log.", "/health")
        self.use_one_endpoints = not is_default_workspace
        self.cms_workspace = cms_workspace
        self.sls_project = project

    def get_one_endpoint(self):
        if self.one_endpoint:
            return self.one_endpoint
        if self.network_strategy == NETWORK_STRATEGY_INTERNAL:
            return self.one_endpoints.intranet_endpoint
        elif self.network_strategy == NETWORK_STRATEGY_PUBLIC:
            return self.one_endpoints.share_endpoint
        current_reachable = self.get_current_reachable_endpoint(self.one_endpoints)
        return current_reachable if current_reachable else self.one_endpoints.intranet_endpoint

    def get_current_reachable_endpoint(self, endpoints):
        if endpoints.internal_reachable:
            return endpoints.internal_endpoint
        elif endpoints.intranet_reachable:
            return endpoints.intranet_endpoint
        elif endpoints.share_reachable:
            return endpoints.share_endpoint
        elif endpoints.public_reachable:
            return endpoints.public_endpoint
        return None

    def get_full_trace_url(self):
        if self.use_one_endpoints:
            if self.force_one_endpoint and len(self.force_one_endpoint) > 0:
                return self.concat_full_url(self.force_one_endpoint + "/apm/trace/api/v1/arms/otel/")
            else:
                return self.concat_full_url(self.get_one_endpoint() + "/apm/trace/api/v1/arms/otel/")

        endpoint = self.get_endpoint_by_strategy_or_auto(self.trace_endpoints,
                                                         lambda: self.trace_endpoints.internal_endpoint)
        return self.concat_full_url(endpoint + "/api/v1/arms/otel/")

    def get_full_metric_url(self):
        if self.use_one_endpoints:
            if self.force_one_endpoint and len(self.force_one_endpoint) > 0:
                return self.concat_full_url(self.force_one_endpoint + "/apm/metric/collector/arms/ot/")
            else:
                return self.concat_full_url(self.get_one_endpoint() + "/apm/metric/collector/arms/ot/")
        endpoint = self.get_endpoint_by_strategy_or_auto(self.metric_endpoints,
                                                         lambda: self.metric_endpoints.intranet_endpoint)
        return self.concat_full_url(endpoint + "/collector/arms/ot/")

    def get_full_meta_url(self):
        if self.use_one_endpoints:
            if self.force_one_endpoint and len(self.force_one_endpoint) > 0:
                return self.concat_full_url(self.force_one_endpoint + "/apm/meta/api/v2/arms/metadata/")
            else:
                return self.concat_full_url(self.get_one_endpoint() + "/apm/meta/api/v2/arms/metadata/")
        endpoint = self.get_endpoint_by_strategy_or_auto(self.meta_endpoints,
                                                         lambda: self.meta_endpoints.internal_endpoint)
        return self.concat_full_url(endpoint + "/api/v2/arms/metadata/")

    def concat_full_url(self, endpoint):
        return "http://" + endpoint + ArmsEnv.instance().licenseKey + "/" + ArmsEnv.instance().appId

    def get_endpoint_by_strategy_or_auto(self, endpoints, internal_endpoint_supplier):
        endpoint = None
        if self.network_strategy == NETWORK_STRATEGY_INTERNAL:
            endpoint = internal_endpoint_supplier()
        elif self.network_strategy == NETWORK_STRATEGY_PUBLIC:
            endpoint = endpoints.public_endpoint
        else:
            endpoint = self.get_current_reachable_endpoint(endpoints)
        return endpoint if endpoint else self.one_endpoints.intranet_endpoint

    def start_health_check_task(self):

        def detect_reachable_endpoint(endpoints, check_flag):
            reached_endpoint = None

            if (check_flag & 1) > 0 and not endpoints.internal_reachable and network_utils.is_url_reachable(
                    endpoints.internal_endpoint + endpoints.health_check_path
            ):
                endpoints.internal_reachable = True
                reached_endpoint = endpoints.intranet_endpoint
            if endpoints.internal_reachable:
                return reached_endpoint

            if (check_flag & 2) > 0 and not endpoints.intranet_reachable and network_utils.is_url_reachable(
                    endpoints.intranet_endpoint + endpoints.health_check_path
            ):
                endpoints.intranet_reachable = True
                reached_endpoint = endpoints.intranet_endpoint

            if endpoints.intranet_reachable:
                return reached_endpoint

            if (check_flag & 4) > 0 and not endpoints.share_reachable and network_utils.is_url_reachable(
                    endpoints.share_endpoint + endpoints.health_check_path
            ):
                endpoints.share_reachable = True
                reached_endpoint = endpoints.share_endpoint

            if endpoints.share_reachable:
                return reached_endpoint

            if (check_flag & 8) > 0 and not endpoints.public_reachable and network_utils.is_url_reachable(
                    endpoints.public_endpoint + endpoints.health_check_path
            ):
                endpoints.public_reachable = True
                reached_endpoint = endpoints.public_endpoint

            return reached_endpoint

        def health_check_task_func():
            # detect trace
            detect_reachable_endpoint(self.trace_endpoints, 11)
            # detect metric
            detect_reachable_endpoint(self.metric_endpoints, 10)
            # detect meta
            detect_reachable_endpoint(self.meta_endpoints, 11)
            # detect sls endpoint
            detect_reachable_endpoint(self.one_endpoints, 14)
            time.sleep(60)

        thread = threading.Thread(target=health_check_task_func)
        thread.daemon = True
        thread.start()



global_arms_endpoints_state = ArmsEndpointState()

