# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import gzip

from aliyun.sdk.extension.arms.self_monitor.self_monitor import _self_monitor_metrics

from aliyun.sdk.extension.arms.config.constant import PROFILER_GENAI_SPLITAPP_KEY
from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state
from aliyun.sdk.extension.arms.logger import getLogger
import zlib
import snappy
from io import BytesIO
from os import environ
from typing import Dict, Optional, Callable
from time import sleep

import requests

from aliyun.opentelemetry.exporter.otlp.proto.common._internal import (
    _create_exp_backoff_generator,
)
from aliyun.opentelemetry.exporter.otlp.proto.common.trace_encoder import (
    encode_spans,
)
from aliyun.sdk.extension.arms.controller.controller import traceExporterController
from aliyun.sdk.extension.arms.utils.env_utils import convert_to_env_var, is_true_value
from aliyun.opentelemetry.sdk.environment_variables import (
    OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE,
    OTEL_EXPORTER_OTLP_TRACES_COMPRESSION,
    OTEL_EXPORTER_OTLP_TRACES_ENDPOINT,
    OTEL_EXPORTER_OTLP_TRACES_HEADERS,
    OTEL_EXPORTER_OTLP_TRACES_TIMEOUT,
    OTEL_EXPORTER_OTLP_CERTIFICATE,
    OTEL_EXPORTER_OTLP_COMPRESSION,
    OTEL_EXPORTER_OTLP_ENDPOINT,
    OTEL_EXPORTER_OTLP_HEADERS,
    OTEL_EXPORTER_OTLP_TIMEOUT,
)
from aliyun.opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
# from aliyun.opentelemetry.exporter.otlp.proto.http import (
#     _OTLP_HTTP_HEADERS,
# )
from opentelemetry.util.re import parse_env_headers
import enum

_logger = getLogger(__name__)

_OTLP_HTTP_HEADERS = {
    "Content-Type": "application/x-protobuf",
    # "User-Agent": "OTel-OTLP-Exporter-Python/" + __version__,
}


class Compression(enum.Enum):
    NoCompression = "none"
    Deflate = "deflate"
    Gzip = "gzip"
    Snappy = "snappy"


DEFAULT_COMPRESSION = Compression.NoCompression
DEFAULT_ENDPOINT = "http://localhost:4318/"
DEFAULT_TRACES_EXPORT_PATH = "v1/traces"
DEFAULT_TIMEOUT = 10  # in seconds

X_TRACE_FLAG = 'x-trace-flag'
X_TRACE = 'x-trace'
X_TRACE_PROCESS = 'x-trace-process'
TRACE_REPLACE_SERVICE = 'trace-replace-service'

class OTLPSpanExporter(SpanExporter):
    _MAX_RETRY_TIMEOUT = 64

    def __init__(
            self,
            certificate_file: Optional[str] = None,
            headers: Optional[Dict[str, str]] = None,
            timeout: Optional[int] = None,
            compression: Optional[Compression] = None,
            session: Optional[requests.Session] = None,
    ):
        self._endpoint = global_arms_endpoints_state.get_full_trace_url()
        self._certificate_file = certificate_file or environ.get(
            OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE,
            environ.get(OTEL_EXPORTER_OTLP_CERTIFICATE, True),
        )
        headers_string = environ.get(
            OTEL_EXPORTER_OTLP_TRACES_HEADERS,
            environ.get(OTEL_EXPORTER_OTLP_HEADERS, ""),
        )
        self._headers = headers or parse_env_headers(headers_string)
        if is_enable_multi_app():
            self.add_split_multi_app_header()
        self._timeout = timeout or int(
            environ.get(
                OTEL_EXPORTER_OTLP_TRACES_TIMEOUT,
                environ.get(OTEL_EXPORTER_OTLP_TIMEOUT, DEFAULT_TIMEOUT),
            )
        )
        self._compression = compression or _compression_from_env()
        self._session = session or requests.Session()
        self._session.headers.update(self._headers)
        self._shutdown = False

    def add_split_multi_app_header(self):
        if self._headers is None:
            self._headers = {}
        self._headers[X_TRACE_FLAG] = X_TRACE
        self._headers[X_TRACE_PROCESS] = TRACE_REPLACE_SERVICE

    def _export(self, serialized_data: bytes):
        if serialized_data is None or len(serialized_data) == 0:
            _logger.warning(f"[_export] serialized_data is None or less than zero ")
            return
        data = serialized_data
        if self._compression == Compression.Gzip:
            gzip_data = BytesIO()
            with gzip.GzipFile(fileobj=gzip_data, mode="w") as gzip_stream:
                gzip_stream.write(serialized_data)
            data = gzip_data.getvalue()
        elif self._compression == Compression.Deflate:
            data = zlib.compress(serialized_data)
        elif self._compression == Compression.Snappy:
            data = snappy.compress(serialized_data)
        _logger.debug(
            f"exporter header :{self._session.headers} data size: {len(data)} serialized_data: {serialized_data}")
        self._endpoint = global_arms_endpoints_state.get_full_trace_url()
        resp = self._session.post(
            url=self._endpoint,
            data=data,
            verify=self._certificate_file,
            timeout=self._timeout,
        )
        if resp.status_code != 200:
            _logger.warning(
                f"[trace_exporter] Sending span to endpoints: {self._endpoint}, response code is: {resp.status_code}")
        result = "success" if resp.ok else "fail"
        _self_monitor_metrics.record_agent_span_report(len(data),
            {"status": resp.status_code, "result": result})
        return resp

    @staticmethod
    def _retryable(resp: requests.Response) -> bool:
        if resp.status_code == 408:
            return True
        if resp.status_code >= 500 and resp.status_code <= 599:
            return True
        return False

    def _serialize_spans(self, spans):
        return encode_spans(spans).SerializePartialToString()

    def _export_serialized_spans(self, serialized_data):
        for delay in _create_exp_backoff_generator(
                max_value=self._MAX_RETRY_TIMEOUT
        ):
            if delay == self._MAX_RETRY_TIMEOUT:
                return SpanExportResult.FAILURE
            resp = self._export(serialized_data)
            # pylint: disable=no-else-return
            if resp.ok:
                return SpanExportResult.SUCCESS
            elif self._retryable(resp):
                _logger.warning(
                    "Transient error %s encountered while exporting span batch, retrying in %ss.",
                    resp.reason,
                    delay,
                )
                sleep(delay)
                continue
            else:
                _logger.error(
                    "Failed to export batch code: %s, reason: %s",
                    resp.status_code,
                    resp.text,
                )
                return SpanExportResult.FAILURE
        return SpanExportResult.FAILURE

    def export(self, spans) -> SpanExportResult:
        if not traceExporterController.is_open():
            _logger.warning("[trace_exporter] traceExporterController is not open")
            return SpanExportResult.FAILURE
        # After the call to Shutdown subsequent calls to Export are
        # not allowed and should return a Failure result.
        if self._shutdown:
            _logger.warning("Exporter already shutdown, ignoring batch")
            return SpanExportResult.FAILURE

        serialized_data = self._serialize_spans(spans)
        res = self._export_serialized_spans(serialized_data)
        spans = None
        del serialized_data
        return res

    def shutdown(self):
        if self._shutdown:
            _logger.warning("Exporter already shutdown, ignoring call")
            return
        self._session.close()
        self._shutdown = True

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Nothing is buffered in this exporter, so this method does nothing."""
        return True

def is_enable_multi_app() -> bool:
    env_key = convert_to_env_var(PROFILER_GENAI_SPLITAPP_KEY)
    return is_true_value(environ.get(env_key, "False"))

def _compression_from_env() -> Compression:
    compression = (
        environ.get(
            OTEL_EXPORTER_OTLP_TRACES_COMPRESSION,
            environ.get(OTEL_EXPORTER_OTLP_COMPRESSION, "none"),
        )
        .lower()
        .strip()
    )
    return Compression(compression)


def _append_trace_path(endpoint: str) -> str:
    if endpoint.endswith("/"):
        return endpoint + DEFAULT_TRACES_EXPORT_PATH
    return endpoint + f"/{DEFAULT_TRACES_EXPORT_PATH}"
