import queue
import threading
import requests

# metadata_exporter
class metadata_exporter:
    def __init__(self, endpoint_url, queue):
        self.endpoint_url = endpoint_url
        self.queue = queue
        self.running = True

        thread = threading.Thread(target=self.export_metadata)
        thread.daemon = True
        thread.start()

    def export_metadata(self):
        while self.running:
            metadata = self.queue.get()
            if metadata is None:
                break
            self.post_metadata(metadata)

    def post_metadata(self, metadata):
        try:
            response = requests.post(self.endpoint_url, json=metadata)
            response.raise_for_status()
        except requests.RequestException as e:
            print(f"Failed to export metadata: {e}")

    def stop(self):
        self.running = False
        self.queue.put(None)

