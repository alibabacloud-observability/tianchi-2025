from aliyun.sdk.extension.arms.utils import network_utils

collectorEndpointMap = {
    "cn-huhehaote": "dc-cn-huhehaote.arms.aliyuncs.com",
    "arms-dc-me-central-1": "arms-dc-me-central-1.aliyuncs.com",
    "cn-beijing": "arms-dc-bj.aliyuncs.com",
    "ap-southeast-1-oxs": "dc-ap-southeast-1-oxs-internal.arms.aliyuncs.com",
    "ap-southeast-2": "dc-ap-southeast-2.arms.aliyuncs.com",
    "cn-north-2-gov-1": "arms-dc-gov.aliyuncs.com",
    "cn-qingdao": "arms-dc-qd.aliyuncs.com",
    "cn-wulanchabu": "dc-cn-wulanchabu.arms.aliyuncs.com",
    "cn-zhangjiakou-oxs": "arms-zb-oxs.aliyuncs.com",
    "eu-west-1": "dc-eu-west-1.arms.aliyuncs.com",
    "cn-hangzhou": "arms-dc-hz.aliyuncs.com",
    "ap-southeast-5": "arms-dc-indonesia.aliyuncs.com",
    "ap-northeast-1-oxs": "dc-ap-northeast-1-oxs-internal.arms.aliyuncs.com",
    "cn-hangzhou-finance": "arms-dc-hz-finance.aliyuncs.com",
    "cn-shenzhen-finance-1": "arms-dc-sz-finance.aliyuncs.com",
    "cn-shanghai-finance-1": "arms-dc-sh-finance.aliyuncs.com",
    "eu-central-1": "arms-dc-frankfurt.aliyuncs.com",
    "cn-shanghai": "arms-dc-sh.aliyuncs.com",
    "cn-chengdu": "dc-cn-chengdu.arms.aliyuncs.com",
    "ap-southeast-3": "dc-ap-southeast-3.arms.aliyuncs.com",
    "ap-northeast-1": "arms-dc-jp.aliyuncs.com",
    "us-west-1": "arms-dc-usw.aliyuncs.com",
    "cn-shenzhen": "arms-dc-sz.aliyuncs.com",
    "cn-hongkong": "arms-dc-hk.aliyuncs.com",
    "ap-southeast-6": "arms-dc-ap-southeast-6.aliyuncs.com",
    "dc-me-east-1": "dc-me-east-1.arms.aliyuncs.com",
    "ap-southeast-1": "arms-dc-sg.aliyuncs.com",
    "cn-guangzhou": "dc-cn-guangzhou.arms.aliyuncs.com",
    "cn-zhangjiakou": "arms-dc-zb.aliyuncs.com",
    "us-east-1": "dc-us-east-1.arms.aliyuncs.com",
    "cn-hangzhou": "arms-dc-hz.aliyuncs.com",
    "cn-heyuan": "dc-cn-heyuan.arms.aliyuncs.com",
    "us-east-1-oxs": "dc-us-east-1-oxs-internal.arms.aliyuncs.com",
    "eu-central-1-oxs": "dc-eu-central-1-oxs-internal.arms.aliyuncs.com",
    "ap-south-1": "dc-ap-south-1.arms.aliyuncs.com",
}


def GetTraceMetaEndpointByRegion(regionId):
    if regionId not in collectorEndpointMap:
        return "arms-dc-zb.aliyuncs.com:9990"
    else:
        url = collectorEndpointMap[regionId]
        return url + ":9990"


def _get_internal_endpoint(url):
    if not url:
        return url
    url_sp = url.split(".")
    if len(url_sp) == 0:
        return url
    if "internal" in url_sp[0]:
        return url
    return url_sp[0] + "-internal" + url[len(url_sp[0]):]


def GetTraceEndpointByRegion(regionId):
    if regionId not in collectorEndpointMap:
        return "arms-dc-zb.aliyuncs.com"
    else:
        return collectorEndpointMap[regionId]


def GetMetricsEndpointByRegion(regionId):
    uri = regionId
    return f"{uri}.arms.aliyuncs.com"


def GetSLSEndpointByRegion(regionId):
    return f"{regionId}-intranet.log.aliyuncs.com"
