"""
Heartbeat will be triggered at scheduled intervals.
"""

import threading
from time import time_ns


class Heartbeat(object):

    def __init__(self, call, intervals=60, name="Heartbeat"):
        self.intervals = intervals
        if call is None:
            raise ValueError("call func cannot be None")
        self.condition = threading.Condition(threading.Lock())
        self.worker_thread = threading.Thread(
            name=name, target=self.worker, daemon=True
        )
        self.call = call
        self.is_running = False
        self.done = False

    def worker(self):
        """
        heartbeat worker
        """
        timeout = self.intervals
        while not self.done:
            with self.condition:
                if self.done:
                    # done flag may have changed, avoid waiting
                    break
                self.condition.wait(timeout)
            # subtract the duration of this export call to the next timeout
            start = time_ns()
            self.call()
            end = time_ns()
            duration = (end - start) / 1e9
            timeout = self.intervals - duration

    def close(self):
        """
        close heartbeat
        """
        self.done = True

    def run(self):
        """
        start heartbeat
        """
        if not self.is_running:
            self.worker_thread.start()
            self.is_running = True
