import chardet
import codecs
import hashlib


def utf8_to_gbk(data):
    # 检测字节序列的编码
    encoding = chardet.detect(data)['encoding']

    # 确保字节序列是UTF-8编码的
    if encoding != 'utf-8':
        return None, ValueError('Input data is not utf-8 encoded')

    try:
        # 将字节序列解码为unicode字符串，然后重新编码为GBK
        # 注意：GBK可能与CP936(在Windows系统中GBK的别名)有微妙的区别，但通常是相似的
        # 如果在Windows系统上运行，可以考虑使用"gbk"替换"GB18030"
        encoded_data = data.decode('utf-8').encode('GB18030')
    except UnicodeError as e:
        # 如果转换过程中出现错误，返回错误信息
        return None, e

    return encoded_data, None


def generate_md5_hash(text):
    # 这里假设前面已经定义了 utf8_to_gbk 函数
    gbk_text, err = utf8_to_gbk(text.encode('utf-8'))
    if err:
        return ""

    # 计算GBK编码文本的MD5散列值
    m = hashlib.md5()
    m.update(gbk_text)
    return m.hexdigest()


def generate_md5_hash(text):
    try:
        # 假定 text 已正确转码为GBK
        gbk_text = text.encode('gbk')
    except UnicodeEncodeError:
        return ""

    # 计算GBK编码文本的MD5散列值
    m = hashlib.md5()
    m.update(gbk_text)
    return m.hexdigest()


def decode_user_id(uid):
    try:
        # 解析base-36编码的字符串为整数
        num = int(uid, 36)
    except ValueError as e:
        # 如果无法解析，返回错误
        return "", e

    # 将整数格式化为base-10的字符串并返回
    return str(num), None


def base36encode(number, alphabet='0123456789abcdefghijklmnopqrstuvwxyz'):
    """Converts an integer to a base36 string."""
    if not isinstance(number, int):
        raise TypeError('number must be an integer')

    base36 = ''
    sign = ''

    if number < 0:
        sign = '-'
        number = -number

    if 0 <= number < len(alphabet):
        return sign + alphabet[number]

    while number != 0:
        number, i = divmod(number, len(alphabet))
        base36 = alphabet[i] + base36

    return sign + base36


def get_user_id(license_key):
    if license_key:
        at_index = license_key.find('@')
        if at_index != -1:
            encoded_user_id = license_key[:at_index]
            user_id, err = decode_user_id(encoded_user_id)
            if err is None:
                return user_id
            else:
                pass
    return ""


def generate_app_id(user_id, app_name):
    if not user_id or not app_name:
        return ""

    # 将用户ID从字符串转换为整数
    try:
        user_id_36 = int(user_id)
    except ValueError:
        return ""

    # 生成MD5散列值
    md5_hash = generate_md5_hash(app_name + "token")
    length = 15
    if len(md5_hash) < length:
        length = len(md5_hash)

    # 获取MD5散列值的前15个字符，如果它们的长度足够的话
    md5_hash = md5_hash[:length]

    # 将用户ID转换为base-36并于MD5散列值连接
    result = base36encode(user_id_36) + "@" + md5_hash
    return result


# 检查网络是否通
def check_network(url):
    import requests
    try:
        response = requests.request("GET", url, timeout=1)
        if response.status_code == 200:
            return True
    except Exception as e:
        return False
    return False


def get_default_workspace(user_id, region_id):
    return "default-cms-" + user_id + "-" + region_id


def get_service_id(workspace, user_id, region_id, pid):
    if not user_id or not pid:
        return ""
    site_name_code = generate_md5_hash(pid + workspace + "TRACE" + region_id + "token")
    if len(site_name_code) > 21:
        site_name_code = site_name_code[:21]
    try:
        user_id_36 = int(user_id)
    except ValueError:
        return ""
    return base36encode(user_id_36) + "@" + site_name_code


def is_default_cms_workspace(user_id, region_id, cms_workspace):
    if not user_id or not region_id or not cms_workspace:
        return True
    return cms_workspace == get_default_workspace(user_id, region_id)


# xtrace服务端创建project时用的md5算法非标，需要对齐
def get_md5_string_for_xtrace_project(origin):
    buf = origin.encode()
    md5 = hashlib.md5()
    md5.update(buf)
    abstract = md5.digest()
    return ''.join(f"{(b & 0xff):x}" for b in abstract)
