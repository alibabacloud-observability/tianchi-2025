def get_llm_common_attributes() -> dict:
    return {"callType": "gen_ai",
            "callKind": "custom_entry",
            "rpcType": 2100}

