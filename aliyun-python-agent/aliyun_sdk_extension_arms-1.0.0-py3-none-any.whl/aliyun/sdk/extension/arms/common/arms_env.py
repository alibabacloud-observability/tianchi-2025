import os
from os import getenv
from uuid import uuid4

from aliyun.sdk.extension.arms.common.endpoints import (GetTraceEndpointByRegion, GetTraceMetaEndpointByRegion,
                                                        GetMetricsEndpointByRegion, GetSLSEndpointByRegion)
from aliyun.sdk.extension.arms.common.utils import arms_utils as MetadataUtils
from aliyun.sdk.extension.arms.common.utils.arms_utils import is_default_cms_workspace
from aliyun.sdk.extension.arms.utils.env_utils import get_hostname, get_ip_address

from aliyun.opentelemetry.instrumentation.utils import is_uwsgi, is_gunicorn, is_uvicorn


class ArmsEnv(object):
    def __init__(self):
        # environments
        self.licenseKey = os.getenv("ARMS_LICENSE_KEY", "")
        self.appName = os.getenv("ARMS_APP_NAME", "")
        self.appId = os.getenv("ARMS_APP_ID", "")
        user_id = MetadataUtils.get_user_id(self.licenseKey)
        self.user_id = user_id
        if self.appName and len(self.appName) > 0:
            self.agentId = MetadataUtils.generate_app_id(user_id, self.appName)
            self.appId = self.agentId
        self.agentId = self.appId
        hostname = get_hostname()
        self.hostname = os.getenv("HOSTNAME", hostname)
        self.clusterId = os.getenv("ARMS_CLUSTER_ID", "")
        self.clusterName = os.getenv("ARMS_CLUSTER_NAME", "")
        self.workloadKind = os.getenv("ARMS_WORKLOAD_KIND", "")
        self.workloadName = os.getenv("ARMS_WORKLOAD_NAME", "")
        self.namespace = os.getenv("ARMS_NAMESPACE", "")
        self.agentEnv = os.getenv("ARMS_AGENT_ENV", "DEFAULT")
        self.uuid = uuid4()
        self.regionId = os.getenv("ARMS_REGION_ID", "cn-zhangjiakou")
        self.sls_project_name = f"end-side-logs-{self.regionId}"
        self.log_store_name = "python-agent-log"

        # params
        self.timeoutSec = int(os.getenv("DEFAULT_HTTPTIMEOUT_KEY", 30))
        self.initialIntervalSec = int(os.getenv("DEFAULT_INITIAL_INTERVAL_KEY", 5))
        self.maxIntervalSec = int(os.getenv("DEFAULT_MAX_INTERVAL_KEY", 30))
        self.maxElapsedTimeSec = int(os.getenv("DEFAULT_MAX_ELASPED_TIME_KEY", 60))
        self.maxQueueSize = int(os.getenv("ARMS_MAX_QUEUE_SIZE_KEY", 256))
        self.maxExporterBatchSize = int(os.getenv("ARMS_MAX_EXPORTER_BATCH_SIZE_KEY", 1024))
        self.maxExporterTimeoutSec = int(os.getenv("ARMS_MAX_EXPORTER_TIMEOUT_KEY", 15))
        # endpoints
        self.traceGatewayEndpoint = GetTraceEndpointByRegion(self.regionId)
        self.metaGatewayEndpoint = GetTraceMetaEndpointByRegion(self.regionId)
        self.metricsGatewayEndpoint = GetMetricsEndpointByRegion(self.regionId)
        self.slsUri = f'/logstores/{self.log_store_name}'
        # auto detect here
        self.slsHost = self.sls_project_name + "." + GetSLSEndpointByRegion(self.regionId)
        self.slsEndpoint = "https://" + self.slsHost + self.slsUri
        # metadata send config
        self.sendMaxSize = int(os.getenv("DEFAULT_SEND_MAX_SIZE_KEY", 512))
        self.sendTimeInterval = int(os.getenv("DEFAULT_SEND_TIME_INTERVAL_KEY", 15))
        self.ringBufferSize = int(os.getenv("DEFAULT_RING_BUFFER_SIZE_KEY", 1024))
        self.hostTags = os.getenv("ARMS_HOST_TAGS", "")
        # 在常见的多进程场景下，上报的agent info需要区分进程ID
        # 目前常用的python多进程服务器包括uwsgi/gunicorn/uvicorn
        if is_uwsgi() or is_gunicorn() or is_uvicorn():
            self.ip = f'{get_ip_address()}-{os.getpid()}'
        else:
            self.ip = get_ip_address()

        # 云监控2.0 workspace相关字段
        self.workspace = os.getenv("ARMS_WORKSPACE", None)
        if not self.workspace or len(self.workspace) == 0:
            self.workspace = MetadataUtils.get_default_workspace(self.user_id, self.regionId)
        self.service_id = MetadataUtils.get_service_id(self.workspace, self.user_id, self.regionId, self.appId)
        if not is_default_cms_workspace(self.user_id, self.regionId, self.workspace):
            self.appId = self.service_id
            self.agentId = self.service_id


    def getTraceEndpoint(self):
        return self.traceGatewayEndpoint

    def getMetaEndpoint(self):
        return self.metaGatewayEndpoint

    def getSlsEndpoint(self):
        return self.slsEndpoint

    def getAppId(self):
        return self.appId

    def getMetricsEndpoint(self):
        return self.metricsGatewayEndpoint

    @classmethod
    def instance(cls):
        if not hasattr(ArmsEnv, "_instance"):
            ArmsEnv._instance = ArmsEnv()
        return ArmsEnv._instance
