import enum

from .converger.type import ValueType

mapping = {}


class TargetType(enum.Enum):
    prpc = 0
    url = 1
    method = 2
    other_rpc = 3
    exception = 4
    unknown_rpc = 5
    external_url = 6
    external_address = 7
    raw_sql = 8

    raw_slow_sql = 9
    raw_no_sql = 10
    raw_slow_nosql = 11
    sql = 12
    slow_sql = 13
    slow_nosql = 14
    nosql = 15

    dest_id = 16
    endpoint = 17

    def value_type(self) -> ValueType:
        global mapping
        return mapping.get(self, ValueType.other)


def get_value_type_mapping():
    global mapping
    mapping = {
        TargetType.prpc: ValueType.url,
        TargetType.url: ValueType.url,
        TargetType.method: ValueType.method,
        TargetType.other_rpc: ValueType.other,
        TargetType.exception: ValueType.other,
        TargetType.unknown_rpc: ValueType.other,
        TargetType.external_url: ValueType.url,
        TargetType.external_address: ValueType.ip_or_domain,

        TargetType.raw_sql: ValueType.raw_sql,
        TargetType.raw_slow_sql: ValueType.raw_sql,
        TargetType.raw_no_sql: ValueType.raw_sql,
        TargetType.raw_slow_nosql: ValueType.raw_sql,

        TargetType.sql: ValueType.sql,
        TargetType.slow_sql: ValueType.sql,
        TargetType.slow_nosql: ValueType.sql,
        TargetType.nosql: ValueType.sql,

        TargetType.dest_id: ValueType.other,
        TargetType.endpoint: ValueType.ip_or_domain,
    }


get_value_type_mapping()
