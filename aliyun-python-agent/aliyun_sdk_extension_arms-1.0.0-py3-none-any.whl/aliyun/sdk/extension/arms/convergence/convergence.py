from .converger.app_converger import AppConverger
from .type import TargetType
import threading

def GenerateConvergenceKey(origin_key) -> str:
    return origin_key + '.convergence'

class OtAppConverger:

    _instance_lock = threading.Lock()
    def __init__(self):
        self.converger = AppConverger()

    def __new__(cls, *args, **kwargs):
        if not hasattr(OtAppConverger, "_instance"):
            with OtAppConverger._instance_lock:
                if not hasattr(OtAppConverger, "_instance"):
                    OtAppConverger._instance = object.__new__(cls)
        return OtAppConverger._instance

    def converge(self, target_key: TargetType, value: str) -> str:
        return self.converger.converge(target_key.name, target_key.value_type(), value)

    def converge_dynamic(self, target_key: str, value: str) -> str:
        raise NotImplemented("converge dynamic requires server configuration, which is not implemented yet")
        # if not target_key.startswith("dyn_"):
        #     target_key = "dyn_" + target_key
        # return self.converger.converge(target_key, value)
