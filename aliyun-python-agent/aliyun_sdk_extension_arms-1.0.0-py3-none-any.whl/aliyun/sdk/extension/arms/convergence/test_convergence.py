from .converger import constant

constant.DEFAULT_LIMIT = 10
constant.DEFAULT_WND = 5

import time
import unittest
from .convergence import OtAppConverger
from .type import TargetType
from .converger.constant import ARMS_OTHERS


class TestOtAppConverger(unittest.TestCase):
    def test_memory_window_limit_converger(self):
        converger = OtAppConverger()
        url = "https://taobao.com/?item="
        for i in range(0, 10):
            curl = url + str(i)
            self.assert_not_converge(converger, TargetType.url, curl)

        for i in range(10, 20):
            curl = url + str(i)
            self.assert_not_converge(converger, TargetType.url, curl)

        for i in range(0, 10):
            curl = url + str(i)
            self.assert_not_converge(converger, TargetType.url, curl)

        time.sleep(8)
        for i in range(10, 20):
            curl = url + str(i)
            self.assert_not_converge(converger, TargetType.url, curl)

    def assert_not_converge(self, c: OtAppConverger, target_type: TargetType, val: str):
        result = c.converge(target_type, val)
        self.assertEqual(result, val)

    def assert_converge(self, c: OtAppConverger, target_type: TargetType, val: str):
        result = c.converge(target_type, val)
        self.assertEqual(result, ARMS_OTHERS)


if __name__ == '__main__':
    unittest.main()
