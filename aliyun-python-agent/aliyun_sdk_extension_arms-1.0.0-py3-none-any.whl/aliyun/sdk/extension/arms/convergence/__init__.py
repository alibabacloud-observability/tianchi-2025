from .convergence import OtAppConverger
from .type import TargetType
from .convergence import GenerateConvergenceKey
import os
from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)

__all__ = ['OtAppConverger', 'TargetType', 'GenerateConvergenceKey']

_ot_app_converger = OtAppConverger()


def converge(target_key: TargetType, value: str):
    if _is_enable():
        return _ot_app_converger.converge(target_key, value)
    else:
        return value

_enable_flag= None
def _is_enable():
    global _enable_flag
    if _enable_flag is not None:
        return _enable_flag
    flag = os.getenv("ENABLE_CONVERGENCE", "true")
    if flag == "false":
        _logger.info(f"close convergence flag")
        _enable_flag = False
        return False
    _enable_flag = True
    return True
