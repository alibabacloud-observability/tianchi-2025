import os
import threading
import time
from .config import BaseWindowLimitConfig
from .converger import Converger
from .result import Result
from .type import ConvergerType
from aliyun.sdk.extension.arms.logger import getLogger
_logger = getLogger(__name__)


class WindowConverger(Converger):
    def __init__(self, backend: ConvergerType, converger_type: ConvergerType, config: BaseWindowLimitConfig):
        _logger.info(f"[WindowConverger]==> {config.wnd}")
        self.limit = config.limit
        if config.wnd == 0:
            self.wnd = 3600
        else:
            self.wnd = config.wnd

        self.backend = backend
        self.config = config
        self.type = converger_type
        if self.wnd > 0:
            self.add_schedule_job()
        self.converger = self.new_instance()

    def new_instance(self):
        from .factory import new_converger
        nc = new_converger(self.backend, self.config.get_non_window_config())
        return nc

    def converge(self, value) -> Result:
        return self.converger.converge(value)

    def scheduleJob(self):
        _logger.warning(f"[scheduleJob] start ==> {os.getpid()} ：get_ident： {threading.get_ident()}")
        while True:
            time.sleep(self.wnd)
            self.converger = self.new_instance()
        _logger.warning(f"[scheduleJob] end ==> {os.getpid()} ：get_ident： {threading.get_ident()}")

    def add_schedule_job(self):
        _logger.warning(f"[add_schedule_job]  ==>")
        thread = threading.Thread(target=self.scheduleJob)
        thread.daemon = True
        thread.start()
