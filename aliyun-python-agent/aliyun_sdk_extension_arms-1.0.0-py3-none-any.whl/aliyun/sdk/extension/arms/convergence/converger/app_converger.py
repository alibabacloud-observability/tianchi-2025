from aliyun.sdk.extension.arms.logger import getLogger

from .type import ValueType
from .default import defaultAppConfigTemplate
from .config import create_target_config, TargetConfig
from .constant import INTERNAL_DEFAULT
from .convergers import Convergers
from .result import Result

_logger = getLogger(__name__)


class AppConverger:
    def __init__(self):
        self.cache = {}

    def build_convergers(self, value_type: ValueType, target_config: TargetConfig) -> Convergers:
        convergers = Convergers(value_type, target_config.lmt_cfg, target_config)
        return convergers

    def get_target_config(self, target_key: str, value_type: ValueType) -> TargetConfig:
        template = defaultAppConfigTemplate.get_target_config_or_default(target_key)
        if template is None:
            assert False
        return create_target_config(template, INTERNAL_DEFAULT, False, value_type)

    def get_convergers(self, target_key: str, value_type: ValueType) -> Convergers:
        cs = self.cache.get(target_key)
        if cs is not None:
            return cs
        target_config = self.get_target_config(target_key, value_type)
        cs = self.build_convergers(value_type, target_config)

        cs = self.cache.setdefault(target_key, cs)
        return cs

    def converge(self, target_key: str, value_type: ValueType, val: str) -> str:
        result = Result(False, val)
        convergers = self.get_convergers(target_key, value_type)
        if convergers is None:
            _logger.warning("convergers is None")
            return result.value

        target_config = convergers.target_config
        if target_config is None:
            _logger.warning("target_config is None")
            return result.value
        if not target_config.enable:
            return result.value
        if target_config.converge:
            before = convergers.before
            for c in before:
                result = c.converge(result.value)
                if result.converged:
                    return result.value

        # 进行样本采集，未实现

        if target_config.converge and target_config.over:
            after = convergers.after
            for c in after:
                result = c.converge(result.value)
                if result.converged:
                    return result.value

        if target_config.converge:
            c = convergers.ultimate_limit_converger
            if c is not None:
                result = c.converge(result.value)
            else:
                _logger.warning("suspicious configuration: ultimate Limit converger does not work")

        return result.value
