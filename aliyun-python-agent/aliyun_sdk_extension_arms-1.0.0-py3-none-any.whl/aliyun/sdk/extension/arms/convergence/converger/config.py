from abc import abstractmethod
from typing import Dict, Optional

from .type import ConvergerType
from .type import ValueType
from .constant import DEFAULT_KEY


class ConvergerConfig:
    @abstractmethod
    def type(self):
        pass

    @abstractmethod
    def enabled(self):
        pass


class AbstractConvergerConfig(ConvergerConfig):
    def __init__(self, type: ConvergerType, enable: bool, stop_wh_exclude_ret: bool, excludes: list,
                 exclude_regex: list):
        self.type = type
        self.enable = enable
        self.stop_wh_exclude_ret = stop_wh_exclude_ret
        self.excludes = excludes
        self.exclude_regex = exclude_regex

    def enabled(self):
        return self.enable

    def type(self):
        return self.type

    def set_enabled(self, status: bool):
        self.enable = status


class BaseLimitConfig(AbstractConvergerConfig):
    def __init__(self, type: ConvergerType, enable: bool, stop_wh_exclude_ret: bool, excludes: list,
                 exclude_regex: list, limit: int):
        super().__init__(type, enable, stop_wh_exclude_ret, excludes, exclude_regex)
        self.limit = limit


class BaseWindowLimitConfig(BaseLimitConfig):
    def __init__(self, type: ConvergerType, enable: bool, stop_wh_exclude_ret: bool, excludes: list,
                 exclude_regex: list, limit: int, wnd: int):
        super().__init__(type, enable, stop_wh_exclude_ret, excludes, exclude_regex, limit)
        self.wnd = wnd

    @abstractmethod
    def get_non_window_config(self) -> BaseLimitConfig:
        pass


class MemoryLimitConfig(BaseLimitConfig):
    def __init__(self, enable: bool, stop_wh_exclude_ret: bool, excludes: list,
                 exclude_regex: list, limit: int):
        super().__init__(ConvergerType.m_lmt, enable, stop_wh_exclude_ret, excludes, exclude_regex, limit)


class MemoryWindowLimitConfig(BaseWindowLimitConfig):
    def __init__(self, enable: bool, stop_wh_exclude_ret: bool, excludes: list,
                 exclude_regex: list, limit: int, wnd: int):
        super().__init__(ConvergerType.w_l_lmt, enable, stop_wh_exclude_ret, excludes, exclude_regex, limit, wnd)

    def get_non_window_config(self) -> MemoryLimitConfig:
        return MemoryLimitConfig(self.enable, self.stop_wh_exclude_ret, self.excludes, self.exclude_regex,
                                 self.limit)


# App Converger Config

class BaseTargetConfig:
    def __init__(self, type: str, enable: bool, converge: bool, excludes: list, before: dict, after: dict,
                 lmt_cfg: BaseLimitConfig, mon_raw: bool, mon_rs: bool):
        self.type = type
        self.enable = enable
        self.converge = converge
        self.excludes = excludes
        self.before = before
        self.after = after
        self.lmt_cfg = lmt_cfg
        self.mon_raw = mon_raw
        self.mon_rs = mon_rs


class TargetConfig(BaseTargetConfig):
    def __init__(self, base: BaseTargetConfig, pri: int, over: bool):
        super().__init__(base.type, base.enable, base.converge, base.excludes, base.before, base.after, base.lmt_cfg,
                         base.mon_raw, base.mon_rs)

        self.pri = pri
        self.over = over


def create_target_config(base: BaseTargetConfig, pri: int, over: bool, value_type: ValueType) -> TargetConfig:
    tc = TargetConfig(base, pri, over)
    tc.type = str(value_type)
    return tc


class BaseAppConfig:
    def __init__(self, enable: bool, extra_labels: dict):
        self.enable = enable
        self.extra_labels = extra_labels


class AppConfigTemplate(BaseAppConfig):
    def __init__(self, enable: bool, extra_labels: dict, templates: Dict[str, BaseTargetConfig]):
        super().__init__(enable, extra_labels)
        # templates: map[string, BaseTargetConfig)
        self.templates = templates
        # glReplaceConfig

    def get_target_config(self, target_key: str) -> Optional[BaseTargetConfig]:
        return self.templates.get(target_key)

    def get_target_config_or_default(self, target_key: str) -> Optional[BaseTargetConfig]:
        template = self.templates.get(target_key)
        if template is None:
            template = self.templates.get(DEFAULT_KEY)
        return template


class AppConfig(BaseAppConfig):
    def __init__(self, enable: bool, extra_labels: dict, id: int, version: int, appid: int, configs: dict):
        super().__init__(enable, extra_labels)
        self.id = id
        self.version = version
        self.appid = appid
        self.configs = configs

    def get_target_config(self, target_key: str) -> TargetConfig:
        return self.configs[target_key]
