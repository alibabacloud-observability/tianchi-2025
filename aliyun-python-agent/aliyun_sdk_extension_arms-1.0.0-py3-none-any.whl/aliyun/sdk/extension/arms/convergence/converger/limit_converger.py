from .fixed_set import FixedSizeSet
from .result import Result
from .constant import *
from .config import MemoryLimitConfig
from .converger import Converger


class MemoryLimitConverger(Converger):
    def __init__(self, config: MemoryLimitConfig):
        self.config = config
        self.cache = FixedSizeSet(config.limit)
        self.limit = config.limit

    def converge(self, value):
        ok = self.cache.putIfAbsent(value)
        if ok:
            return Result(True, value)
        return Result(True, ARMS_OTHERS)
