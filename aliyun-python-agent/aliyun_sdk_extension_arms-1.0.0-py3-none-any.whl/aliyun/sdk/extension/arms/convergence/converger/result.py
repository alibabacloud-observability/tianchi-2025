class Result:
    def __init__(self, converged, value):
        self.converged = converged
        self.value = value

    def get_value(self):
        return self.value

    def get_converged(self):
        return self.converged
