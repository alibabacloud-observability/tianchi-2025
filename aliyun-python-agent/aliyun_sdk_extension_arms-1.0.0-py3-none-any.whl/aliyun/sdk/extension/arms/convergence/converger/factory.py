from aliyun.sdk.extension.arms.logger import getLogger

from .type import ConvergerType
from .limit_converger import MemoryLimitConverger
from .window_converger import WindowConverger

_logger = getLogger(__name__)


def new_converger(converger_type: ConvergerType, config: any):
    if converger_type == ConvergerType.m_lmt:
        return MemoryLimitConverger(config)
    if converger_type == ConvergerType.w_l_lmt:
        return WindowConverger(ConvergerType.m_lmt, converger_type, config)
    _logger.error("Unsupported Converger Type")
