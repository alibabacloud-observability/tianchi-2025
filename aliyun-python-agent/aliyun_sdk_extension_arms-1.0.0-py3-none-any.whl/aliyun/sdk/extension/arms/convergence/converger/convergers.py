from typing import List, Dict
from .converger import Converger
from .config import TargetConfig, ConvergerConfig, BaseLimitConfig
from .factory import new_converger

from .type import ValueType, ConvergerType

DefaultConvergers: Dict[ConvergerType, ConvergerConfig]


def init_default_converger():
    global DefaultConvergers
    # url, sql, text的默认配置，暂未实现
    DefaultConvergers = {}


init_default_converger()


class Convergers:

    def __init__(self, value_type: ValueType,
                 limit_config: BaseLimitConfig, target_config: TargetConfig):
        self.value_type = value_type
        self.target_config = target_config
        # 添加默认converger，如果该收敛器支持我们期望的Value_type，将其加入到before中
        global DefaultConvergers
        for key, val in DefaultConvergers.items():
            pass
        self.before = self.build_convergers(target_config.before)
        self.after = self.build_convergers(target_config.after)
        if limit_config is not None:
            self.ultimate_limit_converger = new_converger(limit_config.type, limit_config)

    def build_convergers(self, config: Dict[str, ConvergerConfig]) -> List[Converger]:
        result = list()
        if config is None:
            return result
        for key, val in config.items():
            target_type = ConvergerType[key]
            if target_type == ConvergerType.noop:
                continue
            nc = new_converger(target_type, val)
            if nc is not None:
                result.append(new_converger(target_type, val))
        return result
