import abc
from .result import Result


class Converger:
    @abc.abstractmethod
    def converge(self, key: str) -> Result:
        pass
