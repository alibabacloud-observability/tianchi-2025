from .config import BaseTargetConfig, MemoryWindowLimitConfig, AppConfigTemplate
from .constant import DEFAULT_KEY, DEFAULT_LIMIT, DEFAULT_WND

defaultAppConfigTemplate: AppConfigTemplate


def new_default_base_target_config():
    c = BaseTargetConfig("", True, True, list(), {}, {}, None, False, True)
    return c


def new_default_memory_window_limit_config():
    c = MemoryWindowLimitConfig(True, True, list(), list(), DEFAULT_LIMIT, DEFAULT_WND)
    return c


def init_default_app_config_template():
    base_target_config = new_default_base_target_config()
    base_target_config.lmt_cfg = new_default_memory_window_limit_config()
    template_map = {
        DEFAULT_KEY: base_target_config,
    }
    global defaultAppConfigTemplate
    defaultAppConfigTemplate = AppConfigTemplate(True, {}, template_map)


init_default_app_config_template()
