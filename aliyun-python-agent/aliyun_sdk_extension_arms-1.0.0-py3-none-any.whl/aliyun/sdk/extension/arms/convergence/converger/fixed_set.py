

class FixedSizeSet:
    def __init__(self, capacity):
        self.capacity = capacity
        self.elements = set()

    def putIfAbsent(self, element):
        if element in self.elements:
            return True

        if len(self.elements) >= self.capacity:
            return False

        self.elements.add(element)
        return True

    def dump(self):
        return set(self.elements)

    def __contains__(self, element):
        return element in self.elements

    def __len__(self):
        return len(self.elements)

    def __str__(self):
        return str(self.elements)
