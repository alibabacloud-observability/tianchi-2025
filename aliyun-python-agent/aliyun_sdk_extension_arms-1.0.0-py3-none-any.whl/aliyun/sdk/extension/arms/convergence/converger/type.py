from enum import Enum


class ConvergerType(Enum):
    text = 0
    s_limit = 1
    b_lmt = 2
    m_lmt = 3
    w_b_lmt = 4
    w_l_lmt = 5
    replace = 6
    sql_fmt = 7
    exp_fmt = 8
    url_fmt = 9
    noop = 10
    all = 11


class ValueType(Enum):
    method = 0
    url = 1
    sql = 2
    raw_sql = 3
    excep = 4
    ip_or_domain = 5
    other = 6
    text = 7
    all = 8
    unknown = 9

    def __str__(self):
        if self.value == self.raw_sql:
            return "raw-sql"
        if self.value == self.ip_or_domain:
            return "ip"
        return self.name

    @staticmethod
    def from_code(self, item: str):
        if item == "raw-sql":
            return self.raw_sql
        if item == "ip":
            return self.ip_or_domain
        return ValueType[item]
