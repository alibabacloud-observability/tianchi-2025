import unittest

from .agent_info_provider import AgentInfoProvider

class TestAgentInfoProvider(unittest.TestCase):
    def test_init(self):

        aip = AgentInfoProvider.get_instance()
        aip.init_agent_info()
        print(aip.agent_info_.hostname)
        print(aip.agent_info_.ip)
        self.assertEqual(aip.inited_, True)  # add assertion here


if __name__ == '__main__':
    unittest.main()
