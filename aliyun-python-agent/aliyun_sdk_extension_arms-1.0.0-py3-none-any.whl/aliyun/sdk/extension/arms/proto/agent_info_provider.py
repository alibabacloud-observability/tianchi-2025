import os
import socket
import time

from .agent_info_pb2 import AgentInfo
import threading

class AgentInfoProvider:
    def __init__(self):
        self.agent_info_ = AgentInfo()
        self.inited_ = False

    def init_agent_info(self):
        if not self.inited_:
            self.agent_info_.hostname = socket.gethostname()
            self.agent_info_.ip = self.__get_host_ip()
            # TODO @qianlu.kk use git short commit
            self.agent_info_.agentVersion = "0.0.1"
            self.agent_info_.pid = os.getpid()
            self.agent_info_.startTimestamp = int(time.time_ns() / 1e6)
            self.agent_info_.agentId = ""
            self.agent_info_.agentEnv = ""
            self.agent_info_.agentArgs = ""
            # self.agent_info_.agentTags = ""
            self.agent_info_.appName = ""
            # xxxxx
            self.inited_ = True

    # FIXME @qianlu.kk have some problems
    def __get_host_ip(self):
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            return local_ip
        except socket.gaierror as e:
            # TODO @qianlu.kk use log lib
            # print("Error occurred while getting the local IPv4 address: ", e)
            return 'Unknown'

    @classmethod
    def get_instance(cls):
        if not hasattr(AgentInfoProvider, '_instance'):
            AgentInfoProvider._instance = AgentInfoProvider()
        return AgentInfoProvider._instance
