# 埋点前后的装饰器，帮助统计instrumenter的执行结果以及执行的耗时等数据
from aliyun.sdk.extension.arms.self_monitor.self_monitor import _self_monitor_metrics
import time

# 同步装饰器，用来装饰python中的同步函数，用来统计埋点关键方法的执行次数，异常次数等关键指标
# 1. instrumentation_name：插件名称
# 2. advice_method：埋点方法名称
# 3. throw_exception：是否捕获埋点异常，在某些埋点中异常是需要抛出去的，这里默认值为False，默认场景捕获埋点中可能发生的异常避免影响业务
def hook_advice(instrumentation_name="unknown", advice_method="unknown", throw_exception=False):
    def decorator(func):
        def wrapper(*args, **kwargs):
            start_time = time.time() * 1000
            result = None
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                end_time = time.time() * 1000
                _self_monitor_metrics.record_advice_threw_exception(
                    end_time - start_time,
                    {
                        "exception_info": str(e),
                        "advice_method": advice_method,
                        "instrumentation_name": instrumentation_name
                    },
                )
                if throw_exception:
                    raise e
            end_time = time.time() * 1000
            if _self_monitor_metrics:
                _self_monitor_metrics.record_advice_execution(
                    end_time - start_time,
                    {
                        "advice_method": advice_method,
                        "instrumentation_name": instrumentation_name
                    },
                )
            return result

        wrapper.__wrapped__ = func
        return wrapper

    return decorator


# 异步装饰器，用来装饰python中的异步函数(async) 用来统计埋点关键方法的执行次数，异常次数等关键指标
# 1. instrumentation_name：插件名称
# 2. advice_method：埋点方法名称
# 3. throw_exception：是否捕获埋点异常，在某些埋点中异常是需要抛出去的，这里默认值为False，默认场景捕获埋点中可能发生的异常避免影响业务
def async_hook_advice(instrumentation_name="unknown", advice_method="unknown", throw_exception=False):
    def decorator(func):
        async def wrapper(*args, **kwargs):
            start_time = time.time() * 1000
            result = None
            try:
                result = await func(*args, **kwargs)
            except Exception as e:
                end_time = time.time() * 1000
                _self_monitor_metrics.record_advice_threw_exception(
                    end_time - start_time,
                    {
                        "exception_info": str(e),
                        "advice_method": advice_method,
                        "instrumentation_name": instrumentation_name
                    },
                )
                if throw_exception:
                    raise e
            end_time = time.time() * 1000
            if _self_monitor_metrics:
                _self_monitor_metrics.record_advice_execution(
                    end_time - start_time,
                    {
                        "advice_method": advice_method,
                        "instrumentation_name": instrumentation_name
                    },
                )
            return result

        wrapper.__wrapped__ = func
        return wrapper

    return decorator
