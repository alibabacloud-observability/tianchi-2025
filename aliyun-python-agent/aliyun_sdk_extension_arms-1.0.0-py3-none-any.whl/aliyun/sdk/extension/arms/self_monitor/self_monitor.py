import os
import time

from opentelemetry.metrics import get_meter

from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.self_monitor import (SELF_MONITOR_AGENT_SPAN_REPORT_RESULT,
                                                    SELF_MONITOR_AGENT_SPAN_REPORT_BYTES,
                                                    SELF_MONITOR_AGENT_METRIC_REPORT_RESULT,
                                                    SELF_MONITOR_AGENT_METRIC_REPORT_BYTES,
                                                    SELF_MONITOR_AGENT_META_REPORT_RESULT,
                                                    SELF_MONITOR_AGENT_META_REPORT_BYTES,
                                                    SELF_MONITOR_AGENT_ADVICE_EXECUTION_COUNT,
                                                    SELF_MONITOR_ADVICE_THREW_EXCEPTION_COUNT)
from aliyun.sdk.extension.arms.semconv.metrics import MetricUnit
from aliyun.opentelemetry.instrumentation.version import __version__

SELF_MONITOR_SAMPLE_RATE = int(os.getenv("PROFILER_SELFMONITOR_SAMPLE_RATE", "1000"))

_logger = getLogger(__name__)

class ArmsSelfMonitor:
    def init_self_monitor_metrics(self):
        if not self._enable:
            return
        try:
            self._meter = get_meter(
                __name__,
                __version__,
                schema_url="https://opentelemetry.io/schemas/1.11.0",
            )
            # span上报状态
            self._agent_span_report_result = self._meter.create_counter(
                name=SELF_MONITOR_AGENT_SPAN_REPORT_RESULT,
                unit=MetricUnit.COUNT,
                description="Span report self monitor")
            # span上报字节数
            self._agent_span_report_bytes = self._meter.create_counter(
                name=SELF_MONITOR_AGENT_SPAN_REPORT_BYTES,
                unit=MetricUnit.COUNT,
                description="Span report self monitor bytes")
            # metric上报状态
            self._agent_metric_report_result = self._meter.create_counter(
                name=SELF_MONITOR_AGENT_METRIC_REPORT_RESULT,
                unit=MetricUnit.COUNT,
                description="Metric report self monitor")
            # metric上报字节数
            self._agent_metric_report_bytes = self._meter.create_counter(
                name=SELF_MONITOR_AGENT_METRIC_REPORT_BYTES,
                unit=MetricUnit.COUNT,
                description="Metric report self monitor bytes")
            # meta上报状态
            self._agent_meta_report_result = self._meter.create_counter(
                name=SELF_MONITOR_AGENT_META_REPORT_RESULT,
                unit=MetricUnit.COUNT,
                description="Meta report self monitor")
            # meta上报字节数
            self._agent_meta_report_bytes = self._meter.create_counter(
                name=SELF_MONITOR_AGENT_META_REPORT_BYTES,
                unit=MetricUnit.COUNT,
                description="Meta report self monitor bytes")
            # 各advice方法指定次数
            self._advice_execution_count = self._meter.create_counter(
                name=SELF_MONITOR_AGENT_ADVICE_EXECUTION_COUNT,
                unit=MetricUnit.COUNT,
                description="Instrumenter start self monitor")
            # 埋点异常次数
            self._advice_threw_exception_count = self._meter.create_counter(
                name=SELF_MONITOR_ADVICE_THREW_EXCEPTION_COUNT,
                unit=MetricUnit.COUNT,
                description="Advice threw exception self monitor")
            self._inited = True
        except Exception as e:
            _logger.warning("[self_monitor] failed to init self monitor metrics", str(e))

    def self_monitor_enable(self):
        return self._enable

    def record_agent_span_report(self, bytes, export_attributes):
        if not self.self_monitor_enable():
            return
        self._lazy_init_meter()
        if self._agent_span_report_result:
            self._agent_span_report_result.add(1, attributes=export_attributes)
        if self._agent_span_report_bytes:
            self._agent_span_report_bytes.add(bytes, attributes=export_attributes)

    def record_agent_metric_report(self, bytes, export_attributes):
        if not self.self_monitor_enable():
            return
        self._lazy_init_meter()
        if self._agent_metric_report_result:
            self._agent_metric_report_result.add(1, attributes=export_attributes)
        if self._agent_metric_report_bytes:
            self._agent_metric_report_bytes.add(bytes, attributes=export_attributes)

    def record_agent_meta_report(self, bytes, export_attributes):
        if not self.self_monitor_enable():
            return
        self._lazy_init_meter()
        if self._agent_meta_report_result:
            self._agent_meta_report_result.add(1, attributes=export_attributes)
        if self._agent_meta_report_bytes:
            self._agent_meta_report_bytes.add(bytes, attributes=export_attributes)

    def record_advice_execution(self, rt, export_attributes):
        if not self.self_monitor_enable():
            return
        self._lazy_init_meter()
        if not self._self_monitor_sampled():
            return
        if self._advice_execution_count:
            self._advice_execution_count.add(1, attributes=export_attributes)

    def record_advice_threw_exception(self, rt, export_attributes):
        if not self.self_monitor_enable():
            return
        self._lazy_init_meter()
        if not self._self_monitor_sampled():
            return
        if self._advice_threw_exception_count:
            self._advice_threw_exception_count.add(1, attributes=export_attributes)

    def _self_monitor_sampled(self):
        return (time.time_ns() // 1000) % SELF_MONITOR_SAMPLE_RATE == 0

    def set_self_monitor_enable(self, enable):
        self._enable = enable

    def _lazy_init_meter(self):
        if not _self_monitor_metrics._inited:
            _self_monitor_metrics.init_self_monitor_metrics()

    def __init__(self):
        self._advice_threw_exception_count = None
        self._advice_execution_count = None
        self._agent_meta_report_result = None
        self._agent_meta_report_bytes = None
        self._agent_metric_report_result = None
        self._agent_metric_report_bytes = None
        self._agent_span_report_bytes = None
        self._agent_span_report_result = None
        self._meter = None
        self._meter_provider = None
        self._inited = False
        self._enable = True


_self_monitor_metrics = ArmsSelfMonitor()