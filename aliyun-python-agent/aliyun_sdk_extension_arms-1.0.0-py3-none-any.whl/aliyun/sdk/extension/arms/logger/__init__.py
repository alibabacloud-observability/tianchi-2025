import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Mapping, Any

from aliyun.opentelemetry.instrumentation.gevent_state import global_gevent_state

# 环境变量名称
APSARA_APM_AGENT_WORKSPACE_DIR = "APSARA_APM_AGENT_WORKSPACE_DIR"
LOG_MAX_BYTES = "LOG_MAX_BYTES"
LOG_BACKUP_COUNT = "LOG_BACKUP_COUNT"

# 获取进程ID
PROCESS_ID = os.getpid()
log_file_name = None
log_system_no_perm = False

def concat_log_path(workspace_dir: str):
    return os.path.join(workspace_dir, ".apsara-apm", "python", "logs")

# 获取日志目录，按优先级顺序
def get_log_dir():
    """获取日志目录，按优先级顺序：
    1. APSARA_APM_AGENT_WORKSPACE_DIR 环境变量指定的目录（优先级最高）
    2. ack-onepilot的volume目录
    3. 用户家目录下的 logs 目录
    4. 主文件同级的logs目录
    """
    # 优先级1: 环境变量指定的目录
    try:
        env_log_dir = os.getenv(APSARA_APM_AGENT_WORKSPACE_DIR)
        if env_log_dir:
            env_log_dir = concat_log_path(env_log_dir)
            os.makedirs(env_log_dir, exist_ok=True)
            return env_log_dir
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to ${APSARA_APM_AGENT_WORKSPACE_DIR} directory")

    try:
        # 优先级2: ack-onepilot的volume目录
        pilot_dir = concat_log_path("/home/admin/.opt")
        os.makedirs(pilot_dir, exist_ok=True)
        return pilot_dir
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to /home/admin/.opt directory")

    try:
        # 优先级3: 用户家目录下的 logs 目录
        home_logs = concat_log_path(os.path.join(os.path.expanduser("~")))
        os.makedirs(home_logs, exist_ok=True)
        return home_logs
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to $HOME directory")

    try:
        # 优先级4: 主文件同级的logs目录
        current_logs = concat_log_path("logs")
        os.makedirs(current_logs, exist_ok=True)
        return current_logs
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to current directory")
    return None


def get_log_file():
    """获取日志文件路径"""
    global log_file_name, log_system_no_perm
    if log_system_no_perm:
        return None
    if log_file_name:
        return log_file_name
    log_dir = get_log_dir()
    if log_dir:
        log_file_name = f"{log_dir}/aliyun-python-agent-{os.getpid()}.log"
    else:
        log_system_no_perm = True
    return log_file_name

_logger_list: Mapping[str, Any] = {}
_sls_log_handler = None

def getLogger(logger_name: str, level=logging.WARN, add_sls_log_handler=True):
    """Function to setup a logger; can be called from any module in the code."""
    if logger := _get_logger(logger_name):
        return logger
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    logger.propagate = False
    log_file = get_log_file()
    if not log_file:
        return logger
    handler = RotatingFileHandler(log_file, maxBytes=getMaxBytes(), backupCount=getBackupCount())
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    _logger_list[logger_name] = logger
    if add_sls_log_handler and global_gevent_state.inited:
        try:
            set_sls_log_handler(logger)
        except Exception:
            return logger
    return logger


def set_all_logger_level(level=logging.INFO):
    for logger_name, logger in _logger_list.items():
        logger.setLevel(level)


def set_sls_log_handler(logger):
    if logger is None:
        return
    sls_log_handler = _get_global_sls_log_handler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    sls_log_handler.setFormatter(formatter)
    logger.addHandler(sls_log_handler)


def _get_global_sls_log_handler():
    from aliyun.sdk.extension.arms.logger.sls_log_handler import SlsLogHandler
    global _sls_log_handler
    if _sls_log_handler is None:
        _sls_log_handler = SlsLogHandler()
    return _sls_log_handler


def init_self_logger():
    for logger_name, logger in _logger_list.items():
        set_sls_log_handler(logger)


def _get_logger(logger_name: str):
    logger = _logger_list.get(logger_name)
    return logger

def getMaxBytes() -> int:
    max_m_bytes = 300
    size_str = os.getenv(LOG_MAX_BYTES, "300")
    if size_str is not None and size_str.isnumeric():
        max_m_bytes = int(size_str)

    return max_m_bytes * 1024 * 1024


def getBackupCount() -> int:
    backup_cnt = 2
    cnt_str = os.getenv(LOG_BACKUP_COUNT, "2")
    if cnt_str is not None and cnt_str.isnumeric():
        backup_cnt = int(cnt_str)

    return backup_cnt

get_log_file()