import logging

from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.metadata import add_sls_log
from aliyun.sdk.extension.arms.metadata.module.metadata import SLSLogData
from aliyun.sdk.extension.arms.proto.arms_log_pb2 import Log
from aliyun.sdk.extension.arms.utils import get_local_ip

class SlsLogHandler(logging.Handler):

    def __init__(self,level=logging.NOTSET):
        super().__init__(level)
        self.contents = []
        user_id = ArmsEnv().user_id
        arms_env = ArmsEnv()
        self.contents.append(Log.Content(Key="serverIp", Value=get_local_ip()))
        self.contents.append(Log.Content(Key="agentVersion", Value="1.0.0"))
        self.contents.append(Log.Content(Key="armsUserId", Value=user_id))
        self.contents.append(Log.Content(Key="userId", Value=user_id))
        self.contents.append(Log.Content(Key="appId", Value=arms_env.appId))
        self.contents.append(Log.Content(Key="armsAppId", Value=arms_env.appId))
        self.contents.append(Log.Content(Key="job", Value="aliyun-python-agent"))
        self.contents.append(Log.Content(Key="language", Value="python"))

    def emit(self, record):
        value = self.format(record)
        contents = self.contents.copy()
        contents.append(Log.Content(Key="logType", Value="pLog"))
        contents.append(Log.Content(Key="message", Value = value))
        add_sls_log(SLSLogData(log=Log(Contents=contents,Time=int(record.created),Time_ns=0)))
