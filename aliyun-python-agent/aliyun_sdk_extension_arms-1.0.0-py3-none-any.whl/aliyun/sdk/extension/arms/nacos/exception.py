class NacosException(Exception):
    pass


class NacosRequestException(NacosException):
    pass
