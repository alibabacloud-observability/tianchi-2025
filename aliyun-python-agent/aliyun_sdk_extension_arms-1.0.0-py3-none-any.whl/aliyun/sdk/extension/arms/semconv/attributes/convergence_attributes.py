CONVERGENCE_SUFFIX = ".convergence"


def get_convergence_key(src_key: str) -> str:
    if src_key.endswith(CONVERGENCE_SUFFIX):
        return src_key
    return f"{src_key}{CONVERGENCE_SUFFIX}"
