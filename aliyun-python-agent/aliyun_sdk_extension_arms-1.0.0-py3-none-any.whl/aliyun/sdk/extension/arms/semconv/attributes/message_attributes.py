

MESSAGE_DELEY_MILLISECONDS = "messaging.consume.delay_ms"

