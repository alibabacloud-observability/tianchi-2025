
from enum import Enum
class LLMMetricsAttributes:

    MODEL_NAME = "modelName"

    USAGE_TYPE = "usageType"


class UsageTypeValue(Enum):

    Input = "input"

    Output = "output"

