RPC = "rpc"

PID = "pid"

PPID = "ppid"

PRPC = "prpc"

EagleEye_pAppName = "EagleEye-pAppName"

EagleEye_pRpc = "EagleEye-pRpc"

RPC_TYPE = "rpcType"

APP = "app"

SOURCE = "source"

VERSION = "version"

STATUS = "status"

HOST = "host"
