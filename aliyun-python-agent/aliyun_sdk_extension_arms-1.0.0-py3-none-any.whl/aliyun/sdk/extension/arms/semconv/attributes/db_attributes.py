


DB_STATEMENT_ID = "db.statement.id"

SQL_ID = "sqlId"

OP_TYPE = "opType"

DB_SYSTEM = "db.system"

DB_NAME = "db.name"

SQL_KEY = "sql"

SQL_IDS = "sql.ids"