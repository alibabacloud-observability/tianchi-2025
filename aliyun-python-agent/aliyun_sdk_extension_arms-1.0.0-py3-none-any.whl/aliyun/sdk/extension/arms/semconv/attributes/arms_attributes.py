from enum import Enum

VERSION = "version"

STATUS = "status"

ENDPOINT = "endpoint"

DEST_ID = "destId"

RPC = "rpc"

HOST = "host"

OUT_IDS = "out.ids"

EagleEye_pAppName = "EagleEye-pAppName"

EagleEye_pRpc = "EagleEye-pRpc"

NET_PROTOCOL_NAME = "net.protocol.name"

COMPONENT_NAME = "component.name"

RPC_TYPE = "rpcType"

TRACE_PROTOCOL_TYPE = "trace.protocol.type"

EXCEP_TYPE = "excepType"

EXCEP_INFO = "excepInfo"

EXCEP_NAME = "excepName"

EXCEP_IDS = "excep.ids"

CALL_TYPE = "callType"

CALL_KIND = "callKind"

SERVICE_TYPE = "serviceType"

PID = "pid"

CLUSTER_ID = "clusterId"

PPID = "ppid"

PRPC = "prpc"


class RpcTypeValue(Enum):
    HTTP = 0

    HTTP_CLIENT = 25

    MYSQL = 60

    REDIS = 70

    GRPC = 9

    GRPC_CLIENT = 10

    MONGODB = 64


class CallTypeValue(Enum):
    HTTP = "http"

    HTTP_CLIENT = "http_client"

    MYSQL = "mysql"

    REDIS = "redis"

    GRPC = "grpc"

    GRPC_CLIENT = "grpc_client"

    MONGODB = "mongodb"


class ComponentNameValue(Enum):
    HTTP_SERVER = "http_server"

    HTTP_CLIENT = "http_client"

    HTTPX = "httpx"

    DIFY = "dify"

    DASHSCOPE = "dashscope"

    OPENAI = "openai"

    LLAMA_INDEX = "llama_index"

    LANGCHAIN = "langchain"

    REDIS = "redis"

    SQLALCHEMY = "sqlalchemy"

# TODO
class ServiceTypeValue(Enum):
    HTTP = "9152"
    HTTP_CLIENT = "9055"
    DUBBO_CONSUMER = "9110"
    DUBBO_PROVIDER = "1110"
    GRPC_CONSUMER = "9101"
    GRPC_PROVIDER = "1101"
    DB = "2250"


def categorize_http_status(status_code):
    category = status_code // 100
    if category == 2:
        return "2xx"
    elif category == 3:
        return "3xx"
    elif category == 4:
        return "4xx"
    elif category == 5:
        return "5xx"
    else:
        return "Unknown"
