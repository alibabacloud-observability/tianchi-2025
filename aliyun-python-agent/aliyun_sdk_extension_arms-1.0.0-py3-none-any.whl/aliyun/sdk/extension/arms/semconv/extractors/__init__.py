
from aliyun.sdk.extension.arms.semconv.extractors.http_extractor import HttpExtractor

__all__ = ["HttpExtractor","BaseExtractor"]