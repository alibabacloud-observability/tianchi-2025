from aliyun.sdk.extension.arms.logger import getLogger

from aliyun.sdk.extension.arms.semconv.extractors.extractor import BaseExtractor
from aliyun.sdk.extension.arms.semconv.attributes import arms_attributes as ArmsAttributes
from aliyun.sdk.extension.arms.convergence import converge, TargetType
from aliyun.opentelemetry.semconv.trace import SpanAttributes
from opentelemetry.baggage import get_all, get_baggage

_http_attrs = {
    ArmsAttributes.RPC,
    ArmsAttributes.RPC_TYPE,
    ArmsAttributes.CALL_KIND,
    ArmsAttributes.CALL_TYPE,
    ArmsAttributes.DEST_ID,
    ArmsAttributes.ENDPOINT,
    ArmsAttributes.PRPC,
    ArmsAttributes.PPID,
}

_logger = getLogger(__name__)


class HttpExtractor(BaseExtractor):

    def _extract(self, data: dict) -> dict:
        attrs = {
            key: data[key]
            for key in self._attr_keys.intersection(data.keys())
        }
        return attrs

    def _extract_endpoint(self, data: dict) -> dict:
        if ArmsAttributes.RPC in data:
            rpc = data[ArmsAttributes.RPC]
            return {ArmsAttributes.ENDPOINT: f"{rpc}"}
        if SpanAttributes.URL_PATH in data:
            rpc = data[SpanAttributes.URL_PATH]
            converged_rpc = converge(TargetType.other_rpc, rpc)
            return {ArmsAttributes.ENDPOINT: f"{converged_rpc}"}
        else:
            _logger.warning(f"[Element Not Find] endpoint is not in attributes")
        return None

    def _extract_dest_id(self, data: dict) -> dict:
        # return {ArmsAttributes.DEST_ID: data[SpanAttributes.DESTINATION_DOMAIN]}
        if SpanAttributes.DESTINATION_DOMAIN in data:
            return {ArmsAttributes.DEST_ID: f"{data[SpanAttributes.DESTINATION_DOMAIN]}"}
        else:
            _logger.warning(f"[Element Not Find] dest domain is not in attributes")
        return None

    def _extract_rpc(self, data: dict) -> dict:
        return {ArmsAttributes.RPC, data[SpanAttributes.URL_PATH]}

    def extract_status_code(self, status_code: int) -> str:
        if status_code == 200:
            return "200"
        elif 200 < status_code < 300:
            return "2xx"
        elif 300 < status_code < 400:
            return "3xx"
        elif 400 < status_code < 500:
            return "4xx"
        elif 100 <= status_code < 200:
            return "1xx"
        else:
            return "5xx"

    def _init_attr_key(self):
        self._attr_keys = _http_attrs
