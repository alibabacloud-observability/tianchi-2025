

from abc import ABC, abstractmethod


class BaseExtractor(ABC):


    _instance = None
    _attr_keys = {}


    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = object.__new__(cls)

        return cls._instance

    def __init__(self):
        self._init_attr_key()
        assert len(self._attr_keys) != 0


    def extract(self, data: dict) -> dict:
        attr = self._extract(data)
        assert len(attr) > 0
        dest_id_kv = self._extract_dest_id(data)
        endpoint_kv = self._extract_endpoint(data)
        if dest_id_kv is not None:
            attr.update(dest_id_kv)
        if endpoint_kv is not None:
            attr.update(endpoint_kv)

        return attr

    @abstractmethod
    def _extract_endpoint(self,data: dict) -> dict:
        pass

    @abstractmethod
    def _extract_dest_id(self,data: dict) -> dict:
        pass
    @abstractmethod
    def _extract(self,data: dict) -> dict:
        pass

    @abstractmethod
    def _extract_rpc(self, data: dict) -> dict:
        pass

    @abstractmethod
    def _init_attr_key(self):
        pass