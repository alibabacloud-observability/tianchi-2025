from opentelemetry.metrics import (get_meter,
                                   Meter)
from typing import Union
from typing import Iterable
from opentelemetry.metrics import (
    CallbackOptions,
    Observation
)
from opentelemetry.util.types import Attributes
from threading import Lock

class SingletonMeta(type):
    """
    This is a thread-safe implementation of Singleton.
    """

    _instances = {}

    _lock: Lock = Lock()
    """
    We now have a lock object that will be used to synchronize threads during
    first access to the Singleton.
    """

    @classmethod
    def reset(cls):
        with cls._lock:
            cls._instances.clear()

    def __call__(cls, *args, **kwargs):
        """
        Possible changes to the value of the `__init__` argument do not affect
        the returned instance.
        """
        # Now, imagine that the program has just been launched. Since there's no
        # Singleton instance yet, multiple threads can simultaneously pass the
        # previous conditional and reach this point almost at the same time. The
        # first of them will acquire lock and will proceed further, while the
        # rest will wait here.
        with cls._lock:
            # The first thread to acquire the lock, reaches this conditional,
            # goes inside and creates the Singleton instance. Once it leaves the
            # lock block, a thread that might have been waiting for the lock
            # release may then enter this section. But since the Singleton field
            # is already initialized, the thread won't create a new object.
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance
        return cls._instances[cls]


class MetricUnit:
    COUNT = "count"

    MS = "ms"

    S = "s"

    BY = "By"


class MetricInstruments:
    """
    app metrics
    """
    ARMS_RPC_REQUESTS_COUNT = "arms_rpc_requests_count"

    ARMS_RPC_REQUESTS_SECONDS = "arms_rpc_requests_seconds"

    ARMS_RPC_REQUESTS_ERROR_COUNT = "arms_rpc_requests_error_count"

    ARMS_RPC_REQUESTS_SLOW_COUNT = "arms_rpc_requests_slow_count"

    ARMS_RPC_REQUESTS_BY_STATUS_COUNT = "arms_rpc_requests_by_status_count"

    ARMS_RPC_RESULT_BYTES = "arms_rpc_result_bytes"

    ARMS_RPC_REQUEST_BYTES = "arms_rpc_request_bytes"

    ARMS_RPC_DELAY_SECONDS = "arms_rpc_delay_seconds"

    ARMS_RPC_REQUESTS_BY_STATUS_COUNT = "arms_rpc_requests_by_status_count"

    ARMS_TAG_HOST_ENTITY = "arms_tag_host_entity"

    SELF_MONITOR_INSTRUMENT_START_COUNT = "self_monitor_agent_instrumentor_start_count"
    SELF_MONITOR_INSTRUMENT_END_COUNT = "self_monitor_agent_instrumentor_end_count"
    SELF_MONITOR_INSTRUMENT_START_DURATION_SUM = "self_monitor_agent_instrumentor_start_rt"
    SELF_MONITOR_INSTRUMENT_END_DURATION_SUM = "self_monitor_agent_instrumentor_end_rt"

    #   LLM Metrics
    GEN_AI_CALLS_COUNT = "genai_calls_count"

    GEN_AI_CALLS_DURATION_SECONDS = "genai_calls_duration_seconds"

    GEN_AI_CALLS_ERROR_COUNT = "genai_calls_error_count"

    GEN_AI_CALLS_SLOW_COUNT = "genai_calls_slow_count"

    GEN_AI_LLM_CONTEXT_SIZE = "genai_llm_context_size"

    GEN_AI_LLM_PROMPT_SIZE = "genai_llm_prompt_size"

    GEN_AI_LLM_FIRST_TOKEN_SECONDS = "genai_llm_first_token_seconds"

    GEN_AI_LLM_OUTPUT_TOKEN_SECONDS = "genai_llm_output_token_seconds"

    GEN_AI_LLM_USAGE_TOKENS = "genai_llm_usage_tokens"


class ArmsCommonServiceMetrics(metaclass=SingletonMeta):
    __slots__ = ("total_requests_count",
                 "requests_duration",
                 "error_requests_count",
                 "slow_requests_count",
                 "status_requests_count",
                 "arms_rpc_requests_latency_seconds",
                 "response_size",
                 "request_size",
                 "delay_duration",
                 "arms_tag_host_entity",
                 "calls_count",
                 "call_error_count",
                 "calls_duration_seconds",
                 "llm_context_size",
                 "llm_prompt_size",
                 "llm_output_token_seconds",
                 "llm_usage_tokens",
                 "llm_first_token_seconds",
                 "self_monitor_agent_instrumentor_end_rt",
                 "self_monitor_agent_instrumentor_start_rt",
                 "self_monitor_agent_instrumentor_end_count",
                 "self_monitor_agent_instrumentor_start_count")

    def __init__(self, meter: Meter):
        self.total_requests_count = meter.create_counter(name=MetricInstruments.ARMS_RPC_REQUESTS_COUNT,
                                                         unit=MetricUnit.COUNT,
                                                         description="The total number of HTTP requests")
        self.error_requests_count = meter.create_counter(
            name=MetricInstruments.ARMS_RPC_REQUESTS_ERROR_COUNT,
            unit=MetricUnit.COUNT,
            description="The total number of HTTP error requests")
        self.slow_requests_count = meter.create_counter(
            name=MetricInstruments.ARMS_RPC_REQUESTS_SLOW_COUNT,
            unit=MetricUnit.COUNT,
            description="The total number of slow HTTP requests")
        self.status_requests_count = meter.create_counter(
            name=MetricInstruments.ARMS_RPC_REQUESTS_BY_STATUS_COUNT,
            unit=MetricUnit.COUNT,
            description="The total number of HTTP requests status")
        self.requests_duration = meter.create_histogram(
            name=MetricInstruments.ARMS_RPC_REQUESTS_SECONDS,
            unit=MetricUnit.MS,
            description="Duration of HTTP client requests."
        )
        self.response_size = meter.create_histogram(
            name=MetricInstruments.ARMS_RPC_RESULT_BYTES,
            unit=MetricUnit.BY,
            description="Arms response bytes")
        self.request_size = meter.create_histogram(
            name=MetricInstruments.ARMS_RPC_REQUEST_BYTES,
            unit=MetricUnit.BY,
            description="Arms request bytes")
        self.delay_duration = meter.create_histogram(
            name=MetricInstruments.ARMS_RPC_DELAY_SECONDS,
            unit=MetricUnit.S,
            description="The latency of rpc invocation")
        self.arms_tag_host_entity = meter.create_gauge(
            name=MetricInstruments.ARMS_TAG_HOST_ENTITY,
            unit=MetricUnit.S,
            description="ARMS host entity tag")
        self.self_monitor_agent_instrumentor_start_rt = meter.create_counter(
            name=MetricInstruments.SELF_MONITOR_INSTRUMENT_START_DURATION_SUM,
            unit=MetricUnit.COUNT,
            description="Total instrumentor start duration sum")
        self.self_monitor_agent_instrumentor_end_rt = meter.create_counter(
            name=MetricInstruments.SELF_MONITOR_INSTRUMENT_END_DURATION_SUM,
            unit=MetricUnit.COUNT,
            description="Total instrumentor end duration sum")
        self.self_monitor_agent_instrumentor_start_count = meter.create_counter(
            name=MetricInstruments.SELF_MONITOR_INSTRUMENT_START_COUNT,
            unit=MetricUnit.COUNT,
            description="Total instrumentor start execute sum")
        self.self_monitor_agent_instrumentor_end_count = meter.create_counter(
            name=MetricInstruments.SELF_MONITOR_INSTRUMENT_END_COUNT,
            unit=MetricUnit.COUNT,
            description="Total instrumentor end execute sum")
        self.calls_count =  meter.create_counter(
            name=MetricInstruments.GEN_AI_CALLS_COUNT,
            unit=MetricUnit.COUNT,
            description="Total call count of LLM")
        self.calls_duration_seconds =  meter.create_histogram(
            name=MetricInstruments.GEN_AI_CALLS_DURATION_SECONDS,
            unit=MetricUnit.MS,
            description="Duration of LLM call."
        )
        self.call_error_count = meter.create_counter(
            name=MetricInstruments.GEN_AI_CALLS_ERROR_COUNT,
            unit=MetricUnit.COUNT,
            description="Total error call count of LLM")
        self.llm_context_size = meter.create_histogram(
            name=MetricInstruments.GEN_AI_LLM_CONTEXT_SIZE,
            unit=MetricUnit.BY,
            description="Context size of LLM ")
        self.llm_prompt_size = meter.create_histogram(
            name=MetricInstruments.GEN_AI_LLM_PROMPT_SIZE,
            unit=MetricUnit.BY,
            description="Prompt size of LLM")
        self.llm_output_token_seconds = meter.create_histogram(
            name=MetricInstruments.GEN_AI_LLM_OUTPUT_TOKEN_SECONDS,
            unit=MetricUnit.MS,
            description="Duration of LLM output invocation"
        )
        self.llm_first_token_seconds = meter.create_histogram(
            name=MetricInstruments.GEN_AI_LLM_FIRST_TOKEN_SECONDS,
            unit=MetricUnit.MS,
            description="Duration of LLM first call."
        )
        self.llm_usage_tokens = meter.create_counter(
            name=MetricInstruments.GEN_AI_LLM_USAGE_TOKENS,
            unit=MetricUnit.COUNT,
            description="Token count of the LLM prompt, completion, and embedding")


class RpcType:
    HTTP = 0

    HTTP_CLIENT = 25

    MYSQL = 60

    REDIS = 70

    GRPC = 9

    GRPC_CLIENT = 10

    MONGODB = 64
