from aliyun.sdk.extension.arms.config.constant import CMS_WORKSPACE_KEY_IN_METRIC, ARMS_SERVICE_ID_KEY_IN_METRIC
from aliyun.sdk.extension.arms.proto.arms_measures_pb2 import (
    MeasureBatches,
    MeasureBatch,
    Measures,
    Measure,
    EnumUnit
)
from typing import Mapping, Optional, Sequence, Tuple, Union
import time
import socket
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.opentelemetry.instrumentation import version

from aliyun.opentelemetry.sdk.metrics.export import (
    AggregationTemporality,
    Gauge,
    Histogram,
    Metric,
    MetricExporter,
    MetricExportResult,
    MetricsData,
    Sum,
    NumberDataPoint,
    HistogramDataPoint
)
from opentelemetry.util.types import Attributes

from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.tag import arms_tag_service

_logger = getLogger(__name__)


class ArmsMeasureBatches():
    def __init__(self, app_measure_batches: MeasureBatches, self_monitor_measure_batches: MeasureBatches):
        self.app_measure_batches = app_measure_batches
        self.self_monitor_measure_batches = self_monitor_measure_batches

class ArmsMetricDataConverter():
    '''
    convert otel metrics data to Arms Metric Data
    '''

    def __init__(self):
        pass

    def convert_to_arms_metric(self, metrics_data: MetricsData) -> ArmsMeasureBatches:
        global app_measure_batch_list, self_monitor_measure_batch_list
        for rms in metrics_data.resource_metrics:
            app_measure_batch_list = []
            self_monitor_measure_batch_list = []
            res = rms.resource.attributes
            timestamp = int(round(time.time() * 1000))
            local_ip = ArmsEnv.instance().ip
            for scm in rms.scope_metrics:
                for metric in scm.metrics:
                    if len(metric.data.data_points) > 0:
                        timestamp = metric.data.data_points[0].time_unix_nano // 1000000
                    measuresList = self.convert_metric_data(metric)
                    metric_type = "app"
                    is_self_monitor = False
                    if metric.name.startswith("arms_python"):
                        metric_type = "system"
                    if metric.name.startswith("self_monitor"):
                        metric_type = "selfMonitor"
                        is_self_monitor = True
                    common_tags = {
                        "app": ArmsEnv.instance().appName,
                        "clusterId": ArmsEnv.instance().clusterId,
                        "language": "python",
                        "namespace": ArmsEnv.instance().namespace,
                        CMS_WORKSPACE_KEY_IN_METRIC: ArmsEnv.instance().workspace,
                        ARMS_SERVICE_ID_KEY_IN_METRIC: ArmsEnv.instance().service_id
                    }
                    if is_self_monitor:
                        self_monitor_measure_batch = MeasureBatch(
                            version=version.__agent_version__,
                            type=metric_type,
                            time=timestamp,
                            measures=measuresList,
                            pid=ArmsEnv.instance().agentId,
                            ip=local_ip,
                            commonTags=common_tags,
                        )
                        self_monitor_measure_batch_list.append(self_monitor_measure_batch)
                    else:
                        for k, v in arms_tag_service.global_arms_tag_service.host_tags.items():
                            common_tags[k] = v
                        for k, v in arms_tag_service.global_arms_tag_service.app_tags.items():
                            common_tags[k] = v
                        app_measure_batch = MeasureBatch(
                            version=version.__agent_version__,
                            type=metric_type,
                            time=timestamp,
                            measures=measuresList,
                            pid=ArmsEnv.instance().agentId,
                            ip=local_ip,
                            commonTags=common_tags,
                        )
                        app_measure_batch_list.append(app_measure_batch)

        app_measure_batches = MeasureBatches(
            measureBatches=app_measure_batch_list,
            headers=[]
        )
        self_monitor_measure_batches = MeasureBatches(
            measureBatches=self_monitor_measure_batch_list,
            headers=[]
        )
        return ArmsMeasureBatches(app_measure_batches, self_monitor_measure_batches)

    def get_local_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 尝试连接到一个不需要真实存在的地址
        s.connect(("114.114.114.114", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip

    def convert_metric_data(self, metric: Metric):
        # 这里应该是`convertMetricData`函数的具体实现
        data_points = metric.data.data_points
        measuresList = []
        if isinstance(metric.data, Sum):
            for data_point in data_points:
                measureList = self.convert_normal_metric_data(data_point, metric)
                measures = Measures(
                    labels=self.convert_point_data_labels(data_point.attributes),
                    measures=measureList
                )
                measuresList.append(measures)
        elif isinstance(metric.data, Histogram):
            for data_point in data_points:
                measureList = self.convert_histogram_metric_data(data_point, metric)
                measures = Measures(
                    labels=self.convert_point_data_labels(data_point.attributes),
                    measures=measureList
                )
                measuresList.append(measures)
        elif isinstance(metric.data, Gauge):
            for data_point in data_points:
                measureList = self.convert_normal_metric_data(data_point, metric)
                measures = Measures(
                    labels=self.convert_point_data_labels(data_point.attributes),
                    measures=measureList
                )
                measuresList.append(measures)
        return measuresList

    def convert_point_data_labels(self, attributes: Attributes) -> Mapping:
        # 这里应该是`convertPointDataLabels`函数的具体实现
        attr = {}
        for key in attributes:
            attr[key] = f'{attributes[key]}'
        return attr

    def convert_normal_metric_data(self, data_point: NumberDataPoint, metric: Metric):
        # 这里应该是`convert Normal MetricData`函数的具体实现
        measureList = []
        measure = Measure(
            valueType="COUNT",
            name=metric.name,
            unit=self._get_measure_unit(metric.unit),
            value=float(data_point.value),
            desc=metric.description
        )
        measureList.append(measure)
        return measureList

    def _get_measure_unit(self, unit_str: str) -> EnumUnit:
        '''
        get measure unit
        '''
        unit = EnumUnit.UNKNOWN
        if str == "s":
            unit = EnumUnit.SECOND
        elif str == "ms":
            unit = EnumUnit.MILLISECONDS
        elif str == "count":
            unit = EnumUnit.COUNT
        elif str == "b":
            unit = EnumUnit.BYTE
        else:
            unit = EnumUnit.UNKNOWN
        return unit

    def convert_histogram_metric_data(self, data_point: HistogramDataPoint, metric: Metric):
        # 这里应该是`convertHistogramMetricData`函数的具体实现
        measureList = []
        metric_name = metric.name
        if metric.name.startswith("arms_python"):
            metric_name = f"{metric.name}_count"
        countMeasure = Measure(
            valueType="COUNT",
            name=metric_name,
            unit=EnumUnit.COUNT,
            value=float(data_point.count),
            desc=metric.description
        )
        metric_name = metric.name
        if metric.name.startswith("arms_python"):
            metric_name = f"{metric.name}_sum"
        measureList.append(countMeasure)
        msMeasure = Measure(
            valueType="SUM",
            name=metric_name,
            unit=EnumUnit.MILLISECONDS,
            value=float(data_point.sum),
            desc=metric.description
        )
        measureList.append(msMeasure)
        # minMeasure = Measure(
        #     valueType="MIN",
        #     name=metric.name,
        #     unit=EnumUnit.COUNT,
        #     value=float(data_point.min),
        #     desc=metric.description
        # )
        # measureList.append(minMeasure)
        # maxMeasure = Measure(
        #     valueType="MAX",
        #     name=metric.name,
        #     unit=EnumUnit.COUNT,
        #     value=float(data_point.max),
        #     desc=metric.description
        # )
        # measureList.append(maxMeasure)

        return measureList
